package cn.local.resumestudio;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.AtomicFile;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_FILE = 110;
    private static final int SAVE_DOCUMENT = 111;
    private static final int MAX_TEXT = 24 * 1024 * 1024;
    private static final int MAX_STATE_BYTES = 20 * 1024 * 1024;
    private final Object stateLock = new Object();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ArrayList<String> results = new ArrayList<>();
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private PdfExporter pdf;
    private PendingSave pendingSave;
    private boolean ready;
    private boolean busy;

    private static final class PendingSave {
        final File file;
        final String mime, type, mode;
        final int pages, pageLimit;
        PendingSave(File file, String mime, String type, String mode) {
            this(file, mime, type, mode, 0, 0);
        }
        PendingSave(File file, String mime, String type, String mode, int pages, int pageLimit) {
            this.file = file; this.mime = mime; this.type = type; this.mode = mode;
            this.pages = pages; this.pageLimit = pageLimit;
        }
    }

    private String appVersion() {
        try {
            String version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            return version == null ? "unknown" : version;
        } catch (android.content.pm.PackageManager.NameNotFoundException ignored) {
            return "unknown";
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244, 247, 250));
        // Native owns insets. The asset UI has no duplicate safe-area padding.
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets keyboard = insets.getInsets(WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, keyboard.bottom));
                return WindowInsets.CONSUMED;
            }
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) root.post(() -> {
            android.view.WindowInsetsController controller = root.getWindowInsetsController();
            if (controller != null) controller.setSystemBarsAppearance(
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        });
        root.requestApplyInsets();
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        WebView.setWebContentsDebuggingEnabled(debug);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBlockNetworkLoads(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        web.setBackgroundColor(Color.rgb(244, 247, 250));
        web.setWebViewClient(new AssetClient(this, () -> {
            ready = true;
            for (String result : results) emit(result);
            results.clear();
        }));
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                                        FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Set<String> types = new LinkedHashSet<>();
                for (String accept : params.getAcceptTypes()) {
                    if (accept == null) continue;
                    for (String one : accept.split(",")) {
                        String mime = acceptMime(one.trim());
                        if (mime != null) types.add(mime);
                    }
                }
                pick.setType(types.size() == 1 ? types.iterator().next() : "*/*");
                if (types.size() > 1) pick.putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0]));
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try { startActivityForResult(pick, PICK_FILE); }
                catch (ActivityNotFoundException e) {
                    fileCallback.onReceiveValue(null); fileCallback = null;
                    Toast.makeText(MainActivity.this, "系统暂时没有文件选择器", Toast.LENGTH_LONG).show();
                }
                return true;
            }

            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR)
                    recordError("client_console", message.lineNumber());
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Native");
        if (savedInstanceState != null) restorePending(savedInstanceState);
        web.loadUrl(AssetClient.ORIGIN + "index.html");
    }

    private static String acceptMime(String value) {
        String s = value.toLowerCase(Locale.ROOT);
        if (s.equals(".jpg") || s.equals(".jpeg")) return "image/jpeg";
        if (s.equals(".png")) return "image/png";
        if (s.equals(".webp")) return "image/webp";
        if (s.equals(".json")) return "application/json";
        if (s.equals(".txt")) return "text/plain";
        if (s.equals(".pdf")) return "application/pdf";
        if (s.equals(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        return s.matches("[a-z0-9.+-]+/[a-z0-9.*+-]+") ? s : null;
    }

    private boolean trusted() {
        return web != null && web.getUrl() != null && AssetClient.isLocal(Uri.parse(web.getUrl()));
    }

    private final class Bridge {
        @JavascriptInterface public String getVersion() { return appVersion(); }

        @JavascriptInterface public String readState() {
            synchronized (stateLock) {
                AtomicFile state = new AtomicFile(new File(getFilesDir(), "resume-state.json"));
                if (state.getBaseFile().length() > MAX_STATE_BYTES) return "";
                try {
                    byte[] bytes = state.readFully();
                    if (bytes.length > MAX_STATE_BYTES) return "";
                    return new String(bytes, StandardCharsets.UTF_8);
                } catch (IOException | RuntimeException e) { return ""; }
            }
        }

        @JavascriptInterface public boolean writeState(String json) {
            if (json == null || json.length() > MAX_STATE_BYTES) return false;
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_STATE_BYTES) return false;
            synchronized (stateLock) {
                AtomicFile state = new AtomicFile(new File(getFilesDir(), "resume-state.json"));
                FileOutputStream stream = null;
                try {
                    // Reject broken backups before replacing the last committed state.
                    new JSONObject(json);
                    stream = state.startWrite();
                    stream.write(bytes);
                    state.finishWrite(stream);
                    stream = null;
                    // AtomicFile's sync/rename paths can log rather than throw.
                    // Return success only after the committed bytes read back.
                    return Arrays.equals(bytes, state.readFully());
                } catch (IOException | JSONException | RuntimeException e) {
                    if (stream != null) state.failWrite(stream);
                    return false;
                }
            }
        }

        @JavascriptInterface public void exportPdf(String html, String name, String mode, int pageLimit) {
            runOnUiThread(() -> {
                if (!trusted()) return;
                String selectedMode = mode == null ? "save" : mode;
                if (pageLimit != 1 && pageLimit != 2) {
                    result("pdf", false, "请选择一页或两页目标后重试", selectedMode, 0, pageLimit); return;
                }
                if (!selectedMode.matches("save|share|wechat|qq")) {
                    result("pdf", false, "导出方式无效", selectedMode, 0, pageLimit); return;
                }
                if (busy) { result("pdf", false, "上一项导出尚未结束，请返回后重试", selectedMode, 0, pageLimit); return; }
                if (html == null || html.trim().isEmpty() || html.length() > MAX_TEXT) {
                    result("pdf", false, "简历内容为空或照片过大，请检查后重试", selectedMode, 0, pageLimit); return;
                }
                busy = true;
                try {
                    File output = createExport(safeName(name, "pdf"));
                    pdf = new PdfExporter(MainActivity.this, output, pageLimit, (ok, reason, pages, limit) -> {
                        pdf = null;
                        if (!ok) {
                            busy = false;
                            if (pages <= limit) recordError("pdf_generation", 0);
                            result("pdf", false, reason, selectedMode, pages, limit);
                        }
                        else if (selectedMode.equals("save")) {
                            beginSave(new PendingSave(output, "application/pdf", "pdf", selectedMode, pages, limit));
                        } else share(output, selectedMode, pages, limit);
                    });
                    pdf.start(html);
                } catch (IOException | RuntimeException e) {
                    busy = false; pdf = null; recordError("pdf_start", 0);
                    result("pdf", false, "无法生成 PDF，请检查可用空间后重试", selectedMode, 0, pageLimit);
                }
            });
        }

        @JavascriptInterface public void saveText(String content, String name, String mimeType) {
            runOnUiThread(() -> {
                if (!trusted()) return;
                if (busy) { result("save", false, "上一项导出尚未结束，请返回后重试", "save"); return; }
                if (content == null || content.length() > MAX_TEXT) {
                    result("save", false, "文件内容过大，请缩小照片后重试", "save"); return;
                }
                busy = true;
                String mime = "application/json".equals(mimeType) ? "application/json" : "text/plain";
                String extension = mime.equals("application/json") ? "json" : "txt";
                io.execute(() -> {
                    try {
                        File file = createExport(safeName(name, extension));
                        try (FileOutputStream stream = new FileOutputStream(file)) {
                            stream.write(content.getBytes(StandardCharsets.UTF_8));
                        }
                        runOnUiThread(() -> beginSave(new PendingSave(file, mime, "save", "save")));
                    } catch (IOException | RuntimeException e) {
                        runOnUiThread(() -> {
                            busy = false; recordError("text_export", 0);
                            result("save", false, "无法准备文件，请检查可用空间后重试", "save");
                        });
                    }
                });
            });
        }

        @JavascriptInterface public void reportError(String json) {
            if (json != null && json.length() > 4096) { recordError("client_error", 0); return; }
            String code = "client_error";
            int line = 0;
            try {
                JSONObject data = new JSONObject(json == null ? "{}" : json);
                String requested = data.optString("code", data.optString("name", "client_error"));
                if (requested.matches("[A-Za-z0-9_.:-]{1,80}")) code = requested;
                line = Math.max(0, data.optInt("line", 0));
            } catch (JSONException ignored) { }
            // Deliberately omit arbitrary message, stack, profile and user text.
            recordError(code, line);
        }
    }

    private File createExport(String name) throws IOException {
        File directory = new File(new File(getCacheDir(), "shared"), UUID.randomUUID().toString());
        if (!directory.mkdirs() && !directory.isDirectory()) throw new IOException("Cache unavailable");
        return new File(directory, name);
    }

    private static String safeName(String input, String extension) {
        String name = input == null ? "简历" : input.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (name.isEmpty() || name.equals(".") || name.equals("..")) name = "简历";
        if (name.toLowerCase(Locale.ROOT).endsWith("." + extension))
            name = name.substring(0, name.length() - extension.length() - 1);
        if (name.length() > 80) name = name.substring(0, 80);
        return name + "." + extension;
    }

    private void beginSave(PendingSave save) {
        pendingSave = save;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(save.mime);
        intent.putExtra(Intent.EXTRA_TITLE, save.file.getName());
        try { startActivityForResult(intent, SAVE_DOCUMENT); }
        catch (ActivityNotFoundException e) {
            busy = false; pendingSave = null;
            result(save.type, false, "系统暂时没有文件保存器，可尝试分享 PDF", save.mode, save.pages, save.pageLimit);
        }
    }

    private void share(File file, String mode, int pages, int pageLimit) {
        Uri uri = ResumeFileProvider.uriFor(file);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, file.getName());
        send.setClipData(ClipData.newRawUri(file.getName(), uri));
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        String target = mode.equals("wechat") ? "com.tencent.mm"
                : mode.equals("qq") ? "com.tencent.mobileqq" : null;
        boolean directed = false;
        if (target != null) {
            send.setPackage(target);
            directed = send.resolveActivity(getPackageManager()) != null;
            if (!directed) send.setPackage(null);
        }
        try {
            if (directed) startActivity(send);
            else {
                Intent chooser = Intent.createChooser(send, target == null ? "分享简历 PDF" : "目标应用不可用，请选择分享方式");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                chooser.setClipData(send.getClipData());
                startActivity(chooser);
            }
            result("pdf", true, directed ? "已打开目标应用，请自行选择联系人并确认发送"
                    : target == null ? "已打开分享面板，请自行选择接收方式"
                    : "未找到可接收 PDF 的目标应用，已打开系统分享面板", mode, pages, pageLimit);
        } catch (ActivityNotFoundException | SecurityException e) {
            recordError("pdf_share", 0);
            result("pdf", false, "暂时无法打开分享，请保存 PDF 后从 QQ 或微信添加文件", mode, pages, pageLimit);
        } finally { busy = false; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            if (fileCallback != null) {
                Uri selected = resultCode == RESULT_OK && data != null ? data.getData() : null;
                // A chooser returns content URIs. Never accept arbitrary file:// locations.
                if (selected != null && !"content".equals(selected.getScheme())) selected = null;
                fileCallback.onReceiveValue(selected == null ? null : new Uri[]{selected});
                fileCallback = null;
            }
        } else if (requestCode == SAVE_DOCUMENT && pendingSave != null) {
            PendingSave save = pendingSave; pendingSave = null;
            Uri destination = resultCode == RESULT_OK && data != null ? data.getData() : null;
            if (destination == null) {
                busy = false; result(save.type, false, "已取消保存，资料已保留", save.mode, save.pages, save.pageLimit); return;
            }
            io.execute(() -> {
                try (FileInputStream input = new FileInputStream(save.file);
                     OutputStream output = getContentResolver().openOutputStream(destination, "wt")) {
                    if (output == null) throw new IOException("Destination unavailable");
                    byte[] buffer = new byte[32768]; int read;
                    while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                    output.flush();
                    runOnUiThread(() -> {
                        busy = false; result(save.type, true, "文件已保存", save.mode, save.pages, save.pageLimit);
                    });
                } catch (IOException | RuntimeException e) {
                    runOnUiThread(() -> {
                        busy = false; recordError("document_save", 0);
                        result(save.type, false, "保存失败，资料已保留；请换一个位置重试", save.mode, save.pages, save.pageLimit);
                    });
                }
            });
        }
    }

    private void result(String type, boolean ok, String message, String mode) {
        result(type, ok, message, mode, 0, 0);
    }

    private void result(String type, boolean ok, String message, String mode, int pages, int pageLimit) {
        try {
            JSONObject event = new JSONObject().put("type", type).put("ok", ok)
                    .put("message", message).put("mode", mode);
            if ("pdf".equals(type)) event.put("pages", pages).put("pageLimit", pageLimit);
            String json = event.toString();
            if (ready && trusted()) emit(json); else results.add(json);
        } catch (JSONException ignored) { }
    }

    private void emit(String json) {
        web.evaluateJavascript("window.onNativeResult&&window.onNativeResult(" + json + ");", null);
    }

    private void recordError(String code, int line) {
        io.execute(() -> {
            try {
                // Respect the same persisted switch for native and JavaScript errors.
                synchronized (stateLock) {
                    AtomicFile state = new AtomicFile(new File(getFilesDir(), "resume-state.json"));
                    try {
                        JSONObject saved = new JSONObject(new String(state.readFully(), StandardCharsets.UTF_8));
                        if (!saved.optBoolean("diagnosticsEnabled", true)) return;
                    } catch (IOException | JSONException ignored) { }
                }
                File file = new File(getFilesDir(), "diagnostics.jsonl");
                if (file.length() > 49152) new FileOutputStream(file).close();
                JSONObject data = new JSONObject().put("version", appVersion()).put("api", Build.VERSION.SDK_INT)
                        .put("code", code).put("line", line).put("time", System.currentTimeMillis());
                try (FileOutputStream stream = new FileOutputStream(file, true)) {
                    stream.write((data.toString() + "\n").getBytes(StandardCharsets.UTF_8));
                }
            } catch (IOException | JSONException ignored) { }
        });
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        if (pendingSave != null) {
            state.putString("saveFile", pendingSave.file.getAbsolutePath());
            state.putString("saveMime", pendingSave.mime);
            state.putString("saveType", pendingSave.type);
            state.putString("saveMode", pendingSave.mode);
            state.putInt("savePages", pendingSave.pages);
            state.putInt("savePageLimit", pendingSave.pageLimit);
        }
    }

    private void restorePending(Bundle state) {
        String path = state.getString("saveFile");
        if (path == null) return;
        try {
            File file = new File(path).getCanonicalFile();
            File root = new File(getCacheDir(), "shared").getCanonicalFile();
            if (file.isFile() && file.getPath().startsWith(root.getPath() + File.separator)) {
                String type = state.getString("saveType", "pdf");
                int pages = state.getInt("savePages", 0);
                int limit = state.getInt("savePageLimit", 0);
                if ("pdf".equals(type) && (pages < 1 || pages > limit || (limit != 1 && limit != 2))) {
                    result("pdf", false, "导出状态已过期，请重新生成 PDF；资料已保留", "save", pages, limit);
                    return;
                }
                pendingSave = new PendingSave(file, state.getString("saveMime", "application/pdf"),
                        type, state.getString("saveMode", "save"), pages, limit);
                busy = true;
            }
        } catch (IOException ignored) { }
    }

    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){if(typeof window.onNativeBack==='function')return window.onNativeBack()===true;"
                + "if(window.history.length>1){window.history.back();return true;}return false;})()",
                handled -> { if (!"true".equals(handled)) MainActivity.super.onBackPressed(); });
    }

    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onPause() {
        if (web != null) {
            web.evaluateJavascript("window.onNativePause&&window.onNativePause();", null);
            web.onPause();
        }
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (pdf != null) pdf.cancel();
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (web != null) { web.removeJavascriptInterface("Native"); web.destroy(); web = null; }
        io.shutdown();
        super.onDestroy();
    }
}
