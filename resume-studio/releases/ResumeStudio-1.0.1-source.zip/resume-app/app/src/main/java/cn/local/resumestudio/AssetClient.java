package cn.local.resumestudio;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Fixed HTTPS origin served exclusively from APK assets; it never resolves a host. */
final class AssetClient extends WebViewClient {
    static final String ORIGIN = "https://resume.local/";
    private final Context context;
    private final Runnable ready;

    AssetClient(Context context, Runnable ready) {
        this.context = context;
        this.ready = ready;
    }

    static boolean isLocal(Uri uri) {
        return uri != null && "https".equals(uri.getScheme())
                && "resume.local".equals(uri.getHost())
                && (uri.getPort() == -1 || uri.getPort() == 443)
                && uri.getUserInfo() == null;
    }

    @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return !isLocal(request.getUrl());
    }

    @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return !isLocal(Uri.parse(url));
    }

    @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        return response(request.getUrl());
    }

    @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
        return response(Uri.parse(url));
    }

    WebResourceResponse response(Uri uri) {
        if (!isLocal(uri)) return error(403, "Forbidden");
        String path = uri.getPath();
        if (path == null || path.equals("/")) path = "/index.html";
        if (!path.startsWith("/") || path.contains("\\") || path.contains("\u0000")
                || path.contains("%") || path.contains("//")) return error(403, "Forbidden");
        for (String segment : path.split("/")) {
            if (segment.equals(".") || segment.equals("..")) return error(403, "Forbidden");
        }
        String mime = mime(path);
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        headers.put("X-Content-Type-Options", "nosniff");
        headers.put("Access-Control-Allow-Origin", "https://resume.local");
        headers.put("Cross-Origin-Resource-Policy", "same-origin");
        try {
            return new WebResourceResponse(mime, isText(mime) ? "UTF-8" : null,
                    200, "OK", headers, context.getAssets().open(path.substring(1)));
        } catch (IOException e) {
            return error(404, "Not Found");
        }
    }

    @Override public void onPageFinished(WebView view, String url) {
        if (ready != null && isLocal(Uri.parse(url))) ready.run();
    }

    private static WebResourceResponse error(int status, String reason) {
        return new WebResourceResponse("text/plain", "UTF-8", status, reason,
                Collections.singletonMap("Cache-Control", "no-store"),
                new ByteArrayInputStream(new byte[0]));
    }

    private static boolean isText(String mime) {
        return mime.startsWith("text/") || mime.equals("application/javascript")
                || mime.equals("application/json") || mime.equals("image/svg+xml");
    }

    private static String mime(String name) {
        String p = name.toLowerCase(Locale.ROOT);
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".json") || p.endsWith(".map")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        if (p.endsWith(".otf")) return "font/otf";
        if (p.endsWith(".pdf")) return "application/pdf";
        if (p.endsWith(".wasm")) return "application/wasm";
        if (p.endsWith(".txt") || p.endsWith(".md")) return "text/plain";
        return "application/octet-stream";
    }
}
