package cn.local.resumestudio;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/** A narrowly scoped, read-only PDF provider without external-storage permissions. */
public final class ResumeFileProvider extends ContentProvider {
    static final String AUTHORITY = "cn.local.resumestudio.exports";

    @Override public boolean onCreate() { return true; }

    static Uri uriFor(File file) {
        return new Uri.Builder().scheme("content").authority(AUTHORITY)
                .appendPath("pdf").appendPath(file.getParentFile().getName())
                .appendPath(file.getName()).build();
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        List<String> p = uri.getPathSegments();
        if (!AUTHORITY.equals(uri.getAuthority()) || p.size() != 3 || !"pdf".equals(p.get(0))
                || !p.get(1).matches("[a-f0-9-]{36}") || !p.get(2).endsWith(".pdf")
                || p.get(2).contains("/") || p.get(2).contains("\\")) {
            throw new FileNotFoundException("Invalid export");
        }
        try {
            File root = new File(getContext().getCacheDir(), "shared").getCanonicalFile();
            File file = new File(new File(root, p.get(1)), p.get(2)).getCanonicalFile();
            if (!file.getPath().startsWith(root.getPath() + File.separator) || !file.isFile())
                throw new FileNotFoundException("Export unavailable");
            return file;
        } catch (IOException e) {
            throw new FileNotFoundException("Export unavailable");
        }
    }

    @Override public String getType(Uri uri) { return "application/pdf"; }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        try {
            File file = resolve(uri);
            String[] columns = projection == null
                    ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
            MatrixCursor c = new MatrixCursor(columns, 1);
            Object[] row = new Object[columns.length];
            for (int i = 0; i < columns.length; i++) {
                if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) row[i] = file.getName();
                else if (OpenableColumns.SIZE.equals(columns[i])) row[i] = file.length();
            }
            c.addRow(row);
            return c;
        } catch (FileNotFoundException e) { return null; }
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Read access only");
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
}
