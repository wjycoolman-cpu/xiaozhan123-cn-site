package android.print;

/**
 * SDK stubs hide these constructors; AOSP runtime exposes their public,
 * UnsupportedAppUsage-marked constructors. No reflection or system changes.
 * This adapter is exercised on the target Android runtime before delivery.
 */
public final class ResumePrintCallbacks {
    private ResumePrintCallbacks() { }
    public abstract static class Layout extends PrintDocumentAdapter.LayoutResultCallback {
        public Layout() { super(); }
    }
    public abstract static class Write extends PrintDocumentAdapter.WriteResultCallback {
        public Write() { super(); }
    }
}
