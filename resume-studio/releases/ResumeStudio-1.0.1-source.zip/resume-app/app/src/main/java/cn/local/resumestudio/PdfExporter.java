package cn.local.resumestudio;

import android.content.Context;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.ResumePrintCallbacks;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One print transaction owns its WebView, adapter and descriptor until completion. */
final class PdfExporter {
    interface Listener { void finished(boolean ok, String reason, int pages, int pageLimit); }
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final WebView printView;
    private final File target;
    private final Listener listener;
    private final int pageLimit;
    private final ExecutorService verifier = Executors.newSingleThreadExecutor();
    private final CancellationSignal cancellation = new CancellationSignal();
    private PrintDocumentAdapter adapter;
    private ParcelFileDescriptor descriptor;
    private boolean started;
    private boolean complete;
    private int pageCount;
    private final Runnable timeout = () -> finish(false, "PDF 生成超时，请缩小照片或稍后重试");

    PdfExporter(Context context, File target, int pageLimit, Listener listener) {
        if (pageLimit != 1 && pageLimit != 2) throw new IllegalArgumentException("Page limit must be 1 or 2");
        this.target = target;
        this.listener = listener;
        this.pageLimit = pageLimit;
        printView = new WebView(context);
        printView.getSettings().setJavaScriptEnabled(false);
        printView.getSettings().setAllowFileAccess(false);
        printView.getSettings().setAllowContentAccess(false);
        printView.getSettings().setBlockNetworkLoads(true);
        printView.getSettings().setDefaultTextEncodingName("UTF-8");
        // This generated document is entirely inline. AssetClient intentionally
        // rejects data: navigation and must not intercept WebView's loadData URL.
        // Network, files, content access and JavaScript stay disabled here.
        printView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (started || complete) return;
                started = true;
                handler.postDelayed(PdfExporter.this::print, 150);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   WebResourceError error) {
                if (request.isForMainFrame()) finish(false, "简历排版未能加载，请重试");
            }
        });
    }

    void start(String html) {
        handler.postDelayed(timeout, 30000);
        // Exactly the preview's complete HTML; no raster screenshot conversion.
        printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    private void print() {
        if (complete) return;
        try {
            adapter = printView.createPrintDocumentAdapter(target.getName());
            PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asPortrait())
                    .setResolution(new PrintAttributes.Resolution("resume", "简历PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR).build();
            adapter.onStart();
            adapter.onLayout(null, attributes, cancellation, new ResumePrintCallbacks.Layout() {
                @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) { handler.post(PdfExporter.this::write); }
                @Override public void onLayoutFailed(CharSequence error) { handler.post(() -> finish(false, "PDF 排版失败，请重试")); }
                @Override public void onLayoutCancelled() { handler.post(() -> finish(false, "已取消 PDF 生成，资料已保留")); }
            }, new Bundle());
        } catch (RuntimeException | LinkageError e) { finish(false, "当前系统无法生成 PDF，请重试"); }
    }

    private void write() {
        if (complete) return;
        try {
            descriptor = ParcelFileDescriptor.open(target, ParcelFileDescriptor.MODE_CREATE
                    | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_READ_WRITE);
            adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, descriptor, cancellation,
                    new ResumePrintCallbacks.Write() {
                        @Override public void onWriteFinished(PageRange[] pages) {
                            handler.post(PdfExporter.this::verifyPages);
                        }
                        @Override public void onWriteFailed(CharSequence error) { handler.post(() -> finish(false, "PDF 写入失败，请重试")); }
                        @Override public void onWriteCancelled() { handler.post(() -> finish(false, "已取消 PDF 生成，资料已保留")); }
                    });
        } catch (IOException | RuntimeException | LinkageError e) { finish(false, "PDF 无法写入，请检查可用空间后重试"); }
    }

    private void verifyPages() {
        if (complete) return;
        try {
            // Finish the write before reopening this exact completed PDF read-only.
            if (descriptor != null) { descriptor.close(); descriptor = null; }
            if (!target.isFile() || target.length() <= 100) {
                finish(false, "PDF 写入不完整，请重试；资料已保留");
                return;
            }
        } catch (IOException | RuntimeException e) {
            finish(false, "PDF 无法完成写入，请重试；资料已保留");
            return;
        }
        verifier.execute(() -> {
            int actualPages = 0;
            boolean readable = false;
            try {
                actualPages = readPageCount(target);
                readable = actualPages > 0;
            } catch (IOException | RuntimeException | LinkageError ignored) { }
            final int pages = actualPages;
            final boolean valid = readable;
            handler.post(() -> {
                if (complete) return;
                pageCount = pages;
                if (!valid) finish(false, "PDF 页数无法核验，请重试；资料已保留");
                else if (pages > pageLimit) {
                    String action = pageLimit == 1 ? "请精简内容或改为两页" : "请精简内容后重试";
                    finish(false, "当前资料有" + pages + "页，目标" + pageLimit + "页，" + action);
                } else finish(true, "PDF 已生成，共" + pages + "页");
            });
        });
    }

    private static int readPageCount(File file) throws IOException {
        ParcelFileDescriptor input = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        try {
            // PdfRenderer takes ownership after construction. Closing it closes
            // that read descriptor; only a failed constructor leaves us the FD.
            try (PdfRenderer renderer = new PdfRenderer(input)) {
                input = null;
                return renderer.getPageCount();
            }
        } finally {
            if (input != null) input.close();
        }
    }

    void cancel() { finish(false, "已取消 PDF 生成，资料已保留"); }

    private void finish(boolean ok, String reason) {
        if (complete) return;
        complete = true;
        handler.removeCallbacks(timeout);
        verifier.shutdownNow();
        if (!ok) cancellation.cancel();
        if (descriptor != null) {
            try { descriptor.close(); } catch (IOException ignored) { }
            descriptor = null;
        }
        if (adapter != null) {
            try { adapter.onFinish(); } catch (RuntimeException ignored) { }
        }
        printView.stopLoading();
        printView.destroy();
        if (!ok && target.isFile()) target.delete();
        listener.finished(ok, reason, pageCount, pageLimit);
    }
}
