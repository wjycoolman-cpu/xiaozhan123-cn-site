@echo off
setlocal
set "RESUME_PYTHON=C:\Users\28688\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not exist "%RESUME_PYTHON%" set "RESUME_PYTHON=python"
"%RESUME_PYTHON%" "%~dp0build.py" %*
exit /b %errorlevel%
