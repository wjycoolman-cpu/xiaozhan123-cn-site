"""Offline Android build with SDK tools and JDK 17; no Gradle or downloads.

Example: python build.py --variant both
Signing key stays outside the project in ../signing. Its password is protected
with Windows DPAPI for the current Windows user and is never printed.
"""
from __future__ import annotations
import argparse
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import secrets
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent

class Blob(ctypes.Structure):
    _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]

def dpapi(value: bytes, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise RuntimeError("This local signing profile uses Windows DPAPI")
    buffer = (ctypes.c_ubyte * len(value)).from_buffer_copy(value)
    source = Blob(len(value), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    output = Blob()
    crypto = ctypes.windll.crypt32
    if decrypt:
        success = crypto.CryptUnprotectData(ctypes.byref(source), None, None, None,
                                            None, 1, ctypes.byref(output))
    else:
        success = crypto.CryptProtectData(ctypes.byref(source), "Resume Studio local signing",
                                          None, None, None, 1, ctypes.byref(output))
    if not success:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.data, output.size)
    finally:
        ctypes.windll.kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        ctypes.windll.kernel32.LocalFree(output.data)

def run(executable: Path, *args: str | Path, env=None):
    subprocess.run([str(executable), *(str(a) for a in args)], check=True, env=env)

def build(args):
    sdk = Path(args.sdk)
    jdk = Path(args.jdk)
    tools = sdk / "build-tools/35.0.0"
    platform = sdk / "platforms/android-35/android.jar"
    java, javac, jar, keytool = [jdk / f"bin/{name}.exe" for name in ("java", "javac", "jar", "keytool")]
    aapt, align = tools / "aapt2.exe", tools / "zipalign.exe"
    for required in (platform, java, javac, jar, aapt, align):
        if not required.is_file():
            raise FileNotFoundError(f"Required build tool missing: {required}")
    env = dict(os.environ)
    signing = Path(args.signing).resolve() if args.signing else ROOT.parent / "signing"
    key = signing / "resume-studio.p12"
    protected = signing / "resume-studio.dpapi.bin"
    if not args.compile_only:
        signing.mkdir(parents=True, exist_ok=True)
        if protected.is_file():
            password = dpapi(protected.read_bytes(), decrypt=True).decode("utf-8")
        elif key.is_file():
            raise RuntimeError("Existing signing key is missing its password. Recover it; do not replace the key.")
        else:
            password = secrets.token_urlsafe(32)
            protected.write_bytes(dpapi(password.encode("utf-8")))
        env["RESUME_SIGNING_PASS"] = password
        if not key.is_file():
            run(keytool, "-genkeypair", "-keystore", key, "-storetype", "PKCS12",
                "-alias", "resume", "-keyalg", "RSA", "-keysize", "3072", "-validity", "10000",
                "-dname", "CN=Offline Resume Studio, OU=Local Apps, O=Personal, C=CN",
                "-storepass:env", "RESUME_SIGNING_PASS", "-keypass:env", "RESUME_SIGNING_PASS",
                "-noprompt", env=env)
    variants = ["debug", "release"] if args.variant == "both" else [args.variant]
    for variant in variants:
        out = ROOT / "build" / variant
        generated, classes, dex = [out / name for name in ("generated", "classes", "dex")]
        for directory in (out, generated, classes, dex):
            directory.mkdir(parents=True, exist_ok=True)
        manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        if variant == "debug":
            manifest = manifest.replace('android:debuggable="false"', 'android:debuggable="true"')
        manifest_path = out / "AndroidManifest.xml"
        manifest_path.write_text(manifest, encoding="utf-8")
        compiled = out / "resources.zip"
        run(aapt, "compile", "--dir", ROOT / "app/src/main/res", "-o", compiled)
        unsigned = out / "unsigned.apk"
        link = ["link", "-o", unsigned, "-I", platform, "--manifest", manifest_path,
                "-R", compiled, "--java", generated, "--min-sdk-version", "26",
                "--target-sdk-version", "35", "--auto-add-overlay"]
        if (ROOT / "app/src/main/assets").is_dir():
            link += ["-A", ROOT / "app/src/main/assets"]
        run(aapt, *link)
        sources = sorted((ROOT / "app/src/main/java").rglob("*.java")) + sorted(generated.rglob("*.java"))
        run(javac, "--release", "8", "-encoding", "UTF-8", "-classpath", platform,
            "-d", classes, "-g" if variant == "debug" else "-g:none", *sources)
        if args.compile_only:
            print(f"Java compilation passed: {variant}", flush=True)
            continue
        classes_jar = out / "classes.jar"
        run(jar, "cf", classes_jar, "-C", classes, ".")
        run(java, "-cp", tools / "lib/d8.jar", "com.android.tools.r8.D8", "--min-api", "26",
            "--lib", platform, "--output", dex, classes_jar)
        # Rebuild the central directory instead of appending through zipfile:
        # aapt2 uses ZIP header flags that zipfile otherwise normalizes only in
        # the central header, causing Android zipalign header-mismatch warnings.
        normalized = out / "normalized.apk"
        with zipfile.ZipFile(unsigned, "r") as source, zipfile.ZipFile(normalized, "w") as archive:
            for entry in source.infolist():
                info = zipfile.ZipInfo(entry.filename, entry.date_time)
                info.compress_type = zipfile.ZIP_STORED if entry.filename == "resources.arsc" else entry.compress_type
                info.external_attr = entry.external_attr
                archive.writestr(info, source.read(entry.filename))
            for file in sorted(dex.glob("*.dex")):
                archive.write(file, file.name, compress_type=zipfile.ZIP_DEFLATED)
        normalized.replace(unsigned)
        aligned = out / "aligned.apk"
        run(align, "-f", "-p", "4", unsigned, aligned)
        final = out / f"ResumeStudio-1.0.1-{variant}.apk"
        run(java, "-jar", tools / "lib/apksigner.jar", "sign", "--ks", key, "--ks-key-alias", "resume",
            "--ks-pass", "env:RESUME_SIGNING_PASS", "--key-pass", "env:RESUME_SIGNING_PASS",
            "--out", final, aligned, env=env)
        run(java, "-jar", tools / "lib/apksigner.jar", "verify", "--verbose", final)
        run(align, "-c", "-p", "4", final)
        print(f"Built: {final}", flush=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=["debug", "release", "both"], default="both")
    parser.add_argument("--sdk", default=r"D:\Android\Sdk")
    parser.add_argument("--jdk", default=r"D:\Unity\Editor\6000.3.20f1-x86_64\Editor\Data\PlaybackEngines\AndroidPlayer\OpenJDK")
    parser.add_argument("--signing", default="")
    parser.add_argument("--compile-only", action="store_true")
    build(parser.parse_args())
