@echo off
setlocal
set "compiler=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%compiler%" (
  echo Install Microsoft .NET Framework 4.8 on Windows x64 first.
  exit /b 1
)
if not exist "%~dp0dist" mkdir "%~dp0dist"
"%compiler%" /nologo /target:winexe /platform:x64 /optimize+ /warn:4 /langversion:5 ^
 /out:"%~dp0dist\StardewFarmAssistantManager.exe" ^
 /win32icon:"%~dp0Manager\farm-manager.ico" ^
 /win32manifest:"%~dp0Manager\manager.manifest" ^
 /resource:"%~dp0Manager\payload-hashes.json",payload-hashes.json ^
 /reference:System.dll /reference:System.Core.dll /reference:System.Windows.Forms.dll ^
 /reference:System.Drawing.dll /reference:System.Web.Extensions.dll ^
 /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll /reference:System.Security.dll ^
 "%~dp0Manager\ManagerBackend.cs" "%~dp0Manager\ManagerForm.cs" "%~dp0Manager\Program.cs"
if errorlevel 1 exit /b 1
xcopy /E /I /Y "%~dp0PlayerPayload\FarmAssistantMod" "%~dp0dist\FarmAssistantMod" >nul
if errorlevel 1 exit /b 1
copy /Y "%~dp0Manager\README-player.md" "%~dp0dist\README-player.md" >nul
copy /Y "%~dp0Manager\THIRD-PARTY-NOTICES.md" "%~dp0dist\THIRD-PARTY-NOTICES.md" >nul
copy /Y "%~dp0Manager\LICENSE.txt" "%~dp0dist\LICENSE.txt" >nul
copy /Y "%~dp0PlayerPayload\StardewFarmAssistantManager.exe.config" "%~dp0dist\StardewFarmAssistantManager.exe.config" >nul
echo Built dist\StardewFarmAssistantManager.exe
exit /b 0
