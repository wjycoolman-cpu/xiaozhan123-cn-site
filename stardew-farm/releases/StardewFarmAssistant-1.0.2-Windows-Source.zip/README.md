# 配置器源码

Windows 配置器 1.0.0，C# 5 / .NET Framework 4.8 / WinForms，原创 MIT 代码与几何图标。

## 编译

在 Windows 10/11 x64 安装 .NET Framework 4.8，解压此源码包后运行根目录的 `Build.cmd`。使用 Windows 自带 Framework 编译器，不需要 Python 或游戏 DLL。结果在 `dist`，保留整个目录即可运行或分发。

- `Manager`：配置器源码、图标、资源、许可与玩家说明。
- `PlayerPayload/FarmAssistantMod`：本项目 1.0.2 的原创安装载荷；不包含游戏或 SMAPI 二进制。
- `ModSource`：1.0.2 原创农场模组源码。编译模组需要自己合法安装的游戏和 SMAPI，按该工程说明指定 GamePath。

修改安装载荷后，必须重新计算每个白名单文件的 SHA-256，更新 `Manager/payload-hashes.json`，再编译配置器。不要把他人的清单或任意文件加入卸载名单。模组身份为 `LocalTools.StardewFarmAssistant`；改变模组版本时同时调整配置器中的 ModVersion，并核对模组程序集和 manifest 版本一致。

管理器的官方依赖下载固定到 SMAPI 4.5.2，并内置官方 ZIP 的 SHA-256。更新依赖时应从官方固定版本 Release 验证内容、散列与许可，再改变代码；不能只替换下载 URL 或跳过校验。现有兼容的共享 SMAPI 不降级；现有旧版本或不完整的 SMAPI 使用官方修复流程。

测试用的游戏文件、存档、日志、临时目录、私人路径与 SMAPI 官方安装包不在此源码包内。原生游戏长期验收及不同电脑兼容性应分别验证。没有公开上传、签名更新源或反馈服务器。
