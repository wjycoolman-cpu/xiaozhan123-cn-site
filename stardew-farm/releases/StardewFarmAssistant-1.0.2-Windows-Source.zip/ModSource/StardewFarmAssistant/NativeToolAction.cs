using Microsoft.Xna.Framework;
using StardewValley;
using StardewValley.TerrainFeatures;
using StardewValley.Tools;

namespace StardewFarmAssistant;

/// <summary>Owns one real tool swing, whose native animation applies the effect.</summary>
public sealed class NativeToolAction
{
    private readonly ModEntry owner;
    private readonly Farm farm;
    private readonly Tool tool;
    private readonly DateTime started = DateTime.UtcNow;
    private readonly float originalModifier;
    private int frames;
    private bool sawTool;
    private bool released;
    private bool speedRestored;
    private bool animationTimed;
    private readonly Tree? treeBefore;
    private readonly float treeHealthBefore;
    private readonly bool treeStumpBefore;
    private readonly bool treeFallingBefore;
    private readonly Grass? grassBefore;
    private readonly int grassCountBefore;
    public Vector2 Tile { get; }
    public string Kind { get; }
    public float StaminaBefore { get; }
    public int WaterBefore { get; }
    public bool Succeeded { get; private set; }

    public NativeToolAction(ModEntry owner, Farm farm, Vector2 tile, string kind, Tool tool)
    {
        this.owner = owner; this.farm = farm; Tile = tile; Kind = kind; this.tool = tool;
        farm.terrainFeatures.TryGetValue(tile, out TerrainFeature? feature);
        if (kind == "Chop")
        {
            if (tool is not Axe)
                throw new InvalidOperationException("Chop requires the player's real Axe.");
            treeBefore = feature as Tree
                ?? throw new InvalidOperationException("Chop requires an ordinary Tree terrain feature at the target tile.");
            treeHealthBefore = treeBefore.health.Value;
            treeStumpBefore = treeBefore.stump.Value;
            treeFallingBefore = treeBefore.falling.Value;
        }
        else if (kind == "Clear grass")
        {
            if (tool is not MeleeWeapon weapon || !weapon.isScythe())
                throw new InvalidOperationException("Clear grass requires a real scythe MeleeWeapon.");
            grassBefore = feature as Grass
                ?? throw new InvalidOperationException("Clear grass requires a Grass terrain feature at the target tile.");
            grassCountBefore = grassBefore.numberOfWeeds.Value;
        }
        var who = Game1.player;
        StaminaBefore = who.Stamina;
        WaterBefore = who.Items.OfType<WateringCan>().FirstOrDefault()?.WaterLeft ?? 0;
        originalModifier = who.FarmerSprite.intervalModifier;
        who.Halt(); who.controller = null;
        who.CurrentToolIndex = who.Items.IndexOf(tool);
        who.netItemStowed.Value = false;
        who.faceGeneralDirection(tile * 64f + new Vector2(32));
        who.lastClick = tile * 64f + new Vector2(32);
        who.toolPower.Value = 0; who.toolHold.Value = 0;
        who.BeginUsingTool();
        owner.Status.Activity = kind;
        owner.LogEvidence("tool_started", new { task = kind, tool = tool.ItemId, x = tile.X, y = tile.Y, playerX = who.TilePoint.X, playerY = who.TilePoint.Y, facing = who.FacingDirection, selectedSlot = who.CurrentToolIndex, speed = owner.EffectiveWorkSpeed, mode = owner.Config.WorkMode });
    }

    public bool Update()
    {
        frames++;
        var who = Game1.player;
        if (who.CurrentTool != tool || who.currentLocation != farm)
            throw new InvalidOperationException("The selected tool or location changed during an automatic swing.");
        if (who.UsingTool)
        {
            sawTool = true;
            if (!released && who.canReleaseTool && !who.FarmerSprite.PauseForSingleAnimation)
            { who.EndUsingTool(); released = true; }
            var animation = who.FarmerSprite.CurrentAnimation;
            if (!animationTimed && animation is { Count: > 0 } && who.FarmerSprite.isOnToolAnimation())
            {
                // Keep every native frame and callback. Even 50x leaves a visible
                // swing; only its interval is shortened, never its effect callback.
                double naturalMs = animation.Sum(f => Math.Max(1, f.milliseconds));
                double minimumMs = owner.Config.WorkMode == "showcase" ? 160
                    : Math.Clamp(220 - owner.EffectiveWorkSpeed * 1.5, 70, 220);
                double visibleMs = Math.Max(minimumMs, naturalMs / owner.EffectiveWorkSpeed);
                double ratio = Math.Min(1, visibleMs / naturalMs);
                for (int i = 0; i < animation.Count; i++)
                {
                    var frame = animation[i];
                    frame.milliseconds = Math.Max(12, (int)Math.Round(frame.milliseconds * ratio));
                    animation[i] = frame;
                }
                who.FarmerSprite.interval = who.FarmerSprite.CurrentAnimationFrame.milliseconds;
                animationTimed = true;
                owner.LogEvidence("tool_animation", new { task = Kind, tool = tool.ItemId, naturalMs, visibleMs, nativeFrameCount = animation.Count, firstFrame = who.FarmerSprite.CurrentFrame });
            }
            if (animationTimed && frames == 5) owner.CaptureToolExample(Kind);
            if ((DateTime.UtcNow - started).TotalSeconds > 5)
                throw new InvalidOperationException("Native tool animation did not finish.");
            return false;
        }
        if (!sawTool && frames < 10) return false;
        farm.terrainFeatures.TryGetValue(Tile, out var feature);
        var dirt = feature as HoeDirt;
        bool treeRemoved = treeBefore != null && !ReferenceEquals(feature, treeBefore);
        bool treeHealthReduced = treeBefore != null && ReferenceEquals(feature, treeBefore) && treeBefore.health.Value < treeHealthBefore;
        bool treeBecameStump = treeBefore != null && ReferenceEquals(feature, treeBefore) && !treeStumpBefore && treeBefore.stump.Value;
        bool treeStartedFalling = treeBefore != null && ReferenceEquals(feature, treeBefore) && !treeFallingBefore && treeBefore.falling.Value;
        bool grassRemoved = grassBefore != null && !ReferenceEquals(feature, grassBefore);
        bool grassReduced = grassBefore != null && ReferenceEquals(feature, grassBefore) && grassBefore.numberOfWeeds.Value < grassCountBefore;
        Succeeded = Kind switch
        {
            "Hoe" => dirt != null,
            "Water" => dirt?.state.Value == 1,
            "Refill" => tool is WateringCan can && can.WaterLeft > WaterBefore,
            "Clear" => !farm.objects.ContainsKey(Tile),
            "Clear dead crop" => dirt?.crop == null,
            "Chop" => treeRemoved || treeHealthReduced || treeBecameStump || treeStartedFalling,
            "Clear grass" => grassRemoved || grassReduced,
            _ => false
        };
        owner.LogEvidence("tool_finished", new
        {
            task = Kind,
            tool = tool.ItemId,
            succeeded = Succeeded,
            durationMs = (DateTime.UtcNow - started).TotalMilliseconds,
            renderedFrames = frames,
            staminaBefore = StaminaBefore,
            staminaAfter = who.Stamina,
            tree = treeBefore == null ? null : new
            {
                healthBefore = treeHealthBefore,
                healthAfter = ReferenceEquals(feature, treeBefore) ? treeBefore.health.Value : (float?)null,
                stumpBefore = treeStumpBefore,
                stumpAfter = ReferenceEquals(feature, treeBefore) ? treeBefore.stump.Value : (bool?)null,
                fallingBefore = treeFallingBefore,
                fallingAfter = ReferenceEquals(feature, treeBefore) ? treeBefore.falling.Value : (bool?)null,
                removed = treeRemoved
            },
            grass = grassBefore == null ? null : new
            {
                countBefore = grassCountBefore,
                countAfter = ReferenceEquals(feature, grassBefore) ? grassBefore.numberOfWeeds.Value : (int?)null,
                removed = grassRemoved
            }
        });
        return true;
    }

    public void ReleaseSpeed()
    {
        var who = Game1.player;

        // BeginUsingTool and EndUsingTool are paired native events. Cancellation can
        // happen before the begin event is polled, so UsingTool alone can't tell us
        // whether a release is still owed. Queue the matching native release once
        // while this action still owns the selected tool and location. The game then
        // runs the normal endUsing animation/callback; don't force movement or tool
        // state here, since those may also be owned by a menu, event, or warp.
        bool beginMayStillBeQueued = !sawTool;
        if (!released
            && ReferenceEquals(who.CurrentTool, tool)
            && ReferenceEquals(who.currentLocation, farm)
            && (who.UsingTool || beginMayStillBeQueued))
        {
            who.EndUsingTool();
            released = true;
        }

        if (!speedRestored)
        {
            who.FarmerSprite.intervalModifier = originalModifier;
            speedRestored = true;
        }
    }
}
