using System.Globalization;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Inventories;
using StardewValley.Locations;
using StardewValley.Objects;
using StardewValley.Pathfinding;
using StardewValley.TerrainFeatures;
using SObject = StardewValley.Object;

namespace StardewFarmAssistant;

/// <summary>Crafts and places native scarecrows when managed crops have real crow exposure.</summary>
public sealed class FarmProtection
{
    private const string ScarecrowRecipe = "Scarecrow";
    private const string StorageTag = "LocalTools.StardewFarmAssistant/storage";
    private const int NativeCrowCropThreshold = 16;
    private static readonly Vector2[] Neighbors =
    {
        new(0, 1), new(-1, 0), new(1, 0), new(0, -1)
    };

    private readonly ModEntry owner;

    public FarmProtection(ModEntry owner)
    {
        this.owner = owner ?? throw new ArgumentNullException(nameof(owner));
    }

    /// <summary>
    /// Place at most one native scarecrow. Returns true only after the game has
    /// placed the crafted item and consumed its real recipe ingredients.
    /// </summary>
    public bool TryProtect(Farm farm)
    {
        ArgumentNullException.ThrowIfNull(farm);
        if (!Context.IsWorldReady || Game1.currentLocation != farm)
            return false;

        List<Vector2> managedLivingCrops = owner.Engine.Plots
            .Where(tile => farm.terrainFeatures.TryGetValue(tile, out TerrainFeature? feature)
                && feature is HoeDirt { crop: { } crop }
                && !crop.dead.Value)
            .Distinct()
            .ToList();
        if (managedLivingCrops.Count == 0)
            return false;

        // Farm.addCrows uses all planted HoeDirt and enables the first crow
        // attempt at 16 crops (Math.Min(4, cropCount / 16)).
        int farmCropCount = farm.terrainFeatures.Pairs.Count(pair => pair.Value is HoeDirt { crop: not null });
        if (farmCropCount < NativeCrowCropThreshold)
            return false;

        List<(Vector2 Tile, SObject Scarecrow, int Radius)> existing = farm.objects.Pairs
            .Where(pair => pair.Value.IsScarecrow())
            .Select(pair => (pair.Key, pair.Value, pair.Value.GetRadiusForScarecrow()))
            .ToList();
        List<Vector2> uncovered = managedLivingCrops
            .Where(crop => !existing.Any(scarecrow => IsCovered(crop, scarecrow.Tile, scarecrow.Radius)))
            .ToList();
        if (uncovered.Count == 0)
            return false;

        Farmer who = Game1.player;
        if (!who.craftingRecipes.ContainsKey(ScarecrowRecipe))
        {
            owner.Status.Reason = "Managed crops need crow protection; learn the Scarecrow recipe to automate it";
            return false;
        }

        var recipe = new CraftingRecipe(ScarecrowRecipe, isCookingRecipe: false);
        List<IInventory> materialInventories = FindOwnedReachableStorage(farm, who);
        List<Item> storedItems = materialInventories
            .SelectMany(inventory => inventory)
            .Where(item => item is not null)
            .ToList();
        if (!recipe.doesFarmerHaveIngredientsInInventory(storedItems))
        {
            string missing = string.Join(", ", recipe.recipeList
                .Select(pair => (Id: pair.Key, Missing: Math.Max(0,
                    pair.Value - CountIngredient(pair.Key, who.Items, materialInventories))))
                .Where(pair => pair.Missing > 0)
                .Select(pair => $"{ItemRegistry.Create(pair.Id).DisplayName} x{pair.Missing}"));
            owner.Status.Reason = string.IsNullOrEmpty(missing)
                ? "Managed crops need a Scarecrow, but its real recipe materials are unavailable"
                : $"Managed crops need a Scarecrow; missing {missing}";
            return false;
        }

        if (recipe.createItem() is not SObject crafted || !crafted.IsScarecrow())
        {
            owner.Status.Reason = "Managed crops need crow protection, but the Scarecrow recipe output is unsupported";
            return false;
        }

        int radius = crafted.GetRadiusForScarecrow();
        if (radius <= 0)
        {
            owner.Status.Reason = "Managed crops need crow protection, but the crafted Scarecrow has no coverage radius";
            return false;
        }

        Vector2 center = new(
            uncovered.Average(tile => tile.X),
            uncovered.Average(tile => tile.Y));
        Vector2? placement = FindCandidates(farm, uncovered, radius, center)
            .Take(64)
            .Where(candidate => HasReachableNeighbor(farm, candidate.Tile))
            .Select(candidate => (Vector2?)candidate.Tile)
            .FirstOrDefault();
        if (!placement.HasValue)
        {
            owner.Status.Reason = "Managed crops need a Scarecrow, but no safe reachable placement tile is available nearby";
            return false;
        }

        Dictionary<string, int> before = recipe.recipeList.Keys
            .Distinct(StringComparer.Ordinal)
            .ToDictionary(id => id, id => CountIngredient(id, who.Items, materialInventories), StringComparer.Ordinal);
        Vector2 tile = placement.Value;
        if (!crafted.placementAction(farm, (int)tile.X * 64, (int)tile.Y * 64, who)
            || !farm.objects.TryGetValue(tile, out SObject? placed)
            || !placed.IsScarecrow())
        {
            owner.Status.Reason = "Managed crops need a Scarecrow, but its native placement action was rejected";
            return false;
        }

        recipe.consumeIngredients(materialInventories);
        who.craftingRecipes[ScarecrowRecipe]++;
        Game1.stats.ItemsCrafted++;

        Dictionary<string, int> consumed = before.ToDictionary(
            pair => pair.Key,
            pair => Math.Max(0, pair.Value - CountIngredient(pair.Key, who.Items, materialInventories)),
            StringComparer.Ordinal);
        int coveredBefore = managedLivingCrops.Count - uncovered.Count;
        int newlyCovered = uncovered.Count(crop => IsCovered(crop, tile, radius));
        owner.Status.Activity = "Placed a Scarecrow";
        owner.Status.Reason = "";
        owner.LogEvidence("scarecrow_placed", new
        {
            item = placed.QualifiedItemId,
            position = new { x = tile.X, y = tile.Y },
            materials = consumed,
            materialSources = new { backpack = true, assistantStorageCount = materialInventories.Count },
            radius,
            coverage = new
            {
                farmCropCount,
                managedLiving = managedLivingCrops.Count,
                coveredBefore,
                newlyCovered,
                coveredAfter = coveredBefore + newlyCovered
            }
        });
        return true;
    }

    private List<IInventory> FindOwnedReachableStorage(Farm farm, Farmer who)
    {
        string ownerId = who.UniqueMultiplayerID.ToString(CultureInfo.InvariantCulture);
        var inventories = new List<IInventory>();
        foreach (var pair in farm.objects.Pairs)
        {
            if (pair.Value is not Chest chest
                || !chest.modData.TryGetValue(StorageTag, out string? taggedOwner)
                || !string.Equals(taggedOwner, ownerId, StringComparison.Ordinal)
                || !HasReachableNeighbor(farm, pair.Key))
                continue;
            inventories.Add(chest.GetItemsForPlayer(who.UniqueMultiplayerID));
        }
        return inventories;
    }

    private static int CountIngredient(
        string ingredientId,
        IInventory backpack,
        IEnumerable<IInventory> additionalInventories)
    {
        int count = backpack
            .Where(item => item is not null && CraftingRecipe.ItemMatchesForCrafting(item, ingredientId))
            .Sum(item => item.Stack);
        foreach (IInventory inventory in additionalInventories)
        {
            count += inventory
                .Where(item => item is not null && CraftingRecipe.ItemMatchesForCrafting(item, ingredientId))
                .Sum(item => item.Stack);
        }
        return count;
    }

    private IEnumerable<(Vector2 Tile, int Coverage, float Distance)> FindCandidates(
        Farm farm,
        IReadOnlyList<Vector2> uncovered,
        int radius,
        Vector2 center)
    {
        HashSet<Vector2> protectedPlots = owner.Engine.Plots.ToHashSet();
        int reach = Math.Max(1, radius - 1);
        int minX = Math.Max(1, (int)uncovered.Min(tile => tile.X) - reach);
        int maxX = Math.Min(farm.Map.Layers[0].LayerWidth - 2, (int)uncovered.Max(tile => tile.X) + reach);
        int minY = Math.Max(1, (int)uncovered.Min(tile => tile.Y) - reach);
        int maxY = Math.Min(farm.Map.Layers[0].LayerHeight - 2, (int)uncovered.Max(tile => tile.Y) + reach);

        var candidates = new List<(Vector2 Tile, int Coverage, float Distance)>();
        for (int y = minY; y <= maxY; y++)
        {
            for (int x = minX; x <= maxX; x++)
            {
                Vector2 tile = new(x, y);
                if (protectedPlots.Contains(tile) || !IsSafePlacement(farm, tile))
                    continue;
                int coverage = uncovered.Count(crop => IsCovered(crop, tile, radius));
                if (coverage > 0)
                    candidates.Add((tile, coverage, Vector2.DistanceSquared(tile, center)));
            }
        }

        return candidates
            .OrderByDescending(candidate => candidate.Coverage)
            .ThenBy(candidate => candidate.Distance)
            .ThenBy(candidate => candidate.Tile.Y)
            .ThenBy(candidate => candidate.Tile.X);
    }

    private static bool IsSafePlacement(Farm farm, Vector2 tile)
    {
        var bounds = new Rectangle((int)tile.X * 64, (int)tile.Y * 64, 64, 64);
        return farm.CanItemBePlacedHere(tile)
            && !farm.objects.ContainsKey(tile)
            && !farm.terrainFeatures.ContainsKey(tile)
            && farm.getBuildingAt(tile) is null
            && !farm.resourceClumps.Any(clump => clump.getBoundingBox().Intersects(bounds));
    }

    private static bool HasReachableNeighbor(Farm farm, Vector2 tile)
    {
        Farmer who = Game1.player;
        foreach (Vector2 neighbor in Neighbors
                     .Select(delta => tile + delta)
                     .OrderBy(point => Vector2.DistanceSquared(point, who.Tile)))
        {
            if (!IsWalkable(farm, neighbor))
                continue;
            if (who.TilePoint == neighbor.ToPoint())
                return true;
            var path = new PathFindController(who, farm, neighbor.ToPoint(), who.FacingDirection);
            if (path.pathToEndPoint is { Count: > 0 })
                return true;
        }
        return false;
    }

    private static bool IsWalkable(Farm farm, Vector2 tile)
    {
        int x = (int)tile.X;
        int y = (int)tile.Y;
        if (x < 0 || y < 0 || x >= farm.Map.Layers[0].LayerWidth || y >= farm.Map.Layers[0].LayerHeight)
            return false;
        if (!farm.isTileLocationOpen(tile)
            || farm.objects.ContainsKey(tile)
            || farm.getBuildingAt(tile) is not null)
            return false;
        if (farm.terrainFeatures.TryGetValue(tile, out TerrainFeature? feature) && feature is not HoeDirt)
            return false;
        var bounds = new Rectangle(x * 64, y * 64, 64, 64);
        return !farm.resourceClumps.Any(clump => clump.getBoundingBox().Intersects(bounds));
    }

    private static bool IsCovered(Vector2 crop, Vector2 scarecrow, int radius)
        => radius > 0 && Vector2.DistanceSquared(crop, scarecrow) < radius * radius;
}
