using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace StardewFarmAssistant.Planning;

public record CropOption(
    string SeedId,
    string Name,
    int SeedPrice,
    int SalePrice,
    double ExpectedYield,
    int GrowthDays,
    int RegrowDays,
    int Stock,
    bool IsTrellis);

public record CropEvaluation(
    CropOption Crop,
    int Harvests,
    double ExpectedRevenue,
    double ExpectedProfit,
    double Score);

public record CropAllocation(CropOption Crop, int Quantity);

public record PlantingPlan(
    IReadOnlyList<CropEvaluation> Rankings,
    IReadOnlyList<CropAllocation> Purchases,
    double ExpectedProfit,
    int Spent,
    string Explanation);

/// <summary>
/// Builds a conservative, season-horizon crop plan from already-resolved game data.
/// Quantities represent seeds to buy now and plots to plant now. Spent is the
/// immediate purchase cost. For non-regrowing crops, projected profit includes
/// later replant costs, but those future purchases are replanned when due.
/// </summary>
public static class CropPlanner
{
    public const int MaximumBudget = 100_000;
    public const int MaximumPlots = 120;

    private const double Epsilon = 0.0000001;
    private const int SearchTimeLimitMilliseconds = 20;

    public static PlantingPlan Plan(
        IEnumerable<CropOption> crops,
        int daysRemaining,
        int budget,
        int maxPlots,
        string objective = "balanced")
    {
        ArgumentNullException.ThrowIfNull(crops);

        if (budget < 0)
            throw new ArgumentOutOfRangeException(nameof(budget), "Budget cannot be negative.");
        if (maxPlots < 0)
            throw new ArgumentOutOfRangeException(nameof(maxPlots), "Plot count cannot be negative.");
        if (budget > MaximumBudget)
            throw new ArgumentOutOfRangeException(nameof(budget), $"Budget must be at most {MaximumBudget:N0}.");
        if (maxPlots > MaximumPlots)
            throw new ArgumentOutOfRangeException(nameof(maxPlots), $"Plot count must be at most {MaximumPlots}.");

        string normalizedObjective = string.Equals(objective, "seasonProfit", StringComparison.OrdinalIgnoreCase)
            ? "seasonProfit"
            : "balanced";

        List<Candidate> candidates = crops
            .Where(crop => IsEligible(crop, daysRemaining))
            .Select(crop => Evaluate(crop, daysRemaining, normalizedObjective, maxPlots))
            .Where(candidate => candidate.MaximumQuantity > 0)
            .ToList();

        CropEvaluation[] rankings = candidates
            .Select(candidate => candidate.Evaluation)
            .OrderByDescending(evaluation => evaluation.Score)
            .ThenByDescending(evaluation => evaluation.ExpectedProfit)
            .ThenBy(evaluation => evaluation.Crop.Name, StringComparer.Ordinal)
            .ToArray();

        if (daysRemaining <= 0 || budget == 0 || maxPlots == 0 || candidates.Count == 0)
            return EmptyPlan(rankings, normalizedObjective, daysRemaining, budget, maxPlots);

        AllocationResult allocation = Allocate(candidates, budget, maxPlots);

        CropAllocation[] purchases = allocation.Quantities
            .Select((quantity, index) => new { quantity, index })
            .Where(entry => entry.quantity > 0)
            .Select(entry => new CropAllocation(candidates[entry.index].Evaluation.Crop, entry.quantity))
            .OrderByDescending(purchase => candidates.Find(candidate => ReferenceEquals(candidate.Evaluation.Crop, purchase.Crop))?.Evaluation.Score ?? 0)
            .ThenBy(purchase => purchase.Crop.Name, StringComparer.Ordinal)
            .ToArray();

        string proof = allocation.Completed
            ? "The bounded allocation search completed and proved the best score for the supplied discrete model."
            : $"The bounded search reached its {SearchTimeLimitMilliseconds}ms work limit; this is the best feasible allocation found, without an optimality proof.";
        string explanation =
            $"Objective={normalizedObjective}; allocated {allocation.Plots} of {maxPlots} plots and forecast {allocation.Spent}g " +
            $"in seeds to buy and plant now, with {daysRemaining} remaining days. Projected profit includes future replant seed costs, " +
            "but future purchases depend on later cash and are replanned when due. " + proof +
            " The forecast cannot know future unlocks and remains an optimization of the current discrete model, not a guarantee of whole-game global optimality.";

        return new PlantingPlan(rankings, purchases, allocation.ExpectedProfit, allocation.Spent, explanation);
    }

    private static bool IsEligible(CropOption crop, int daysRemaining)
    {
        return crop is not null
            && !crop.IsTrellis
            && crop.GrowthDays > 0
            && crop.GrowthDays <= daysRemaining
            && crop.SeedPrice > 0
            && crop.SalePrice > 0
            && crop.ExpectedYield > 0
            && crop.Stock != 0;
    }

    private static Candidate Evaluate(CropOption crop, int daysRemaining, string objective, int maxPlots)
    {
        int harvests;
        int seedCycles;

        if (crop.RegrowDays > 0)
        {
            harvests = 1 + ((daysRemaining - crop.GrowthDays) / crop.RegrowDays);
            seedCycles = 1;
        }
        else
        {
            harvests = daysRemaining / crop.GrowthDays;
            seedCycles = harvests;
        }

        long forecastSeedCost = (long)crop.SeedPrice * seedCycles;
        double expectedRevenue = crop.SalePrice * crop.ExpectedYield * harvests;
        double expectedProfit = expectedRevenue - forecastSeedCost;

        double score;
        if (objective == "seasonProfit")
        {
            score = expectedProfit;
        }
        else
        {
            double firstHarvestProfit = (crop.SalePrice * crop.ExpectedYield) - crop.SeedPrice;
            double capitalVelocity = firstHarvestProfit / crop.GrowthDays;
            score = (expectedProfit * 0.75) + (capitalVelocity * daysRemaining * 0.25);
        }

        int maximumQuantity = crop.Stock < 0
            ? maxPlots
            : Math.Min(maxPlots, crop.Stock);

        return new Candidate(
            new CropEvaluation(crop, harvests, expectedRevenue, expectedProfit, score),
            UpfrontSeedCost: crop.SeedPrice,
            maximumQuantity);
    }

    private static PlantingPlan EmptyPlan(
        IReadOnlyList<CropEvaluation> rankings,
        string objective,
        int daysRemaining,
        int budget,
        int maxPlots)
    {
        return new PlantingPlan(
            rankings,
            Array.Empty<CropAllocation>(),
            ExpectedProfit: 0,
            Spent: 0,
            Explanation: $"Objective={objective}; no allocation is feasible for days={daysRemaining}, budget={budget}, plots={maxPlots}. " +
                         "This is a rolling estimate rather than a guarantee of whole-game global optimality.");
    }

    private static AllocationResult Allocate(IReadOnlyList<Candidate> allCandidates, int budget, int maxPlots)
    {
        var ordered = allCandidates
            .Select((candidate, originalIndex) => new SolverCandidate(candidate, originalIndex))
            .Where(entry => entry.Candidate.Evaluation.Score > Epsilon
                && entry.Candidate.UpfrontSeedCost > 0
                && entry.Candidate.UpfrontSeedCost <= budget)
            .OrderByDescending(entry => entry.Candidate.Evaluation.Score / entry.Candidate.UpfrontSeedCost)
            .ThenByDescending(entry => entry.Candidate.Evaluation.Score)
            .ToArray();

        if (ordered.Length == 0)
            return new AllocationResult(new int[allCandidates.Count], 0, 0, 0, Completed: true);

        int[] current = new int[ordered.Length];
        int[] best = new int[ordered.Length];
        double bestScore = 0;
        double bestProfit = 0;
        int bestSpent = 0;
        int bestPlots = 0;

        // Establish a useful incumbent immediately, so a timed-out search still
        // returns a valid deterministic plan.
        int greedyBudget = budget;
        int greedyPlots = maxPlots;
        for (int index = 0; index < ordered.Length; index++)
        {
            Candidate candidate = ordered[index].Candidate;
            int cost = candidate.UpfrontSeedCost;
            int quantity = Math.Min(candidate.MaximumQuantity, Math.Min(greedyPlots, greedyBudget / cost));
            best[index] = quantity;
            greedyPlots -= quantity;
            greedyBudget -= quantity * cost;
            bestScore += quantity * candidate.Evaluation.Score;
            bestProfit += quantity * candidate.Evaluation.ExpectedProfit;
            bestSpent += quantity * cost;
            bestPlots += quantity;
        }

        double[] maximumScoreInSuffix = new double[ordered.Length + 1];
        for (int index = ordered.Length - 1; index >= 0; index--)
            maximumScoreInSuffix[index] = Math.Max(maximumScoreInSuffix[index + 1], ordered[index].Candidate.Evaluation.Score);

        Stopwatch stopwatch = Stopwatch.StartNew();
        long visited = 0;
        bool completed = true;

        Search(index: 0, remainingBudget: budget, remainingPlots: maxPlots, score: 0, expectedProfit: 0, spent: 0, plots: 0);

        int[] quantities = new int[allCandidates.Count];
        for (int index = 0; index < ordered.Length; index++)
            quantities[ordered[index].OriginalIndex] = best[index];

        return new AllocationResult(quantities, bestProfit, bestSpent, bestPlots, completed);

        void Search(
            int index,
            int remainingBudget,
            int remainingPlots,
            double score,
            double expectedProfit,
            int spent,
            int plots)
        {
            visited++;
            if ((visited & 1023) == 0 && stopwatch.ElapsedMilliseconds >= SearchTimeLimitMilliseconds)
            {
                completed = false;
                return;
            }

            if (IsBetter(score, expectedProfit, spent, plots, bestScore, bestProfit, bestSpent, bestPlots))
            {
                bestScore = score;
                bestProfit = expectedProfit;
                bestSpent = spent;
                bestPlots = plots;
                Array.Copy(current, best, current.Length);
            }

            if (index >= ordered.Length || remainingBudget <= 0 || remainingPlots <= 0)
                return;

            double plotBound = score + (remainingPlots * maximumScoreInSuffix[index]);
            double budgetBound = score + GetFractionalBudgetBound(index, remainingBudget);
            if (Math.Min(plotBound, budgetBound) <= bestScore + Epsilon)
                return;

            Candidate candidate = ordered[index].Candidate;
            int cost = candidate.UpfrontSeedCost;
            int quantityLimit = Math.Min(candidate.MaximumQuantity, Math.Min(remainingPlots, remainingBudget / cost));

            for (int quantity = quantityLimit; quantity >= 0; quantity--)
            {
                current[index] = quantity;
                Search(
                    index + 1,
                    remainingBudget - (quantity * cost),
                    remainingPlots - quantity,
                    score + (quantity * candidate.Evaluation.Score),
                    expectedProfit + (quantity * candidate.Evaluation.ExpectedProfit),
                    spent + (quantity * cost),
                    plots + quantity);

                if (!completed)
                    break;
            }

            current[index] = 0;
        }

        double GetFractionalBudgetBound(int startIndex, int remainingBudget)
        {
            double bound = 0;
            for (int index = startIndex; index < ordered.Length && remainingBudget > 0; index++)
            {
                Candidate candidate = ordered[index].Candidate;
                int cost = candidate.UpfrontSeedCost;
                int whole = Math.Min(candidate.MaximumQuantity, remainingBudget / cost);
                bound += whole * candidate.Evaluation.Score;
                remainingBudget -= whole * cost;

                if (whole < candidate.MaximumQuantity && remainingBudget > 0)
                {
                    bound += candidate.Evaluation.Score * ((double)remainingBudget / cost);
                    break;
                }
            }

            return bound;
        }
    }

    private static bool IsBetter(
        double candidateScore,
        double candidateProfit,
        int candidateSpent,
        int candidatePlots,
        double currentScore,
        double currentProfit,
        int currentSpent,
        int currentPlots)
    {
        if (candidateScore > currentScore + Epsilon)
            return true;
        if (Math.Abs(candidateScore - currentScore) > Epsilon)
            return false;
        if (candidateProfit > currentProfit + Epsilon)
            return true;
        if (Math.Abs(candidateProfit - currentProfit) > Epsilon)
            return false;
        if (candidateSpent != currentSpent)
            return candidateSpent < currentSpent;
        return candidatePlots < currentPlots;
    }

    private sealed record Candidate(CropEvaluation Evaluation, int UpfrontSeedCost, int MaximumQuantity);
    private sealed record SolverCandidate(Candidate Candidate, int OriginalIndex);
    private sealed record AllocationResult(int[] Quantities, double ExpectedProfit, int Spent, int Plots, bool Completed);
}
