# Changelog

All notable project changes are recorded here. Dates use `YYYY-MM-DD`.

## [1.0.2] - 2026-10-02

- Movement now follows the native waypoint footprint and axis order, with a per-frame displacement budget including slow frames. The prior center-distance governor could overshoot a narrow alignment corridor and oscillate.
- Production waypoint helper passed 4356 footprint/frame-duration cases (16, 33, 80 and 120 ms); this is geometry verification, not exhaustive native-map acceptance.
- Added bounded waypoint-entry/reversal evidence for native farm, refill, storage and home paths. The first revised natural sample completed 277 waypoint entries and 316 actions with no same-node reversal or stall.
- Wood recovery now requires actual missing chest ingredients and a full backpack blocking seed delivery or harvest; emergency branches must remain on the connected farming frontier. Stale status text no longer triggers storage acquisition.
- Spare-time expansion explains that currently executable farming work is finished. Crops still growing and reserved money can legitimately leave only clearing work.

## [1.0.1] - 2026-10-02

Local release record for the single-player farming assistant. No public upload has occurred.

### Changed

- Farming now takes priority; optional preparation runs only with remaining capacity.
- Clear, grass, chop, and hoe work now share one candidate pool on the four-neighbor boundary of a persistent connected worked core.
- Actual reachable path length sorts first; adjacent interactions are handled directly only within the connected frontier or its allowed safe bridge pool, so a distant adjacent obstacle cannot start a second clearing island. Equal-path candidates use compact-block and snake-order tie breaks.
- The frontier may bridge at most two safe empty tiles. Only selected safe bridge tiles and completed work enter the core; partially cut grass does not count as completed expansion. The former “up to two steps farther than global nearest” ordering was removed.
- Historical saved expansion progress is filtered to one valid four-neighbor connected component, while every existing crop remains eligible for care.
- Once selected, a whole tree and its stump are completed; safe ordinary trees may participate in the connected layout.
- Tree counts advance once only after the tree and stump disappear. Grass counts now measure fully cleared tiles, rather than individual hits.
- The assistant searches nearby for useful work instead of idling until 23:00.
- `SleepWhenFinished` and `SleepOnLowEnergy` now default to true. Disabling the relevant sleep options produces a safe pause for player control.
- Work-speed targets accept any integer from 1 to 200. Adaptive control normally raises by 2–5, lowers by 5 under ordinary pressure, and cuts about 20% under severe assistant overhead.
- Native tool frames and callbacks remain intact. Tool candidates use a 70 ms minimum, Showcase uses 160 ms, and walking acceleration is capped at 12.
- The HUD now says “work target” and reports successful actions per second over a three-second window.
- The Chinese maximum-target hint now says “200档” instead of “200x”, and the no-affordable-crop status is localized into Chinese. These UI text changes do not alter the tested overnight lifecycle.
- Mouse wheel input over work-speed and ceiling controls changes the target by ±1; clicks normally add 5 and add 1 at low targets.
- Replaced the ineffective obsolete `addedSpeed` setter with an assistant-scoped per-frame `temporarySpeedBuff`, capped at 12, with waypoint approach slowdown.
- Stall detection now uses path-node progress rather than pixel movement alone.
- Adjacent clearing inside the eligible connected pool is selected directly; non-adjacent selection uses a single bounded path search before actual-path-first ordering.
- Owned-tool drop notifications now match only vanilla item text on non-question dialogs with `NPC=null`.
- Overnight ownership remains active until settlement truly ends, and cancellation is paired with native Begin/End.
- The latest source revision corrects a premature overnight release when the date had advanced but native new-day processing was unfinished and a transient `menu=null` at or after 24:00 was treated as daytime readiness.
- Overnight state now requires the real `DayStarted` acknowledgment and completed menu flow before release, remains owned across no-menu gaps, survives `DayEnding` and layout changes, and clears on genuine cancellation. Four native sleep/save/recovery cycles passed as documented below.
- Storage selection skips unreachable assistant chests.
- Pre-sleep inventory blocking now checks actual remaining mature crops or a current seed purchase that needs an unavailable slot in a truly full backpack, rather than matching a generic inventory reason.
- Seed-purchase blockage resets on each decision pass and cancellation; mature crops with a usable slot go through a reachable-work recheck before early sleep.
- A full backpack without a mature-crop or current-purchase blockage may complete feasible work and use configured sleep even before enough wood for a chest is available. The accepted natural run crafted its actual 50-wood chest on Spring 3 and continued through two economic rounds.
- The `Harvested` ledger now covers the backpack and assistant chests whose recorded owner exactly matches the current player. Storage transfers retain the balance; successful shipping subtracts only the quantity shipped.
- Per-crop retention is combined across those inventories and all qualities. Development keeps five per crop by default, and known unsubmitted quest requirements remain reserved.
- Tracked assistant-grown surplus in reachable same-owner assistant chests can be shipped with a full backpack: native routing reaches a four-neighbor chest interaction tile before the actual crop quantity enters the shipping bin.
- Unreachable same-owner assistant chests are included in accounting and reserves but cannot be sold from remotely. Unknown and other-player chests remain protected. Stock whose ledger was already erased by an older version is not automatically inferred or reconstructed.
- Tree seeds `309 / 310 / 311` and Moss are stored as forestry resources and are not automatically sold.
- Development now uses the existing 12-tree daily maximum by default, Showcase uses 4, and Rush disables ordinary-tree clearing. Whole-tree/stump completion and the configured energy reserve, default 25, remain budget constraints.

### Controlled validation

- In the same 24-tile parsnip-watering fixture, target 1 took 55.175 s, target 50 took 7.506 s, and target 200 took 5.917 s. All completed 24 native waterings and ended at energy 222 from the same starting energy 270 and water 40.
- Measured speedups versus target 1 were 7.35x at target 50 and 9.32x at target 200. Frame P95 values were 24.4/26.0/25.7 ms and assistant P95 values were 0.0098/0.6863/0.6945 ms.
- Nine Governor mechanism tests passed.
- This controlled result covers movement and native-tool performance, not natural farming income, whole-engine speed, or stable 200x throughput.
- A controlled nearby-clearing scenario with the player at `(30,24)` first handled grass at `(29,24)` with zero walking steps, before farther clearing candidates.
- After an assistant-owned native tool action, original item acquisition received a Prehistoric Rib `(O)583`; the native presentation and text confirmation completed, and clearing continued.
- Tool pause was tested before the native begin event was polled and during `UsingTool=true` animation. Both completed one native watering with water `40→39`, watered soil (`dirt.state=1`), and energy reduced by 2, then restored `CanMove=true` and `UsingTool=false` through the paired native lifecycle without forcing those flags.
- An unrelated plain-text notice remained open, with game time and action count unchanged. This confirms the assistant did not acknowledge that notice as its own item discovery.
- A follow-up four-layer-grass scenario reduced grass from 4 layers to 1 without adding the unfinished tile to saved expansion progress. After the original Prehistoric Rib notice completed, the assistant resumed the same tile and recorded completion only after the last layer disappeared.
- That scenario finished with 64 core tiles, all 64 in one four-neighbor connected component, and zero unfinished obstacles counted as completed. Two native trees/stumps disappeared, with each completed tree counted once.
- The private native economic fixture transferred `7+4=11` crop items from backpack to storage while preserving normal/silver/gold harvest ledger values `20/4/2`.
- After native shipping of four backpack crop items and a backpack refill with untracked items, an eight-step native route from `(35,24)` reached the chest interaction tile `(29,23)`. The assistant then shipped 16 normal and 1 silver crop from storage; the actual shipping-bin total became 21.
- Tracked reserves ended at 3 silver plus 2 gold, totaling five. Four untracked normal-quality items remained unsold. The untagged chest's 3 cauliflowers, another owner's chest's 1 artifact, and the untracked backpack samples were preserved.
- Blocking all four chest interaction sides left 10 normal crops in the chest, harvest ledger 10, and shipping-bin count zero. No remote sale occurred.
- The version 1.0.1 build completed with zero warnings and zero errors. This is build evidence; the controlled runtime results above cover only their actual tested mechanisms.
- These are private controlled native results, not completed natural farming acceptance or all quest-reserve combinations.

### Natural new-save validation

- Native title and Chinese character creation produced an independent new save. No QA resources were applied; the native demonstration rejected a test-resource fixture request.
- Spring 1 bought 20 seeds at 20g each for 400g, retained 100g, and planted 35 including the starting seeds. Spring 3 crafted an assistant chest using 50 actual wood.
- Spring 5 harvested 33, shipped 28, and kept five. Spring 6 settled at 1,080g, bought 49 seeds for 980g, retained 100g, and planted 49. A native scarecrow consumed 50 wood, 1 coal, and 20 fiber and covered all 49 crops.
- Spring 10 harvested 49 and shipped 49. Five assistant-storage-origin shipping actions totaled five crop items and used actual native movement to storage; stored harvest history remained saleable instead of being erased.
- Spring 11 settled at 1,839g, bought 86 seeds for 1,720g, retained 119g, and planted 86. A second scarecrow increased coverage from 75 to all 86 crops.
- At the original Spring 12 save boundary, cumulative totals were 170 planted, 300 native waterings, 82 harvested, 77 shipped, and 11 native sleep/save cycles. Two natural harvest, shipping, settlement, and reinvestment rounds passed.
- With the Development 12-tree ceiling, Spring 5 completed seven whole trees before resting at energy 27.7, above the default 25 reserve; the former four-tree early limit no longer ended that day.
- The adaptive work target reached 200. Recent native-frame P95 samples were about 16.8–17.1 ms and assistant P95 about 0.35–0.51 ms. An earlier 23.5 ms base-game frame window did not falsely lower the target. These are this-run performance samples, not whole-engine 200x speed; the controlled speed comparison retains its original scope.
- Marnie's Spring 12 pet event was completed manually through native dialogue pages, a Yes response, and pet naming. After the native cat named “达德利” appeared, the assistant resumed and watered another 86 crops, increasing native waterings from 300 to 386. The next native sleep/save reached Spring 13 with cumulative totals 170 planted, 386 watered, 82 harvested, 77 shipped, and 12 sleeps. This is automatic farming recovery after manual story handling, not automatic story or choice progression. A guarded event-helper request outside an event was rejected without changing an event.

### Native overnight save/recovery validation

- Four controlled native cycles, with origins 0/1/2/3, completed `sleep → SaveGameMenu → SaveGame.Save without an exception → actual DayStarted → cycle completion → new Plant/Clear/Water/Harvest work`.
- Each owned overnight-wait segment recorded zero routes, farm actions, or tool starts, zero unexpected assistant-disable samples, and zero required-route blockages. Farm work resumed after the real day-start acknowledgment.
- Native experience gain produced pending upgrade entries `(2,1)` and `(2,2)` on Spring 1 and Spring 3; the subsequent overnight save/recovery passed. There is no direct log or visual confirmation of a `LevelUpMenu` page, so no upgrade-page visual pass is claimed.
- Captured overnight waits were all at 06:00 with `SaveGameMenu`. The precise former 24:00/null-menu gap was not dynamically reproduced; reviewed source protects it with the actual `DayStarted` acknowledgment and continued ownership during a null-menu gap. The four runtime passes and this additional source coverage are distinct evidence.
- The final reported build completed with zero warnings and zero errors. Two later UI-only text corrections preserve the tested core overnight logic.

### Release and validation boundaries

- Version 1.0.1 is documented for local distribution through standard SMAPI installation. No public upload has occurred. The tested local demonstration used independent saves rather than a player's personal save.
- Historical-core migration, untested quest-reserve and disabled-sleep combinations, other computers or operating systems, and arbitrary third-party mod combinations are not exhaustively validated.
- The controlled results and natural two-round result cover their respective recorded scenes and boundaries. Fishing, mining, full quest progression, Community Center completion, and story automation remain unimplemented.

### Historical QA findings and corrective results

- A previous natural demo stopped on Spring 4 at the first fossil notification because a normal `DialogueBox` blocked progress.
- The same demo lost assistant ownership across `DayStarted` after Spring 6 shipping.
- A later natural candidate falsely paused on Spring 2 with a full backpack, 37 wood, no mature crop, and energy 28 because a generic inventory reason was treated as blocked harvesting. The revision checks current crop/purchase blockage and clears stale purchase state; the accepted natural run crafted storage on Spring 3 and completed two economic rounds.
- Another earlier natural candidate planted 35 and harvested 35 in its first round, shipped 23, and settled at 905g: the initial remaining 100g plus 805g in sales. It then purchased 40 seeds through the actual shop for 800g, leaving 105g. The second round harvested 40, bringing totals to 75 harvested and 23 shipped, but stalled at 105g because storing those crops had erased their harvest ledger. This was a first-round reinvestment pass and second-round accounting failure. The replacement cross-storage ledger passed both the controlled native economic fixture and the new natural two-round run above; the old failed totals are retained only as diagnostic history.
- These runs are diagnostic evidence and do not establish the latest 1.0.1 behavior.

## [1.0.0-rc] - 2026-10-02

### Added

- Automated farming loop for supported single-player farms: debris clearing, soil preparation, crop planning, real-price seed purchasing, planting, watering, harvesting, crop reserves, shipping, sleeping, and reinvestment.
- Four work modes: Development, Showcase, Rush, and Custom.
- Adaptive work speed that starts probing at `25x`, defaults to a `200x` ceiling, and supports `50x`, `100x`, and `200x` ceilings.
- Manual work tiers: `1 / 2 / 5 / 10 / 25 / 50 / 75 / 100 / 150 / 200`.
- Performance page showing effective speed, frame P95, assistant P95, budget reason, and clearing totals.
- Managed 12x12 region selection; the overlay is forced off in this candidate and `F10` is a close-only action.
- Native tool actions for hoeing, watering, refilling, debris clearing, tree felling, and stump removal.
- Ordinary-tree policy with daily limits and protection for tapped, fertilized, mod-data, and non-ordinary trees.
- Known quest-target crop reserves based on the amount still required.
- Assistant-owned storage chests with a strict resource allowlist.
- Optional native scarecrow crafting and placement using learned recipes and real materials from the backpack or reachable player-owned assistant chests.
- Automatic pause reasons and recovery guidance for missing tools, water, inventory space, unreachable regions, and stalled routes.
- Chinese user guide and English community README.

### Changed

- Crop retention now keeps the configured total per crop across all qualities, prioritizing higher-quality items.
- Work speed is defined as assistant scheduling and limited movement/tool cadence, with clock acceleration limited to shop/sleep waiting.
- Every save load begins paused and requires an explicit `F8` start.
- Rush mode sleeps after essential farm work; Development and Showcase can prepare future plots and wait until 23:00.
- Development and Showcase now default to continuing zero-energy work at the configured energy reserve; Rush enables low-energy early sleep. The Performance page exposes this policy, while disabling Auto Sleep safely pauses for manual eating or sleep.
- Hard-bedtime handling now checks shipping, storage, and mature crops blocked by a full backpack before sleeping.
- Assistant storage now tries another marked chest when one is full and can attempt another chest when 50 wood is available across the backpack and reachable same-owner assistant chests.

### Fixed

- Corrected assistant chest creation logic that had mistaken a generic returned object for a placed chest.
- Preserved high manual speed selections by raising the effective speed ceiling when necessary.
- Added explicit pause behavior when the watering can or hoe is missing.
- Kept the game clock frozen while a blocking pause is shown in AssistantMenu.

### Verified in local runtime

- 35 plantings, 35 waterings, 12 grass cuts, and 2 ordinary trees through native actions.
- Water, Hoe, and movement reached effective `200x`, with observed game-frame P95 around `17–18 ms`; this does not mean constant whole-game 200x speed.
- Empty watering-can refill and continuation.
- Missing watering can passed rainy-day adaptation and sunny-day pause at 06:00. `CanMove=false`, no-safe-region, and unexpected-town-map cases also paused safely; supported recovery continued. The `NoPath` guard passed source review rather than an in-game fault injection.
- Dead crops used a real zero-energy Scythe action in about 316 ms; low-energy zero-cost work completed before sleep while watering respected the reserve.
- Three save-config normalization groups passed.
- Storage consumed 50 wood from 98 and stored five stacks; a full 36-slot chest led to a second chest consuming 50 wood from 128, followed by 51 seed purchases and plantings.
- A 51-crop scene consumed 50 wood, 1 coal, and 20 fiber and placed a native scarecrow with full coverage.
- With all owned assistant chests full and zero backpack wood, chest-sourced wood changed from 999 to 949, backpack wood stayed zero, and a third native chest was placed.
- Earlier farming loop: 97 planted, 176 watered, 33 harvested, 33 shipped, 6 sleeps, revenue reinvestment, and native save reload.
- The 1.0.0 ZIP was extracted into a newly created folder in the actual game `Mods` directory. The manifest UniqueID/version 1.0.0 were correct, the installed DLL was byte-for-byte hash-identical to that version's final release/bundle DLL, and existing ConsoleCommands and SaveBackup folders remained intact.
- A native Spring 9 reload began paused and preserved two assistant chests with their contents plus one scarecrow.
- One 24-mature-potato fixture on Spring 10 produced five `harvest_extra_collected` events totaling `Stack=5` for `(O)192`; every event was confirmed by `Debris.collect:true` and ended at `pending=0`.
- Development at the energy reserve of 25 completed zero-energy harvesting and waited until 23:00; Rush used low-energy early sleep, and Auto Sleep off paused for manual intervention.
- On a native Spring 11 reload of the 1.0.0 candidate, `AutoSleep=false` produced `Paused: manual bedtime reached` at in-game time 23:00; AssistantMenu telemetry stayed at that game time, and a 1280x720 Settings screenshot showed all controls and the pause reason without clipping.
- With 24 mature potatoes, zero free slots, energy 25, and `AutoStorage=false`, closing the menu at 06:00 produced `Paused: backpack needs space`; multiple samples stayed on Spring 11 at `time=600`.
- With the pre-bed check active, `AutoSleep=true` at in-game time 23:00 still prioritized the same backpack pause; samples stayed on Spring 11 at that game time, with `sleeps=0`.
- The formal native `--demo` launcher completed title and Chinese character creation and entered an independent Spring 1 save with audio. Day 1 at 09:40 recorded 35 planted, 35 watered, 0 sleeps, effective `200x`, frame P95 `17.1037 ms`, assistant P95 `0.0052 ms`, `qa_injected=0`, and 100 money. A reviewed real-tool rock-clearing screenshot showed no overlay.

### Validation boundaries

- Final code, local actual-`Mods` installation, and the formal independent new-save demonstration have evidence. The normal launcher has not loaded a player's personal save, and cross-computer or cross-operating-system behavior is not claimed.
- The extra-harvest result is five real collection events within one controlled fixture, not five independent fixtures or evidence of natural global income outside it.
- The two latest guards and the new pre-bed check have targeted native runtime evidence and a zero-warning build; exhaustive state-combination coverage is not claimed.
- Fishing, mining, full quest progression, Community Center completion, and story automation are not implemented.
