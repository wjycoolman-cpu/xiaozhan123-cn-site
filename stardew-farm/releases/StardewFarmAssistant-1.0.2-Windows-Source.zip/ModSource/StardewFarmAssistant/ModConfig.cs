using Microsoft.Xna.Framework;

namespace StardewFarmAssistant;

public sealed class ModConfig
{
    public string WorkMode { get; set; } = "development";
    public int WorkSpeed { get; set; } = 10;
    public bool AdaptiveSpeed { get; set; } = true;
    public int SpeedCeiling { get; set; } = 200;
    public int MaxPlots { get; set; } = 120;
    public int ReserveGold { get; set; } = 100;
    public int ReserveEnergy { get; set; } = 25;
    public int KeepEachCrop { get; set; } = 5;
    public int SleepTime { get; set; } = 2300;
    public bool AutoBuySeeds { get; set; } = true;
    public bool AutoShip { get; set; } = true;
    public bool AutoSleep { get; set; } = true;
    public bool SleepWhenFinished { get; set; } = true;
    public bool SleepOnLowEnergy { get; set; } = true;
    public bool PrepareAhead { get; set; } = true;
    public bool AutoStorage { get; set; } = true;
    public bool AutoScarecrow { get; set; } = true;
    public bool ClearDebris { get; set; } = true;
    public bool ClearTrees { get; set; } = true;
    public int MaxTreesPerDay { get; set; } = 12;
    public bool ShowOverlay { get; set; } = false;
    public string ProfitMode { get; set; } = "balanced";
    public void SetMode(string mode)
    {
        WorkMode = mode is "development" or "rush" or "showcase" ? mode : "custom";
        if (WorkMode == "custom") return;
        WorkSpeed = WorkMode == "rush" ? 50 : WorkMode == "showcase" ? 25 : 10;
        MaxPlots = 120; ReserveEnergy = 25; SleepTime = 2300;
        ReserveGold = WorkMode == "rush" ? 0 : 100;
        KeepEachCrop = WorkMode == "rush" ? 0 : 5;
        PrepareAhead = WorkMode != "rush";
        SleepWhenFinished = true;
        SleepOnLowEnergy = true;
        ClearTrees = WorkMode != "rush"; MaxTreesPerDay = WorkMode == "development" ? 12 : 4;
        AutoBuySeeds = AutoShip = AutoSleep = AutoStorage = AutoScarecrow = ClearDebris = true;
        ShowOverlay = false;
        ProfitMode = "balanced";
    }
    public void Normalize()
    {
        ShowOverlay = false;
        WorkSpeed = Math.Clamp(WorkSpeed, 1, 200);
        SpeedCeiling = Math.Clamp(SpeedCeiling, 1, 200);
        MaxPlots = Math.Clamp(MaxPlots, 1, 120);
        ReserveGold = Math.Clamp(ReserveGold, 0, 1000000);
        ReserveEnergy = Math.Clamp(ReserveEnergy, 15, 200);
        KeepEachCrop = Math.Clamp(KeepEachCrop, 0, 99);
        MaxTreesPerDay = Math.Clamp(MaxTreesPerDay, 1, 12);
        SleepTime = Math.Clamp(SleepTime, 1800, 2400);
        ProfitMode = ProfitMode == "seasonProfit" ? "seasonProfit" : "balanced";
        if (WorkMode is not ("development" or "rush" or "showcase" or "custom")) WorkMode = "custom";
    }
}

public sealed class SaveSettings
{
    public bool Enabled { get; set; }
    public int RegionX { get; set; } = -1;
    public int RegionY { get; set; } = -1;
    public int RegionWidth { get; set; } = 12;
    public int RegionHeight { get; set; } = 12;
    public int AutoLayoutX { get; set; } = -1;
    public int AutoLayoutY { get; set; } = -1;
    public List<Point> ExpansionTiles { get; set; } = new();
    public Dictionary<string, int> Harvested { get; set; } = new();
    public void Normalize()
    {
        if (RegionX < 0 || RegionY < 0) RegionX = RegionY = -1;
        RegionWidth = Math.Clamp(RegionWidth, 1, 120);
        RegionHeight = Math.Clamp(RegionHeight, 1, 120);
        Harvested ??= new();
        ExpansionTiles ??= new();
        ExpansionTiles = ExpansionTiles.Where(p => p.X >= 0 && p.Y >= 0).Distinct().Take(20000).ToList();
        foreach (string key in Harvested.Where(pair => string.IsNullOrWhiteSpace(pair.Key) || pair.Value <= 0).Select(pair => pair.Key).ToArray())
            Harvested.Remove(key);
    }
}

public sealed class FarmStatus
{
    public bool Enabled { get; set; }
    public string Activity { get; set; } = "Paused";
    public string CropChoice { get; set; } = "--";
    public string Reason { get; set; } = "";
    public string SleepReason { get; set; } = "";
    public int Planted { get; set; }
    public int Watered { get; set; }
    public int Harvested { get; set; }
    public int Cleared { get; set; }
    public int TreesCleared { get; set; }
    public int GrassCleared { get; set; }
    public int Shipped { get; set; }
    public int Bought { get; set; }
    public int ManagedPlots { get; set; }
    public long Actions { get; set; }
    public double WorstTickMs { get; set; }
    public int EffectiveSpeed { get; set; } = 25;
    public double FrameP95Ms { get; set; }
    public double AssistantP95Ms { get; set; }
    public double ActionsPerSecond { get; set; }
    public string SpeedReason { get; set; } = "";
    public int DaysRun { get; set; }
}
