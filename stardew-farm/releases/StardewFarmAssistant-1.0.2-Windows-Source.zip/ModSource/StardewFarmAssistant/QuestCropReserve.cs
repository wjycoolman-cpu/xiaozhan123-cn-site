using StardewValley;
using StardewValley.Quests;
using StardewValley.SpecialOrders;
using StardewValley.SpecialOrders.Objectives;
using SObject = StardewValley.Object;

namespace StardewFarmAssistant;

/// <summary>Calculates how many matching items active consuming objectives still need.</summary>
public static class QuestCropReserve
{
    private const int MaximumRequired = 1_000_000;

    /// <summary>
    /// Get the outstanding quantity of this qualified item ID which should be
    /// retained for active quests and special orders. Progress-only collection,
    /// fishing, harvest, and shipping objectives deliberately add no reserve.
    /// </summary>
    public static int RequiredFor(SObject item)
    {
        ArgumentNullException.ThrowIfNull(item);
        Farmer? player = Game1.player;
        if (player is null)
            return 0;

        string qualifiedId = item.QualifiedItemId;
        int required = 0;

        foreach (Quest quest in player.questLog)
        {
            if (quest.completed.Value)
                continue;

            switch (quest)
            {
                case ItemDeliveryQuest delivery
                    when SameId(delivery.ItemId.Value, qualifiedId):
                    required = AddClamped(required, Math.Max(0, delivery.number.Value));
                    break;

                case LostItemQuest lost
                    when lost.itemFound.Value && SameId(lost.ItemId.Value, qualifiedId):
                    required = AddClamped(required, 1);
                    break;

                case SecretLostItemQuest secret
                    when secret.itemFound.Value && SameId(secret.ItemId.Value, qualifiedId):
                    required = AddClamped(required, 1);
                    break;
            }

            if (required >= MaximumRequired)
                return MaximumRequired;
        }

        SObject probeItem = (SObject)item.getOne();
        probeItem.Stack = MaximumRequired;
        foreach (SpecialOrder order in player.team.specialOrders)
        {
            if (order.questState.Value != SpecialOrderStatus.InProgress)
                continue;

            // This is the game's aggregate, side-effect-free matcher for every
            // donation objective in this order, including preserved-color rules.
            required = AddClamped(required, Math.Max(0, order.GetAcceptCount(probeItem)));

            foreach (OrderObjective objective in order.objectives)
            {
                if (objective.IsComplete())
                    continue;
                int remaining = Math.Max(0, objective.GetMaxCount() - objective.GetCount());
                if (remaining == 0)
                    continue;

                switch (objective)
                {
                    case DeliverObjective deliver:
                    {
                        NPC? target = Game1.getCharacterFromName(deliver.targetName.Value);
                        bool accepted = target is not null
                            ? deliver.OnItemDelivered(player, target, probeItem, probe: true) > 0
                            : MatchesContextTagSets(probeItem, deliver.acceptableContextTagSets);
                        if (accepted)
                            required = AddClamped(required, remaining);
                        break;
                    }

                    case GiftObjective gift
                        when MatchesContextTagSets(probeItem, gift.acceptableContextTagSets):
                        // Recipient taste is intentionally left as a conservative
                        // runtime uncertainty; context tags are the item constraint.
                        required = AddClamped(required, remaining);
                        break;
                }

                if (required >= MaximumRequired)
                    return MaximumRequired;
            }
        }

        return required;
    }

    private static bool SameId(string? left, string right)
    {
        return !string.IsNullOrWhiteSpace(left)
            && string.Equals(ItemRegistry.QualifyItemId(left) ?? left, right, StringComparison.OrdinalIgnoreCase);
    }

    private static int AddClamped(int current, int addition)
    {
        if (addition <= 0)
            return current;
        long sum = (long)current + addition;
        return (int)Math.Min(MaximumRequired, sum);
    }

    /// <summary>
    /// Mirrors the game's context-tag grammar: list entries are OR alternatives,
    /// comma clauses are AND, and slash-separated tags inside a clause are OR.
    /// An empty list has no item restriction in the native objective handlers.
    /// </summary>
    private static bool MatchesContextTagSets(Item item, IEnumerable<string> sets)
    {
        bool hadSet = false;
        foreach (string set in sets)
        {
            hadSet = true;
            bool matches = true;
            foreach (string clause in set.Split(','))
            {
                if (!ItemContextTagManager.DoAnyTagsMatch(clause.Split('/'), item.GetContextTags()))
                {
                    matches = false;
                    break;
                }
            }
            if (matches)
                return true;
        }
        return !hadSet;
    }
}
