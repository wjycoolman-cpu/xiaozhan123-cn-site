using System.Globalization;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Inventories;
using StardewValley.Locations;
using StardewValley.Objects;
using StardewValley.Pathfinding;
using SObject = StardewValley.Object;

namespace StardewFarmAssistant;

/// <summary>Stores farm supplies in an assistant-owned, physically crafted chest.</summary>
public sealed class InventoryStorage
{
    private const string StorageTag = "LocalTools.StardewFarmAssistant/storage";
    private const string ChestRecipe = "Chest";
    private const string WoodId = "388";
    private const int ChestWoodCost = 50;
    private static readonly HashSet<string> ResourceIds = new(StringComparer.Ordinal)
    {
        WoodId, "390", "771", "382", "330", "92", "770", "309", "310", "311", "Moss"
    };
    private static readonly Vector2[] Neighbors =
    {
        new(0, 1), new(-1, 0), new(1, 0), new(0, -1)
    };

    private readonly ModEntry owner;
    private Vector2? targetChest;
    private DateTime pathStarted;
    private bool ownsPath;
    private bool shippingOperation;
    public bool OwnsCurrentPath => ownsPath;
    public bool NeedsCraftWood { get; private set; }
    private string lastFailure = "";
    private DateTime lastFailureLog;

    private bool Blocked(string reason)
    {
        owner.Status.Reason = reason;
        if (reason != lastFailure || (DateTime.UtcNow - lastFailureLog).TotalSeconds > 15)
        { owner.LogEvidence("storage_blocked", new { reason }); lastFailureLog = DateTime.UtcNow; }
        lastFailure = reason;
        return false;
    }

    public InventoryStorage(ModEntry owner)
    {
        this.owner = owner ?? throw new ArgumentNullException(nameof(owner));
    }

    /// <summary>
    /// Snapshot the backpack and the inventories of precisely tagged assistant
    /// chests belonging to this farmer. Unreachable owned chests still count:
    /// losing a route must not erase the provenance of crops already stored.
    /// </summary>
    public IReadOnlyList<(SObject Item, IInventory Inventory, Vector2? ChestTile)> GetOwnedItemStacks(Farm farm)
    {
        Farmer who = Game1.player;
        string ownerId = who.UniqueMultiplayerID.ToString(CultureInfo.InvariantCulture);
        var result = new List<(SObject Item, IInventory Inventory, Vector2? ChestTile)>();
        foreach (SObject item in who.Items.OfType<SObject>())
            result.Add((item, who.Items, null));
        foreach (var pair in farm.objects.Pairs.Where(p => p.Value is Chest chest && IsOwnedStorage(chest, ownerId))
                     .OrderBy(p => p.Key.Y).ThenBy(p => p.Key.X))
        {
            if (pair.Value is not Chest chest || !IsOwnedStorage(chest, ownerId)) continue;
            IInventory items = chest.GetItemsForPlayer(who.UniqueMultiplayerID);
            foreach (SObject item in items.OfType<SObject>())
                result.Add((item, items, pair.Key));
        }
        return result;
    }

    private static bool IsOwnedStorage(Chest chest, string ownerId)
        => chest.modData.TryGetValue(StorageTag, out string? taggedOwner)
            && string.Equals(taggedOwner, ownerId, StringComparison.Ordinal);

    /// <summary>
    /// Walk to an assistant-owned chest and ship only the globally allocated
    /// known surplus. Shipping directly from that inventory needs no empty
    /// backpack slot. A true return owns this work step, including the walk.
    /// </summary>
    public bool TryShipOwnedSurplus(Farm farm, IReadOnlyDictionary<string, int> surplus)
    {
        Farmer who = Game1.player;
        if (Game1.isWarping || Game1.locationRequest != null)
        {
            if (shippingOperation) Cancel();
            return true;
        }
        if (Game1.currentLocation != farm)
        {
            if (shippingOperation) Cancel();
            return false;
        }
        // Finish a deposit route already owned by this component before
        // choosing a shipping chest; neither workflow may retarget the other's
        // controller midway through a native walk.
        if (targetChest.HasValue && !shippingOperation) return TryMakeSpace(farm);
        if (!surplus.Any(pair => pair.Value > 0))
        {
            if (shippingOperation) Cancel();
            return false;
        }
        string ownerId = who.UniqueMultiplayerID.ToString(CultureInfo.InvariantCulture);
        bool CanShip(SObject item) => surplus.GetValueOrDefault(item.QualifiedItemId + ":" + item.Quality) > 0
            && item.canBeShipped() && item.canBeTrashed();
        bool HasSurplus(Chest chest) => chest.GetItemsForPlayer(who.UniqueMultiplayerID).OfType<SObject>().Any(CanShip);

        (Vector2 Tile, Chest Chest)? selected = null;
        if (shippingOperation && targetChest.HasValue
            && farm.objects.TryGetValue(targetChest.Value, out SObject? targeted)
            && targeted is Chest current && IsOwnedStorage(current, ownerId) && HasSurplus(current))
            selected = (targetChest.Value, current);
        else if (shippingOperation)
            Cancel();

        if (selected is null)
        {
            bool inaccessibleSurplus = false;
            foreach (var pair in farm.objects.Pairs.Where(p => p.Value is Chest chest && IsOwnedStorage(chest, ownerId))
                         .OrderBy(p => Vector2.DistanceSquared(p.Key, who.Tile)))
            {
                if (pair.Value is not Chest chest || !IsOwnedStorage(chest, ownerId) || !HasSurplus(chest)) continue;
                if (!HasReachableNeighbor(farm, pair.Key)) { inaccessibleSurplus = true; continue; }
                selected = (pair.Key, chest);
                break;
            }
            if (selected is null)
            {
                if (inaccessibleSurplus) return Blocked("Own crop surplus remains in unreachable assistant storage");
                return false;
            }
        }

        targetChest = selected.Value.Tile;
        shippingOperation = true;
        if (who.controller != null)
        {
            if (!ownsPath)
            {
                owner.Status.Activity = "Waiting for current movement before storage";
                return true;
            }
            if ((DateTime.UtcNow - pathStarted).TotalSeconds <= 12)
            {
                owner.Status.Activity = "Walking to ship stored crops";
                return true;
            }
            Cancel();
            return Blocked("Assistant storage shipping route timed out");
        }

        Point playerTile = who.TilePoint;
        if (Math.Abs(playerTile.X - (int)selected.Value.Tile.X) + Math.Abs(playerTile.Y - (int)selected.Value.Tile.Y) != 1)
        {
            if (!TryStartPath(farm, selected.Value.Tile))
            {
                Cancel();
                return Blocked("Assistant storage has no reachable adjacent tile for shipping");
            }
            owner.Status.Activity = "Walking to ship stored crops";
            owner.LogEvidence("storage_shipping_route", new
            {
                x = selected.Value.Tile.X, y = selected.Value.Tile.Y,
                steps = who.controller?.pathToEndPoint.Count ?? 0
            });
            return true;
        }

        Vector2 shippedFrom = selected.Value.Tile;
        IInventory inventory = selected.Value.Chest.GetItemsForPlayer(who.UniqueMultiplayerID);
        var remaining = surplus.ToDictionary(pair => pair.Key, pair => pair.Value);
        ownsPath = false;
        targetChest = null;
        shippingOperation = false;
        int shippedTotal = 0;
        for (int index = 0; index < inventory.Count; index++)
        {
            if (inventory[index] is not SObject item || !CanShip(item)) continue;
            string key = item.QualifiedItemId + ":" + item.Quality;
            int quantity = Math.Min(item.Stack, Math.Min(remaining.GetValueOrDefault(key), owner.Save.Harvested.GetValueOrDefault(key)));
            if (quantity <= 0) continue;
            Item copy = item.getOne(); copy.Stack = quantity;
            farm.getShippingBin(who).Add(copy);
            item.Stack -= quantity;
            if (item.Stack <= 0) inventory[index] = null;
            remaining[key] -= quantity;
            owner.Save.Harvested[key] -= quantity;
            owner.Status.Shipped += quantity;
            shippedTotal += quantity;
            owner.LogEvidence("shipping", new
            {
                item = copy.QualifiedItemId, copy.Stack,
                source = "assistant_storage", x = shippedFrom.X, y = shippedFrom.Y,
                ledgerAfter = owner.Save.Harvested[key]
            });
        }
        if (shippedTotal == 0) return false;
        owner.Status.Activity = "Shipped own stored crops";
        owner.Status.Reason = "";
        lastFailure = "";
        return true;
    }

    /// <summary>
    /// Try to free inventory slots using only a chest owned by this assistant.
    /// Returns true while the storage operation owns the current work step.
    /// </summary>
    public bool TryMakeSpace(Farm farm)
    {
        NeedsCraftWood = false;
        ArgumentNullException.ThrowIfNull(farm);
        Farmer who = Game1.player;

        if (Game1.isWarping || Game1.locationRequest != null)
        {
            Cancel();
            owner.Status.Activity = "Storage paused for location change";
            return true;
        }
        if (Game1.currentLocation != farm)
            return false;
        if (shippingOperation) return true;

        if (!targetChest.HasValue && who.freeSpotsInInventory() > 1)
            return false;

        string ownerId = who.UniqueMultiplayerID.ToString(CultureInfo.InvariantCulture);
        (Vector2 Tile, Chest Chest)? storage = FindStorage(farm, ownerId);
        if (storage is null)
        {
            if (!TryCraftAndPlaceStorage(farm, ownerId, out Vector2 placedTile, out Chest? placedChest))
                return false;
            storage = (placedTile, placedChest!);
        }

        targetChest = storage.Value.Tile;
        if (who.controller != null)
        {
            if (!ownsPath)
                return false;
            if ((DateTime.UtcNow - pathStarted).TotalSeconds <= 12)
            {
                owner.Status.Activity = "Walking to assistant storage";
                return true;
            }

            who.controller = null;
            ownsPath = false;
            targetChest = null;
            owner.Status.Reason = "Assistant storage route timed out";
            return false;
        }

        if (Vector2.Distance(who.Tile, storage.Value.Tile) > 1.6f)
        {
            if (!TryStartPath(farm, storage.Value.Tile))
            {
                targetChest = null;
                owner.Status.Reason = "Assistant storage has no reachable adjacent tile";
                return false;
            }
            return true;
        }

        ownsPath = false;
        targetChest = null;
        int deposited = DepositEligibleItems(farm, storage.Value.Chest);
        if (deposited <= 0)
        {
            owner.Status.Reason = "Inventory is full, but no safe owned items can be stored";
            return false;
        }

        owner.Status.Activity = "Stored farming supplies";
        owner.Status.Reason = "";
        lastFailure = "";
        return true;
    }

    /// <summary>Release only the path controller started by this storage workflow.</summary>
    public void Cancel()
    {
        if (ownsPath && Context.IsWorldReady && Game1.player.controller != null)
            Game1.player.controller = null;
        ownsPath = false;
        targetChest = null;
        shippingOperation = false;
    }

    private (Vector2 Tile, Chest Chest)? FindStorage(Farm farm, string ownerId)
    {
        foreach (var pair in farm.objects.Pairs)
        {
            if (pair.Value is Chest chest && IsOwnedStorage(chest, ownerId))
            {
                var items = chest.GetItemsForPlayer(Game1.player.UniqueMultiplayerID);
                bool freeSlot = items.Count(i => i != null) < chest.GetActualCapacity();
                bool stackRoom = Game1.player.Items.OfType<SObject>()
                    .Where(i => ResourceIds.Contains(i.ItemId) || owner.Save.Harvested.GetValueOrDefault(i.QualifiedItemId + ":" + i.Quality) > 0)
                    .Any(i => items.Any(stored => stored != null && stored.canStackWith(i) && stored.Stack < stored.maximumStackSize()));
                if ((freeSlot || stackRoom) && HasReachableNeighbor(farm, pair.Key)) return (pair.Key, chest);
            }
        }
        return null;
    }

    private bool TryCraftAndPlaceStorage(Farm farm, string ownerId, out Vector2 tile, out Chest? chest)
    {
        tile = default;
        chest = null;
        Farmer who = Game1.player;
        List<IInventory> materialInventories = FindOwnedReachableMaterialInventories(farm, ownerId, who);
        List<Item> storedItems = materialInventories
            .SelectMany(inventory => inventory)
            .Where(item => item is not null)
            .ToList();
        int backpackWoodBefore = CountWood(who.Items);
        int woodBefore = backpackWoodBefore + materialInventories.Sum(CountWood);
        if (!who.craftingRecipes.ContainsKey(ChestRecipe))
        {
            return Blocked("Inventory needs space, but the Chest recipe is not learned");
        }
        if (woodBefore < ChestWoodCost)
        {
            NeedsCraftWood = true;
            return Blocked($"Inventory needs space; {ChestWoodCost - woodBefore} more wood is required for a real Chest");
        }

        var recipe = new CraftingRecipe(ChestRecipe, isCookingRecipe: false);
        if (!recipe.doesFarmerHaveIngredientsInInventory(storedItems))
        {
            return Blocked("Inventory needs space, but the real Chest recipe ingredients are unavailable");
        }
        // In 1.6.15 a crafting recipe returns the big-craftable Object.
        // The original placementAction then creates the actual placed Chest.
        if (recipe.createItem() is not SObject crafted || crafted.QualifiedItemId != "(BC)130")
        {
            return Blocked("Inventory needs space, but the Chest recipe output is unsupported");
        }

        foreach (Vector2 candidate in FindPlacementCandidates(farm))
        {
            if (!farm.CanItemBePlacedHere(candidate)
                || farm.objects.ContainsKey(candidate)
                || farm.terrainFeatures.ContainsKey(candidate)
                || owner.Engine.Plots.Contains(candidate)
                || !HasReachableNeighbor(farm, candidate))
                continue;

            if (!crafted.placementAction(farm, (int)candidate.X * 64, (int)candidate.Y * 64, who)
                || !farm.objects.TryGetValue(candidate, out SObject? placed)
                || placed is not Chest placedChest)
                continue;

            recipe.consumeIngredients(materialInventories);
            who.craftingRecipes[ChestRecipe]++;
            Game1.stats.ItemsCrafted++;
            placedChest.modData[StorageTag] = ownerId;
            tile = candidate;
            chest = placedChest;
            int backpackWoodAfter = CountWood(who.Items);
            int woodAfter = backpackWoodAfter + materialInventories.Sum(CountWood);
            owner.LogEvidence("storage_crafted", new
            {
                costWood = ChestWoodCost,
                woodBefore,
                woodAfter,
                backpackBefore = backpackWoodBefore,
                backpackAfter = backpackWoodAfter,
                assistantStorageCount = materialInventories.Count,
                position = new { x = candidate.X, y = candidate.Y }
            });
            return true;
        }

        return Blocked("Inventory needs space, but no safe reachable Chest tile is available near the farmhouse");
    }

    private List<IInventory> FindOwnedReachableMaterialInventories(Farm farm, string ownerId, Farmer who)
    {
        var inventories = new List<IInventory>();
        foreach (var pair in farm.objects.Pairs)
        {
            if (pair.Value is not Chest chest || !IsOwnedStorage(chest, ownerId)
                || !HasReachableNeighbor(farm, pair.Key))
                continue;
            inventories.Add(chest.GetItemsForPlayer(who.UniqueMultiplayerID));
        }
        return inventories;
    }

    private static int CountWood(IEnumerable<Item?> items)
        => items.Where(item => item is SObject { ItemId: WoodId }).Sum(item => item!.Stack);

    private IEnumerable<Vector2> FindPlacementCandidates(Farm farm)
    {
        Vector2 entry = farm.GetMainFarmHouseEntry().ToVector2();
        for (int radius = 2; radius <= 10; radius++)
        {
            for (int y = -radius; y <= radius; y++)
            {
                for (int x = -radius; x <= radius; x++)
                {
                    if (Math.Max(Math.Abs(x), Math.Abs(y)) != radius)
                        continue;
                    yield return entry + new Vector2(x, y);
                }
            }
        }
    }

    private bool HasReachableNeighbor(Farm farm, Vector2 chestTile)
    {
        foreach (Vector2 neighbor in Neighbors.Select(delta => chestTile + delta)
                     .OrderBy(point => Vector2.DistanceSquared(point, Game1.player.Tile)))
        {
            if (!IsOpenWalkingTile(farm, neighbor))
                continue;
            var path = new PathFindController(Game1.player, farm, neighbor.ToPoint(), Game1.player.FacingDirection);
            if (path.pathToEndPoint is { Count: > 0 } || Game1.player.TilePoint == neighbor.ToPoint())
                return true;
        }
        return false;
    }

    private bool TryStartPath(Farm farm, Vector2 chestTile)
    {
        foreach (Vector2 neighbor in Neighbors.Select(delta => chestTile + delta)
                     .OrderBy(point => Vector2.DistanceSquared(point, Game1.player.Tile)))
        {
            if (!IsOpenWalkingTile(farm, neighbor))
                continue;
            if (Game1.player.TilePoint == neighbor.ToPoint())
                return true;
            var path = new PathFindController(Game1.player, farm, neighbor.ToPoint(), Game1.player.FacingDirection);
            if (path.pathToEndPoint is not { Count: > 0 })
                continue;
            Game1.player.controller = path;
            ownsPath = true;
            pathStarted = DateTime.UtcNow;
            owner.Status.Activity = "Walking to assistant storage";
            return true;
        }
        return false;
    }

    private static bool IsOpenWalkingTile(Farm farm, Vector2 tile)
    {
        return tile.X >= 0 && tile.Y >= 0
            && tile.X < farm.Map.Layers[0].LayerWidth && tile.Y < farm.Map.Layers[0].LayerHeight
            && farm.isTileLocationOpen(tile)
            && !farm.objects.ContainsKey(tile)
            && !farm.terrainFeatures.ContainsKey(tile)
            && farm.getBuildingAt(tile) is null;
    }

    private int DepositEligibleItems(Farm farm, Chest chest)
    {
        Farmer who = Game1.player;
        int depositedTotal = 0;
        int woodReserve = ChestWoodCost;
        var storedCounts = GetOwnedItemStacks(farm).Where(stack => stack.ChestTile.HasValue)
            .GroupBy(stack => stack.Item.QualifiedItemId + ":" + stack.Item.Quality)
            .ToDictionary(group => group.Key, group => group.Sum(stack => stack.Item.Stack));
        // The ledger spans every owned container. Allocate each same-key crop
        // once, excluding the part already in storage, without erasing its
        // ownership when the physical item moves into another inventory.
        var remainingOwned = owner.Save.Harvested.ToDictionary(pair => pair.Key,
            pair => Math.Max(0, pair.Value - storedCounts.GetValueOrDefault(pair.Key)));

        for (int index = who.Items.Count - 1; index >= 0; index--)
        {
            if (who.Items[index] is not SObject item)
                continue;

            bool isResource = ResourceIds.Contains(item.ItemId);
            string harvestedKey = item.QualifiedItemId + ":" + item.Quality;
            int ownedCrop = remainingOwned.GetValueOrDefault(harvestedKey);
            int quantity;
            if (isResource)
            {
                if (item.ItemId == WoodId)
                {
                    int keep = Math.Min(item.Stack, woodReserve);
                    woodReserve -= keep;
                    quantity = item.Stack - keep;
                }
                else
                {
                    quantity = item.Stack;
                }
            }
            else
            {
                quantity = Math.Min(item.Stack, Math.Max(0, ownedCrop));
            }

            if (quantity <= 0)
                continue;

            Item copy = item.getOne();
            copy.Stack = quantity;
            Item? remainder = chest.addItem(copy);
            int deposited = quantity - (remainder?.Stack ?? 0);
            if (deposited <= 0)
                continue;

            item.Stack -= deposited;
            if (item.Stack <= 0)
                who.Items[index] = null;
            if (!isResource)
                remainingOwned[harvestedKey] = Math.Max(0, ownedCrop - deposited);

            depositedTotal += deposited;
            owner.LogEvidence("storage_deposit", new
            {
                item = item.QualifiedItemId,
                quality = item.Quality,
                qty = deposited,
                ledgerAfter = owner.Save.Harvested.GetValueOrDefault(harvestedKey)
            });
        }

        return depositedTotal;
    }
}
