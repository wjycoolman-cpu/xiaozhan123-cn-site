using HarmonyLib;
using StardewValley;

namespace StardewFarmAssistant;

/// <summary>
/// Attributes item debris created by one crop harvest only after the original
/// game confirms that the exact debris object was collected successfully.
/// </summary>
public sealed class HarvestSettlement : IDisposable
{
    private const string HarmonyId = "LocalTools.StardewFarmAssistant.harvest-settlement";
    private static readonly object RouteLock = new();
    private static HarvestSettlement? active;
    private static bool patched;

    private readonly ModEntry owner;
    private readonly Dictionary<Debris, PendingDebris> pending = new(ReferenceEqualityComparer.Instance);
    private bool disposed;

    public HarvestSettlement(ModEntry owner)
    {
        this.owner = owner ?? throw new ArgumentNullException(nameof(owner));
        lock (RouteLock)
        {
            active?.Clear("tracker_replaced");
            active = this;
            if (!patched)
            {
                var collect = AccessTools.Method(typeof(Debris), nameof(Debris.collect), new[] { typeof(Farmer), typeof(Chunk) })
                    ?? throw new MissingMethodException(typeof(Debris).FullName, nameof(Debris.collect));
                new Harmony(HarmonyId).Patch(
                    collect,
                    postfix: new HarmonyMethod(typeof(HarvestSettlement), nameof(AfterDebrisCollect))
                );
                patched = true;
            }
        }
    }

    /// <summary>Whether harvested item debris is still waiting for a real pickup.</summary>
    public bool HasPending => this.pending.Count > 0;

    /// <summary>
    /// Snapshot the debris references which existed before calling the original
    /// <see cref="Crop.harvest(int,int,StardewValley.TerrainFeatures.HoeDirt,StardewValley.Characters.JunimoHarvester,bool)"/>.
    /// </summary>
    public HarvestCapture BeforeHarvest(GameLocation location, string harvestItemId)
    {
        if (this.disposed)
            throw new ObjectDisposedException(nameof(HarvestSettlement));
        ArgumentNullException.ThrowIfNull(location);
        if (string.IsNullOrWhiteSpace(harvestItemId))
            throw new ArgumentException("A harvest item ID is required.", nameof(harvestItemId));

        var existing = new HashSet<Debris>(ReferenceEqualityComparer.Instance);
        foreach (Debris debris in location.debris)
            existing.Add(debris);
        return new HarvestCapture(location, ItemRegistry.QualifyItemId(harvestItemId), existing);
    }

    /// <summary>
    /// Capture only new debris references produced during the corresponding
    /// original harvest call. Existing ground items can never enter this set.
    /// The normal synchronous inventory delta should still be recorded by the
    /// caller; this class owns only output which the game placed into debris.
    /// </summary>
    /// <returns>The number of exact crop-debris objects now awaiting pickup.</returns>
    public int AfterHarvest(HarvestCapture capture)
    {
        if (this.disposed)
            throw new ObjectDisposedException(nameof(HarvestSettlement));
        ArgumentNullException.ThrowIfNull(capture);
        if (capture.Completed)
            throw new InvalidOperationException("This harvest capture was already completed.");
        capture.Completed = true;

        int added = 0;
        int quantity = 0;
        foreach (Debris debris in capture.Location.debris)
        {
            if (capture.ExistingDebris.Contains(debris) || this.pending.ContainsKey(debris))
                continue;
            Item? item = debris.item;
            if (item is null || !string.Equals(item.QualifiedItemId, capture.HarvestItemId, StringComparison.OrdinalIgnoreCase))
                continue;

            int stack = Math.Max(1, item.Stack);
            this.pending.Add(debris, new PendingDebris(capture.Location, capture.HarvestItemId, item.Quality, stack));
            added++;
            quantity += stack;
        }

        this.owner.LogEvidence("harvest_extra_pending", new
        {
            item = capture.HarvestItemId,
            debris = added,
            quantity,
            pending = this.pending.Count
        });
        return added;
    }

    /// <summary>
    /// Drop pending references which vanished without a successful collect
    /// callback, such as debris which sank or was removed during a transition.
    /// This never invents inventory ownership.
    /// </summary>
    public void Update()
    {
        if (this.disposed || this.pending.Count == 0)
            return;
        foreach ((Debris debris, PendingDebris value) in this.pending.ToArray())
        {
            if (value.Location.debris.Contains(debris))
                continue;
            this.pending.Remove(debris);
            this.owner.LogEvidence("harvest_extra_uncollected", new
            {
                item = value.ItemId,
                value.Quality,
                value.Stack,
                pending = this.pending.Count
            });
        }
    }

    /// <summary>Forget all pending debris on pause, save load, return to title, or day transition.</summary>
    public void Clear(string reason)
    {
        if (this.pending.Count == 0)
            return;
        int quantity = this.pending.Values.Sum(value => value.Stack);
        int count = this.pending.Count;
        this.pending.Clear();
        this.owner.LogEvidence("harvest_extra_cleared", new { reason, debris = count, quantity });
    }

    public void Dispose()
    {
        if (this.disposed)
            return;
        this.Clear("disposed");
        this.disposed = true;
        lock (RouteLock)
        {
            if (ReferenceEquals(active, this))
                active = null;
        }
    }

    private static void AfterDebrisCollect(Debris __instance, Farmer farmer, bool __result)
    {
        if (!__result)
            return;
        HarvestSettlement? tracker;
        lock (RouteLock)
            tracker = active;
        tracker?.OnDebrisCollected(__instance, farmer);
    }

    private void OnDebrisCollected(Debris debris, Farmer who)
    {
        if (this.disposed || !this.pending.Remove(debris, out PendingDebris? value))
            return;

        bool isLocalPlayer = who is not null
            && Game1.player is not null
            && who.UniqueMultiplayerID == Game1.player.UniqueMultiplayerID;
        if (!isLocalPlayer)
        {
            this.owner.LogEvidence("harvest_extra_other_collector", new
            {
                item = value.ItemId,
                value.Quality,
                value.Stack,
                collector = who?.UniqueMultiplayerID,
                pending = this.pending.Count
            });
            return;
        }

        string key = value.ItemId + ":" + value.Quality;
        this.owner.Save.Harvested[key] = this.owner.Save.Harvested.GetValueOrDefault(key) + value.Stack;
        this.owner.LogEvidence("harvest_extra_collected", new
        {
            item = value.ItemId,
            value.Quality,
            value.Stack,
            owned = this.owner.Save.Harvested[key],
            pending = this.pending.Count,
            confirmedBy = "Debris.collect:true"
        });
    }

    public sealed class HarvestCapture
    {
        internal GameLocation Location { get; }
        internal string HarvestItemId { get; }
        internal HashSet<Debris> ExistingDebris { get; }
        internal bool Completed { get; set; }

        internal HarvestCapture(GameLocation location, string harvestItemId, HashSet<Debris> existingDebris)
        {
            this.Location = location;
            this.HarvestItemId = harvestItemId;
            this.ExistingDebris = existingDebris;
        }
    }

    private sealed record PendingDebris(GameLocation Location, string ItemId, int Quality, int Stack);
}
