using System.Diagnostics;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.BellsAndWhistles;
using StardewValley.Internal;
using StardewValley.GameData.Crops;
using StardewValley.Locations;
using StardewValley.Objects;
using StardewValley.Pathfinding;
using StardewValley.TerrainFeatures;
using StardewValley.Tools;
using StardewFarmAssistant.Planning;
using SObject = StardewValley.Object;

namespace StardewFarmAssistant;

public sealed class FarmEngine : IActivityModule
{
    private readonly ModEntry owner;
    private readonly InventoryStorage storage;
    private readonly HarvestSettlement harvestSettlement;
    private readonly FarmProtection protection;
    private DateTime lastProtectionCheck;
    private Vector2? pickupTile;
    private DateTime pickupStarted;
    private readonly List<Vector2> plots = new();
    private readonly HashSet<Vector2> blocked = new();
    private readonly Dictionary<string, int> purchasedToday = new();
    private Vector2? target;
    private string task = "";
    private DateTime pathStarted;
    private DateTime lastPurchase;
    private bool sleepCycle;
    private int idleFrames;
    private PathFindController? ownedPath;
    private PathFindController? alignmentPath;
    private Point alignmentNode;
    private int alignmentDirection = -1;
    private Point? clearingSection;
    private readonly HashSet<Point> expansionCore = new();
    private Vector2? expansionSeed;
    private readonly List<Vector2> expansionBridge = new();
    private Vector2? expansionBridgeTarget;
    private Vector2? committedTree;
    private Vector2? committedGrass;
    private DateTime fallingTreeSince;
    private bool seedPurchaseNeedsSpace;
    private bool completionRechecked;
    private int layoutX, layoutY;
    private PathFindController? progressController;
    private int progressRemaining = int.MaxValue;
    private bool returningToSleep;
    private NativeToolAction? nativeAction;
    private Vector2 progressPosition;
    private long progressActions = -1;
    private DateTime lastProgress;
    private int recoveryAttempts;
    private StardewValley.Menus.DialogueBox? ownedParcelDialogue;
    private bool ownedParcelPending;
    private DateTime parcelStarted;
    private DateTime lastParcelAdvance;
    private StardewValley.Menus.DialogueBox? ownedWorkDialogue;
    private DateTime lastOwnedToolAt, lastWorkNoticeAdvance;
    private int ownedNightDay = -1;
    private bool ownedNightDayStarted;
    private bool nightTransitionWaitLogged;
    public string Id => "farming";
    public bool IsAvailable => Context.IsWorldReady && Context.IsMainPlayer && !Context.IsMultiplayer;
    public string UnavailableReason => "Single-player save required";
    private ModConfig Config => owner.Config;
    private SaveSettings Save => owner.Save;
    private FarmStatus Status => owner.Status;
    public IReadOnlyList<Vector2> Plots => plots;
    public Vector2? CurrentTarget => target;

    public FarmEngine(ModEntry owner)
    {
        this.owner = owner;
        storage = new InventoryStorage(owner);
        harvestSettlement = new HarvestSettlement(owner);
        protection = new FarmProtection(owner);
    }
    public void OnDayStarted()
    {
        bool pendingNight = sleepCycle;
        int pendingNightDay = ownedNightDay;
        completionRechecked = false; clearingSection = null;
        Cancel(abandonHarvest: true);
        plots.Clear(); blocked.Clear(); expansionCore.Clear(); purchasedToday.Clear(); idleFrames = 0; sleepCycle = pendingNight; returningToSleep = false;
        ownedNightDay = pendingNightDay;
        ownedNightDayStarted = pendingNight && pendingNightDay >= 0 && Game1.Date.TotalDays > pendingNightDay;
        if (ownedNightDayStarted)
            owner.LogEvidence("sleep_day_started", new { originDay = ownedNightDay, currentDay = Game1.Date.TotalDays, time = Game1.timeOfDay });
        lastPurchase = DateTime.MinValue;
        lastProtectionCheck = DateTime.MinValue;
        lastProgress = DateTime.MinValue; recoveryAttempts = 0;
        Status.DaysRun++;
        Status.Planted = Status.Watered = Status.Harvested = Status.Cleared = Status.Shipped = Status.Bought = 0;
        Status.TreesCleared = Status.GrassCleared = 0;
        Status.Activity = Save.Enabled ? "Planning today's farm" : "F8 to start automatic farming";
        Status.Reason = ""; Status.SleepReason = "";
    }
    public void InvalidateLayout() { Cancel(abandonHarvest: false, preserveNight: true); plots.Clear(); blocked.Clear(); completionRechecked = false; clearingSection = null; }
    public void Cancel() => Cancel(abandonHarvest: false);
    public void Cancel(bool abandonHarvest, bool preserveNight = false)
    {
        if (!preserveNight)
        {
            sleepCycle = false; ownedNightDay = -1; ownedNightDayStarted = false; nightTransitionWaitLogged = false;
        }
        storage.Cancel();
        if (abandonHarvest)
        { harvestSettlement.Clear("day_or_save_changed"); pickupTile = null; }
        else if (harvestSettlement.HasPending) pickupStarted = DateTime.UtcNow;
        if (Context.IsWorldReady)
        {
            if (target.HasValue || task == "travel") Game1.player.controller = null;
        }
        ownedPath = null;
        nativeAction?.ReleaseSpeed(); nativeAction = null;
        target = null; task = ""; returningToSleep = false;
        ownedParcelDialogue = null;
        ownedParcelPending = false;
        ownedWorkDialogue = null; committedTree = committedGrass = null;
        expansionBridge.Clear(); expansionBridgeTarget = null;
        fallingTreeSince = DateTime.MinValue; seedPurchaseNeedsSpace = false;
        lastProgress = DateTime.MinValue;
    }
    private void OwnWalkingSpeed()
    {
        // Farmer.addedSpeed's setter is a no-op in 1.6. Apply the actual native
        // per-frame speed input only to a path started by this assistant.
        ownedPath = Game1.player.controller;
    }
    public void PrepareMovement()
    {
        if (!IsAvailable || Game1.activeClickableMenu != null || Game1.eventUp || Game1.fadeToBlack
            || Game1.isWarping || Game1.locationRequest != null || Game1.player.UsingTool) return;
        if (Game1.player.controller is { pathToEndPoint.Count: > 0 } path
            && (ReferenceEquals(path, ownedPath) || storage.OwnsCurrentPath))
        {
            var next = path.pathToEndPoint.Peek();
            var box = Game1.player.GetBoundingBox();
            var cell = new Rectangle(next.X * 64 + 2, next.Y * 64, 60, 64);
            // Match the native controller's axis order and whole-footprint acceptance.
            // Orthogonal distance must never authorize overshooting this axis's corridor.
            var (direction, stepBudget) = WaypointStepBudget(box, cell);
            if (direction < 0) return;
            float frameScale = Math.Max(1, Game1.currentGameTime.ElapsedGameTime.Milliseconds) * .066f;
            float baseSpeed = Game1.player.speed + Game1.player.addedSpeed + Game1.player.temporarySpeedBuff;
            float desired = Math.Clamp((owner.EffectiveWorkSpeed - 1) / 4f, 0, 12);
            float extra = Math.Min(desired, stepBudget / frameScale - baseSpeed);
            bool sameNode = ReferenceEquals(alignmentPath, path) && alignmentNode == next;
            bool reversed = sameNode && alignmentDirection >= 0 && (alignmentDirection + 2) % 4 == direction;
            if (!sameNode || reversed)
                owner.LogEvidence(reversed ? "path_alignment_reversal" : "movement_probe", new { next.X, next.Y, direction, stepBudget, extra, frameScale, box, pathCount = path.pathToEndPoint.Count });
            alignmentPath = path; alignmentNode = next; alignmentDirection = direction;
            Game1.player.temporarySpeedBuff += extra;
        }
    }
    internal static (int Direction, float StepBudget) WaypointStepBudget(Rectangle box, Rectangle cell)
    {
        float horizontalRoom = Math.Max(0, cell.Width - box.Width) / 2f;
        float verticalRoom = Math.Max(0, cell.Height - box.Height - 2) / 2f;
        if (box.Left < cell.Left && box.Right < cell.Right)
            return (1, Math.Max(1, cell.Left + horizontalRoom - box.Left));
        if (box.Right > cell.Right && box.Left > cell.Left)
            return (3, Math.Max(1, box.Right - (cell.Right - horizontalRoom)));
        if (box.Top <= cell.Top)
            return (2, Math.Max(1, cell.Top + verticalRoom - box.Top));
        if (box.Bottom >= cell.Bottom - 2)
            return (0, Math.Max(1, box.Bottom - (cell.Bottom - 2 - verticalRoom)));
        return (-1, 0);
    }
    public bool WatchForStall()
    {
        if (!IsAvailable || Game1.activeClickableMenu != null || Game1.eventUp || Game1.fadeToBlack
            || Game1.isWarping || Game1.locationRequest != null || Game1.player.isEating || sleepCycle)
        { lastProgress = DateTime.MinValue; return false; }
        bool expectedWait = Status.Activity.StartsWith("Waiting for seed") || Status.Activity is "Field ready; waiting until bedtime" or "Energy reserve; waiting until bedtime";
        bool activeWork = nativeAction != null || target.HasValue || Game1.player.controller != null || task == "travel" || returningToSleep || !Game1.player.CanMove;
        if (expectedWait || !activeWork) { lastProgress = DateTime.MinValue; return false; }
        var now = DateTime.UtcNow;
        bool actionCompleted = progressActions != Status.Actions;
        var controller = Game1.player.controller;
        bool routeAdvanced = controller != null && (!ReferenceEquals(progressController, controller)
            || controller.pathToEndPoint.Count < progressRemaining);
        bool movedOutsideRoute = controller == null && Vector2.DistanceSquared(progressPosition, Game1.player.Position) >= 1;
        if (lastProgress == DateTime.MinValue || actionCompleted || routeAdvanced || movedOutsideRoute)
        {
            progressActions = Status.Actions; progressPosition = Game1.player.Position; lastProgress = now;
            progressController = controller; progressRemaining = controller?.pathToEndPoint.Count ?? int.MaxValue;
            if (actionCompleted) recoveryAttempts = 0;
            return false;
        }
        if ((now - lastProgress).TotalSeconds < 8) return false;
        recoveryAttempts++;
        owner.LogEvidence("stall_detected", new { task, target, attempts = recoveryAttempts, Game1.player.CanMove, controller = Game1.player.controller != null, Status.Actions });
        if (recoveryAttempts >= 3 || !Game1.player.CanMove && nativeAction == null)
        {
            owner.PauseSafely("Paused: route or character action stalled", "Automatic recovery could not make progress. Clock stopped in settings; move the character or change the managed region, then press F8.");
            return true;
        }
        if (target.HasValue) blocked.Add(target.Value);
        Cancel(); Status.Activity = "Replanning interrupted route"; Status.Reason = "No progress for 8 seconds; selected another reachable task";
        return true;
    }
    private bool WalkTo(Point end, string activity)
    {
        var player = Game1.player;
        if (player.TilePoint == end) return true;
        if (player.controller != null) return false;
        var path = new PathFindController(player, player.currentLocation, end, player.FacingDirection);
        if (path.pathToEndPoint == null || path.pathToEndPoint.Count == 0)
        {
            owner.PauseSafely("Paused: required route blocked", "The route to the farm, home, bed or harvest pickup is blocked. Clear the route or move the character, then press F8.");
            return false;
        }
        player.controller = path; OwnWalkingSpeed(); pathStarted = DateTime.UtcNow;
        Status.Activity = activity; task = "travel";
        return false;
    }
    public bool TickOwnedNightMenu()
    {
        if (Game1.activeClickableMenu is StardewValley.Menus.DialogueBox { isQuestion: false, characterDialogue: null } workNotice
            && Game1.currentLocation is Farm && (nativeAction != null || (DateTime.UtcNow - lastOwnedToolAt).TotalSeconds <= 8))
        {
            var item = Game1.player.mostRecentlyGrabbedItem;
            string? expected = item?.checkForSpecialItemHoldUpMeessage();
            if (item != null && expected == null)
                expected = item.HasContextTag("book_item") ? Game1.content.LoadString("Strings\\1_6_Strings:FoundABook", item.DisplayName)
                    : Game1.content.LoadString("Strings\\StringsFromCSFiles:Farmer.cs.1919", item.DisplayName, Lexicon.getProperArticleForWord(item.DisplayName));
            if (ReferenceEquals(workNotice, ownedWorkDialogue) || expected != null && workNotice.getCurrentString() == expected)
            {
                if (!ReferenceEquals(workNotice, ownedWorkDialogue))
                {
                    ownedWorkDialogue = workNotice; lastWorkNoticeAdvance = DateTime.UtcNow;
                    owner.LogEvidence("work_notification_owned", new { item = item?.QualifiedItemId });
                }
                if ((DateTime.UtcNow - lastWorkNoticeAdvance).TotalSeconds >= .7)
                {
                    lastWorkNoticeAdvance = DateTime.UtcNow; workNotice.receiveLeftClick(0, 0);
                    owner.LogEvidence("work_notification_advanced", new { dismissed = Game1.activeClickableMenu != workNotice });
                }
                Status.Activity = "Receiving farm discovery";
                return true;
            }
        }
        if (ownedWorkDialogue != null && Game1.activeClickableMenu != ownedWorkDialogue) ownedWorkDialogue = null;
        if (ownedParcelPending)
        {
            // The gift chest's native animation may create its notification on
            // a later game tick, rather than inside checkForAction itself.
            if (Game1.activeClickableMenu is StardewValley.Menus.DialogueBox { isQuestion: false, characterDialogue: null } notification)
            { ownedParcelDialogue = notification; ownedParcelPending = false; lastParcelAdvance = DateTime.UtcNow; }
            else if (Game1.activeClickableMenu != null || (DateTime.UtcNow - parcelStarted).TotalSeconds > 8)
                ownedParcelPending = false;
        }
        if (ownedParcelDialogue != null)
        {
            if (Game1.activeClickableMenu != ownedParcelDialogue) ownedParcelDialogue = null;
            else
            {
                if ((DateTime.UtcNow - lastParcelAdvance).TotalSeconds >= .4)
                {
                    lastParcelAdvance = DateTime.UtcNow;
                    ownedParcelDialogue.receiveLeftClick(0, 0);
                    owner.LogEvidence("starter_parcel_dialogue", new { dismissed = Game1.activeClickableMenu != ownedParcelDialogue });
                }
                Status.Activity = "Receiving starter seeds";
                return true;
            }
        }
        if ((returningToSleep || sleepCycle) && Game1.currentLocation is FarmHouse home
            && home.lastQuestionKey?.Split(' ')[0] == "Sleep"
            && Game1.activeClickableMenu is StardewValley.Menus.DialogueBox { isQuestion: true, characterDialogue: null } dialogue)
        {
            bool firstAnswer = !sleepCycle;
            Cancel(abandonHarvest: false, preserveNight: !firstAnswer); sleepCycle = true;
            if (firstAnswer) { ownedNightDay = Game1.Date.TotalDays; ownedNightDayStarted = false; nightTransitionWaitLogged = false; }
            dialogue.receiveKeyPress(Microsoft.Xna.Framework.Input.Keys.Y);
            Status.Activity = "Sleeping";
            if (firstAnswer) owner.LogEvidence("sleep", new { day = Game1.dayOfMonth, time = Game1.timeOfDay, Game1.player.Stamina });
            return true;
        }
        if (!sleepCycle) return false;
        var menu = Game1.activeClickableMenu;
        if (menu != null && NightMenuHandler.Advance(menu, owner)) return true;
        if (!ownedNightDayStarted && Game1.Date.TotalDays > ownedNightDay && !nightTransitionWaitLogged)
        {
            nightTransitionWaitLogged = true;
            owner.LogEvidence("sleep_awaiting_day_started", new { originDay = ownedNightDay, currentDay = Game1.Date.TotalDays, time = Game1.timeOfDay, menu = menu?.GetType().Name, Game1.player.CanMove });
        }
        // The native NewDay task advances the date before saving is finished.
        // Own even its menu-free gaps until SMAPI has raised the actual DayStarted.
        if (menu == null && Context.IsWorldReady && ownedNightDayStarted && Game1.Date.TotalDays > ownedNightDay
            && !Game1.fadeToBlack && !Game1.isWarping && Game1.locationRequest == null && Game1.player.CanMove)
        {
            owner.LogEvidence("sleep_cycle_completed", new { originDay = ownedNightDay, currentDay = Game1.Date.TotalDays, time = Game1.timeOfDay });
            sleepCycle = false;
            ownedNightDay = -1; ownedNightDayStarted = false; nightTransitionWaitLogged = false;
            return false;
        }
        Status.Activity = "Sleeping";
        return true;
    }

    private bool IsKnownDebris(SObject item) => item.Name is "Stone" or "Weeds" or "Twig";
    private bool IsCandidate(Farm farm, Vector2 tile)
    {
        int x = (int)tile.X, y = (int)tile.Y;
        if (x < 1 || y < 1 || x >= farm.Map.Layers[0].LayerWidth - 1 || y >= farm.Map.Layers[0].LayerHeight - 1) return false;
        if (Save.RegionX >= 0 && (x < Save.RegionX || y < Save.RegionY || x >= Save.RegionX + Save.RegionWidth || y >= Save.RegionY + Save.RegionHeight)) return false;
        if (farm.doesTileHaveProperty(x, y, "Diggable", "Back") == null) return false;
        if (farm.doesTileHaveProperty(x, y, "Water", "Back") != null || farm.getBuildingAt(tile) != null) return false;
        if (farm.terrainFeatures.TryGetValue(tile, out var terrain) && terrain is not HoeDirt
            && !(Config.ClearDebris && terrain is Grass) && !(terrain is Tree tree && IsSafeTree(farm, tile, tree))) return false;
        if (farm.objects.TryGetValue(tile, out var obj) && !(Config.ClearDebris && IsKnownDebris(obj))) return false;
        if (farm.resourceClumps.Any(c => c.getBoundingBox().Intersects(new Rectangle(x * 64, y * 64, 64, 64)))) return false;
        return true;
    }
    private void BuildLayout(Farm farm)
    {
        var anchor = farm.GetMainFarmHouseEntry().ToVector2();
        var existing = farm.terrainFeatures.Pairs.Where(p => p.Value is HoeDirt hd && hd.crop != null && IsCandidate(farm, p.Key)).Select(p => p.Key).ToList();
        if (existing.Count > 0) anchor = existing.OrderBy(t => Vector2.DistanceSquared(t, anchor)).First();
        var candidates = new List<Vector2>();
        for (int y = 1; y < farm.Map.Layers[0].LayerHeight - 1; y++)
            for (int x = 1; x < farm.Map.Layers[0].LayerWidth - 1; x++)
            { var t = new Vector2(x, y); if (IsCandidate(farm, t)) candidates.Add(t); }
        var start = candidates.OrderBy(t => Vector2.DistanceSquared(t, anchor)).ThenBy(t => t.Y).ThenBy(t => t.X).FirstOrDefault();
        if (candidates.Count == 0) { Status.Reason = "No safe farmable tiles in region"; return; }
        int waterLimit = Math.Max(1, (int)((Game1.player.MaxStamina - Config.ReserveEnergy) / Math.Max(1.0, 2.0 - .1 * Game1.player.FarmingLevel)));
        int count = Math.Min(Config.MaxPlots, waterLimit);
        int columns = Math.Min(12, Math.Max(3, (int)Math.Ceiling(Math.Sqrt(count) / 3) * 3));
        if (Save.RegionX >= 0) { layoutX = Save.RegionX; layoutY = Save.RegionY; columns = Math.Min(columns, Save.RegionWidth); }
        else
        {
            if (Save.AutoLayoutX < 0 || Save.AutoLayoutY < 0)
            { Save.AutoLayoutX = Math.Max(1, (int)start.X - columns / 2); Save.AutoLayoutY = (int)start.Y; }
            layoutX = Save.AutoLayoutX; layoutY = Save.AutoLayoutY;
        }
        int rows = (int)Math.Ceiling((double)count / columns);
        foreach (var t in existing.OrderBy(t => Vector2.DistanceSquared(t, anchor)).ThenBy(t => t.Y).ThenBy(t => t.X).Take(count)) plots.Add(t);
        var safe = candidates.ToHashSet();
        var frontier = new HashSet<Vector2> { start };
        var visited = new HashSet<Vector2>();
        var directions = new[] { new Vector2(0, 1), new Vector2(-1, 0), new Vector2(1, 0), new Vector2(0, -1) };
        while (frontier.Count > 0 && plots.Count < count)
        {
            var t = frontier.OrderBy(t => Math.Max(0, layoutX - t.X) + Math.Max(0, t.X - (layoutX + columns - 1))
                + Math.Max(0, layoutY - t.Y) + Math.Max(0, t.Y - (layoutY + rows - 1)))
                .ThenBy(t => t.Y).ThenBy(t => ((int)t.Y - layoutY) % 2 == 0 ? t.X : -t.X).First();
            frontier.Remove(t); visited.Add(t);
            if (!plots.Contains(t)) plots.Add(t);
            foreach (var d in directions) if (safe.Contains(t + d) && !visited.Contains(t + d)) frontier.Add(t + d);
        }
        plots.Sort((a, b) => a.Y == b.Y ? a.X.CompareTo(b.X) : a.Y.CompareTo(b.Y));
        Status.ManagedPlots = plots.Count;
        // Care for every existing crop, but expand from one connected worked patch.
        var worked = Save.ExpansionTiles.Where(p => IsWorkedExpansionTile(farm, p.ToVector2())).ToHashSet();
        worked.UnionWith(plots.Where(t => farm.terrainFeatures.TryGetValue(t, out var f) && f is HoeDirt
            && IsWorkedExpansionTile(farm, t)).Select(t => t.ToPoint()));
        expansionCore.Clear(); expansionSeed = null;
        if (worked.Count > 0)
        {
            var root = worked.OrderBy(p => Vector2.DistanceSquared(p.ToVector2(), anchor)).First();
            var connected = new Queue<Point>(); connected.Enqueue(root); expansionCore.Add(root);
            while (connected.Count > 0)
            {
                var current = connected.Dequeue();
                foreach (var d in new[] { new Point(0, 1), new Point(-1, 0), new Point(1, 0), new Point(0, -1) })
                {
                    var p = current + d;
                    if (worked.Contains(p) && expansionCore.Add(p)) connected.Enqueue(p);
                }
            }
        }
        Save.ExpansionTiles = expansionCore.ToList();
        if (expansionCore.Count == 0)
        {
            var emptyAnchor = candidates.Where(t => IsWorkedExpansionTile(farm, t))
                .OrderBy(t => Vector2.DistanceSquared(t, start)).Cast<Vector2?>().FirstOrDefault();
            if (emptyAnchor.HasValue) RememberExpansion(emptyAnchor.Value);
            else expansionSeed = start;
        }
        owner.LogEvidence("layout", new { plots = plots.Count, anchor, custom = Save.RegionX >= 0 });
    }
    private void RememberExpansion(Vector2 tile)
    {
        if (expansionCore.Add(tile.ToPoint())) Save.ExpansionTiles.Add(tile.ToPoint());
    }
    private bool IsWorkedExpansionTile(Farm farm, Vector2 tile) => IsCandidate(farm, tile)
        && !farm.objects.ContainsKey(tile)
        && (!farm.terrainFeatures.TryGetValue(tile, out var feature) || feature is HoeDirt);
    private bool RememberWorkedTile(Farm farm, Vector2 tile)
    {
        // A partial grass hit or a still-falling tree must not open a new edge.
        if (!IsWorkedExpansionTile(farm, tile)) return false;
        if (expansionBridgeTarget == tile)
            foreach (var bridgeTile in expansionBridge.AsEnumerable().Reverse())
            {
                if (!IsWorkedExpansionTile(farm, bridgeTile) || !OnExpansionEdge(bridgeTile)) break;
                RememberExpansion(bridgeTile);
            }
        var standing = Game1.player.Tile;
        if (OnExpansionEdge(standing) && IsWorkedExpansionTile(farm, standing)) RememberExpansion(standing);
        if (!OnExpansionEdge(tile)) return false;
        RememberExpansion(tile);
        expansionSeed = null;
        if (expansionBridgeTarget == tile) { expansionBridge.Clear(); expansionBridgeTarget = null; }
        owner.LogEvidence("expansion_completed", new { x = tile.X, y = tile.Y, core = expansionCore.Count });
        return true;
    }
    private bool OnExpansionEdge(Vector2 tile) => expansionCore.Count == 0 && expansionSeed.HasValue
            ? Math.Abs(tile.X - expansionSeed.Value.X) + Math.Abs(tile.Y - expansionSeed.Value.Y) <= 1
            : expansionCore.Contains(tile.ToPoint())
        || new[] { new Point(0, 1), new Point(-1, 0), new Point(1, 0), new Point(0, -1) }.Any(d => expansionCore.Contains(tile.ToPoint() + d));

    private bool BeginTask(Farm farm, Vector2 tile, string kind)
    {
        if (blocked.Contains(tile)) return false;
        var player = Game1.player;
        bool optional = kind is "Clear" or "Clear grass" or "Chop";
        if (optional && Math.Abs(tile.X - player.Tile.X) + Math.Abs(tile.Y - player.Tile.Y) > 13) return false;
        if (kind == "Clear grass" && !player.Items.OfType<MeleeWeapon>().Any(w => w.isScythe()))
        { Status.Reason = "Scythe missing; grass clearing skipped"; return false; }
        if (kind == "Clear" && farm.objects.TryGetValue(tile, out var debris)
            && (debris.Name == "Stone" ? !player.Items.OfType<Pickaxe>().Any() : !player.Items.OfType<Axe>().Any()))
        { Status.Reason = "Clearing tool missing; optional debris clearing skipped"; return false; }
        if (Math.Abs(player.TilePoint.X - (int)tile.X) + Math.Abs(player.TilePoint.Y - (int)tile.Y) == 1)
        { target = tile; task = kind; return true; }
        PathFindController? best = null;
        foreach (var n in new[] { tile + new Vector2(0, 1), tile + new Vector2(-1, 0), tile + new Vector2(1, 0), tile + new Vector2(0, -1) }.OrderBy(t => Vector2.DistanceSquared(t, player.Tile)))
        {
            if (farm.objects.ContainsKey(n) || farm.terrainFeatures.TryGetValue(n, out var f) && f is not (HoeDirt or Grass)) continue;
            if (best != null && Math.Abs(n.X - player.Tile.X) + Math.Abs(n.Y - player.Tile.Y) >= best.pathToEndPoint.Count) continue;
            var path = new PathFindController(player, farm, n.ToPoint(), 2, null, optional ? 256 : 4096);
            if (path.pathToEndPoint == null || path.pathToEndPoint.Count == 0) continue;
            if (best == null || path.pathToEndPoint.Count < best.pathToEndPoint.Count) best = path;
        }
        if (best != null)
        {
            // Optional expansion never crosses the farm for a single piece of debris.
            if (optional && best.pathToEndPoint.Count > 12) return false;
            player.controller = best; OwnWalkingSpeed(); target = tile; task = kind; pathStarted = DateTime.UtcNow;
            owner.LogEvidence("work_route", new { kind, x = tile.X, y = tile.Y, steps = best.pathToEndPoint.Count });
            Status.Activity = "Walking to " + kind.ToLowerInvariant(); return true;
        }
        blocked.Add(tile); return false;
    }
    private bool TryNearbyClearing(Farm farm, IEnumerable<(Vector2 Tile, string Kind)> jobs)
    {
        var player = Game1.player;
        bool hasAxe = player.Items.OfType<Axe>().Any(), hasPickaxe = player.Items.OfType<Pickaxe>().Any();
        bool hasScythe = player.Items.OfType<MeleeWeapon>().Any(w => w.isScythe()), hasHoe = player.Items.OfType<Hoe>().Any();
        var candidates = jobs.Where(j => !blocked.Contains(j.Tile)
            && Math.Abs(j.Tile.X - player.Tile.X) + Math.Abs(j.Tile.Y - player.Tile.Y) <= 13
            && (j.Kind == "Hoe" ? hasHoe : j.Kind == "Clear grass" ? hasScythe
                : j.Kind == "Chop" ? hasAxe
                : farm.objects.TryGetValue(j.Tile, out var debris) && (debris.Name == "Stone" ? hasPickaxe : hasAxe)))
            .Distinct().ToList();
        if (candidates.Count == 0) return false;
        Point Section(Vector2 t) => new((int)Math.Floor((t.X - layoutX) / 3), (int)Math.Floor((t.Y - layoutY) / 3));
        var adjacent = candidates.Where(j => Math.Abs(j.Tile.X - player.Tile.X) + Math.Abs(j.Tile.Y - player.Tile.Y) == 1)
            .OrderBy(j => j.Kind == "Hoe" ? 1 : 0)
            .ThenBy(j => clearingSection.HasValue && Section(j.Tile) == clearingSection ? 0 : 1)
            .ThenBy(j => j.Tile.Y).ThenBy(j => ((int)j.Tile.Y - layoutY) % 2 == 0 ? j.Tile.X : -j.Tile.X).ToList();
        if (adjacent.Count > 0)
        {
            var job = adjacent[0]; clearingSection = Section(job.Tile); target = job.Tile; task = job.Kind; Status.Activity = task;
            owner.LogEvidence("work_route", new { kind = task, x = job.Tile.X, y = job.Tile.Y, steps = 0, nearby = true, sectionX = clearingSection.Value.X, sectionY = clearingSection.Value.Y });
            return true;
        }
        // One bounded breadth-first search supplies actual shortest walking
        // distances for all candidates. It uses the game's collision predicate.
        var start = player.TilePoint;
        var distance = new Dictionary<Point, int> { [start] = 0 };
        var parent = new Dictionary<Point, Point>();
        var queue = new Queue<Point>(); queue.Enqueue(start);
        var directions = new[] { new Point(0, 1), new Point(-1, 0), new Point(1, 0), new Point(0, -1) };
        while (queue.Count > 0)
        {
            var p = queue.Dequeue();
            if (distance[p] >= 12) continue;
            foreach (var d in directions)
            {
                var n = p + d;
                if (distance.ContainsKey(n) || n.X < 0 || n.Y < 0 || n.X >= farm.Map.Layers[0].LayerWidth || n.Y >= farm.Map.Layers[0].LayerHeight) continue;
                if (farm.isCollidingPosition(new Rectangle(n.X * 64 + 1, n.Y * 64 + 1, 62, 62), Game1.viewport, true, 0, false, player, pathfinding: true)) continue;
                distance[n] = distance[p] + 1; parent[n] = p; queue.Enqueue(n);
            }
        }
        var reachable = candidates.Select(j =>
        {
            var approaches = directions.Select(d => j.Tile.ToPoint() + d).Where(p => distance.ContainsKey(p))
                .OrderBy(p => distance[p]).ToList();
            return (Job: j, Approach: approaches.FirstOrDefault(), Steps: approaches.Count == 0 ? int.MaxValue : distance[approaches[0]]);
        }).Where(j => j.Steps <= 12).ToList();
        if (reachable.Count == 0) return false;
        var chosen = reachable.OrderBy(j => j.Steps).ThenBy(j => j.Job.Kind == "Hoe" ? 1 : 0)
            .ThenBy(j => clearingSection.HasValue && Section(j.Job.Tile) == clearingSection ? 0 : 1)
            .ThenBy(j => j.Job.Tile.Y).ThenBy(j => ((int)j.Job.Tile.Y - layoutY) % 2 == 0 ? j.Job.Tile.X : -j.Job.Tile.X).First();
        clearingSection = Section(chosen.Job.Tile);
        if (chosen.Steps > 0)
        {
            var path = new Stack<Point>();
            for (var p = chosen.Approach; p != start; p = parent[p]) path.Push(p);
            player.controller = new PathFindController(path, farm, player, chosen.Approach); OwnWalkingSpeed();
        }
        target = chosen.Job.Tile; task = chosen.Job.Kind; pathStarted = DateTime.UtcNow;
        Status.Activity = chosen.Steps == 0 ? task : "Walking to " + task.ToLowerInvariant();
        owner.LogEvidence("work_route", new { kind = task, x = target.Value.X, y = target.Value.Y, steps = chosen.Steps, nearby = true, sectionX = clearingSection.Value.X, sectionY = clearingSection.Value.Y });
        return true;
    }
    private Dictionary<string, int> InventoryCounts() => Game1.player.Items.Where(i => i is SObject).GroupBy(i => i.QualifiedItemId + ":" + ((SObject)i).Quality).ToDictionary(g => g.Key, g => g.Sum(i => i.Stack));
    private void RecordHarvest(Dictionary<string, int> before)
    {
        foreach (var pair in InventoryCounts())
        {
            int delta = pair.Value - before.GetValueOrDefault(pair.Key);
            if (delta > 0) Save.Harvested[pair.Key] = Save.Harvested.GetValueOrDefault(pair.Key) + delta;
        }
    }
    private SObject? GetSeed(Farm farm)
    {
        var crops = DataLoader.Crops(Game1.content);
        int days = 28 - Game1.dayOfMonth;
        return Game1.player.Items.OfType<SObject>().Where(i => crops.TryGetValue(i.ItemId, out var c) && c.Seasons.Contains(farm.GetSeason()) && !c.IsRaised && c.HarvestMethod == HarvestMethod.Grab && c.DaysInPhase.Sum() <= days)
            .OrderBy(i => i.Stack).FirstOrDefault();
    }
    private bool ExecuteTask(Farm farm)
    {
        if (target is not Vector2 tile) return false;
        if (Game1.player.controller != null)
        {
            return true;
        }
        if (Vector2.Distance(Game1.player.Tile, tile) > 1.6f) { blocked.Add(tile); target = null; return true; }
        var who = Game1.player;
        farm.terrainFeatures.TryGetValue(tile, out var feature);
        var dirt = feature as HoeDirt;
        bool success = false;
        float stamina = who.Stamina;
        int water = who.Items.OfType<WateringCan>().FirstOrDefault()?.WaterLeft ?? 0;
        Status.Activity = task;
        switch (task)
        {
            case "Harvest":
                if (dirt?.crop != null && dirt.readyForHarvest() && who.couldInventoryAcceptThisItem(ItemRegistry.Create(dirt.crop.indexOfHarvest.Value)))
                {
                    var before = InventoryCounts();
                    var capture = harvestSettlement.BeforeHarvest(farm, dirt.crop.indexOfHarvest.Value);
                    if (dirt.crop.harvest((int)tile.X, (int)tile.Y, dirt, null, false)) dirt.crop = null;
                    int extras = harvestSettlement.AfterHarvest(capture);
                    RecordHarvest(before);
                    success = extras > 0 || InventoryCounts().Any(p => p.Value > before.GetValueOrDefault(p.Key));
                    if (success) Status.Harvested++;
                    else Status.Reason = "Inventory needs space to harvest this crop quality";
                    if (extras > 0) { pickupTile = tile; pickupStarted = DateTime.UtcNow; }
                }
                else Status.Reason = "Inventory full or crop changed";
                break;
            case "Water":
                if (dirt?.crop != null && dirt.state.Value != 1 && who.Items.OfType<WateringCan>().FirstOrDefault() is { WaterLeft: > 0 } can)
                { StartTool(can, farm, tile); return true; }
                break;
            case "Hoe":
                if (IsCandidate(farm, tile) && feature == null && !farm.objects.ContainsKey(tile) && who.Items.OfType<Hoe>().FirstOrDefault() is { } hoe)
                { StartTool(hoe, farm, tile); return true; }
                break;
            case "Plant":
                if (dirt != null && dirt.crop == null && GetSeed(farm) is { } seed)
                {
                    who.CurrentToolIndex = who.Items.IndexOf(seed); who.netItemStowed.Value = false;
                    who.faceGeneralDirection(tile * 64f + new Vector2(32));
                    Utility.tryToPlaceItem(farm, seed, (int)tile.X * 64 + 32, (int)tile.Y * 64 + 32);
                    success = dirt.crop != null; if (success) Status.Planted++;
                }
                break;
            case "Clear":
                if (Config.ClearDebris && farm.objects.TryGetValue(tile, out var debris) && IsKnownDebris(debris))
                {
                    Tool? tool = debris.Name == "Stone" ? who.Items.OfType<Pickaxe>().FirstOrDefault() : who.Items.OfType<Axe>().FirstOrDefault();
                    if (tool != null) { StartTool(tool, farm, tile); return true; }
                }
                break;
            case "Chop":
                if (feature is Tree tree && IsSafeTree(farm, tile, tree) && who.Items.OfType<Axe>().FirstOrDefault() is { } axe)
                {
                    if (tree.falling.Value) { Status.Activity = "Waiting for tree to fall"; return true; }
                    if (CanFinishTree(farm, tree, axe)) { StartTool(axe, farm, tile); return true; }
                    Status.Reason = "Not enough spare energy to finish this tree and stump";
                }
                break;
            case "Clear grass":
                if (Config.ClearDebris && feature is Grass)
                {
                    Tool? grassTool = who.Items.OfType<MeleeWeapon>().FirstOrDefault(w => w.isScythe());
                    if (grassTool != null) { StartTool(grassTool, farm, tile); return true; }
                }
                break;
            case "Refill":
                if (who.Items.OfType<WateringCan>().FirstOrDefault() is { } watering)
                { StartTool(watering, farm, tile); return true; }
                break;
            case "Clear dead crop":
                Tool? deadCropTool = who.Items.OfType<MeleeWeapon>().FirstOrDefault(w => w.isScythe()) ?? (Tool?)who.Items.OfType<Axe>().FirstOrDefault();
                if (dirt?.crop?.dead.Value == true && deadCropTool != null)
                { StartTool(deadCropTool, farm, tile); return true; }
                break;
        }
        if (success)
        {
            completionRechecked = false;
            Status.Actions++; idleFrames = 0;
            owner.LogEvidence("action", new { task, x = tile.X, y = tile.Y, staminaBefore = stamina, staminaAfter = who.Stamina, waterBefore = water, waterAfter = who.Items.OfType<WateringCan>().FirstOrDefault()?.WaterLeft, money = who.Money });
        }
        else if (!Status.Reason.Contains("Inventory", StringComparison.OrdinalIgnoreCase)) blocked.Add(tile);
        target = null; task = "";
        return true;
    }
    private void StartTool(Tool tool, Farm farm, Vector2 tile)
    {
        lastOwnedToolAt = DateTime.UtcNow;
        if (task == "Chop") committedTree = tile;
        nativeAction = new NativeToolAction(owner, farm, tile, task, tool);
    }
    public bool TickNativeTool()
    {
        harvestSettlement.Update();
        if (nativeAction == null) return false;
        lastOwnedToolAt = DateTime.UtcNow;
        if (Game1.activeClickableMenu != null || Game1.eventUp || Game1.fadeToBlack) return true;
        if (!nativeAction.Update()) return true;
        var action = nativeAction;
        nativeAction = null; action.ReleaseSpeed();
        if (action.Succeeded)
        {
            completionRechecked = false;
            Status.Actions++; idleFrames = 0;
            if (action.Kind == "Water") Status.Watered++;
            if (action.Kind is "Clear" or "Clear dead crop") Status.Cleared++;
            if (action.Kind == "Clear grass" && (!Game1.getFarm().terrainFeatures.TryGetValue(action.Tile, out var grass)
                || grass is not Grass)) Status.GrassCleared++;
            if (action.Kind is "Hoe" or "Clear" or "Clear grass")
            {
                RememberWorkedTile(Game1.getFarm(), action.Tile);
                if (action.Kind == "Clear grass") committedGrass = Game1.getFarm().terrainFeatures.TryGetValue(action.Tile, out var remaining)
                    && remaining is Grass ? action.Tile : null;
            }
            if (action.Kind == "Chop" && !Game1.getFarm().terrainFeatures.ContainsKey(action.Tile))
                FinishCommittedTree(Game1.getFarm(), action.Tile);
            owner.LogEvidence("action", new { task = action.Kind, x = action.Tile.X, y = action.Tile.Y, staminaBefore = action.StaminaBefore, staminaAfter = Game1.player.Stamina, waterBefore = action.WaterBefore, waterAfter = Game1.player.Items.OfType<WateringCan>().FirstOrDefault()?.WaterLeft, money = Game1.player.Money, animation = true });
        }
        else
        {
            if (!Game1.isWarping && Game1.locationRequest == null && !Game1.fadeToBlack
                && action.Kind is "Water" or "Refill" or "Hoe" or "Clear dead crop")
            {
                owner.PauseSafely("Paused: native tool action failed", "A required tool action could not finish. Check the tool and target tile, then press F8 to retry.");
                return true;
            }
            blocked.Add(action.Tile); Status.Reason = "Tool action could not complete at " + action.Tile;
        }
        target = null; task = "";
        return true;
    }
    private bool ShipOwnCrops(Farm farm)
    {
        if (!Config.AutoShip) return false;
        // Harvest ownership spans the backpack and every precisely tagged
        // assistant chest owned by this farmer. A blocked chest route affects
        // access, never the quantity of owned produce recorded in the ledger.
        var stacks = storage.GetOwnedItemStacks(farm);
        var inventory = stacks.GroupBy(stack => stack.Item.QualifiedItemId + ":" + stack.Item.Quality)
            .ToDictionary(group => group.Key, group => group.Sum(stack => stack.Item.Stack));
        foreach (string key in Save.Harvested.Keys.ToArray())
            Save.Harvested[key] = Math.Clamp(Save.Harvested[key], 0, inventory.GetValueOrDefault(key));
        var allowed = DataLoader.Crops(Game1.content).Values.Select(c => ItemRegistry.QualifyItemId(c.HarvestItemId)).ToHashSet();
        var questReserves = stacks.Select(stack => stack.Item).Where(i => allowed.Contains(i.QualifiedItemId))
            .GroupBy(i => i.QualifiedItemId).ToDictionary(g => g.Key, g => g.Max(QuestCropReserve.RequiredFor));
        var surplus = new Dictionary<string, int>();
        foreach (var crop in stacks.Select(stack => stack.Item).Where(item => allowed.Contains(item.QualifiedItemId))
                     .GroupBy(item => item.QualifiedItemId))
        {
            // KeepEachCrop is one total per crop, not one reserve per quality,
            // stack, or container. Retain high quality first as before.
            int remainingReserve = Math.Max(Config.KeepEachCrop, questReserves.GetValueOrDefault(crop.Key));
            foreach (var quality in crop.GroupBy(item => item.Quality).OrderByDescending(group => group.Key))
            {
                string key = crop.Key + ":" + quality.Key;
                int owned = Save.Harvested.GetValueOrDefault(key);
                int keep = Math.Min(owned, remainingReserve);
                remainingReserve -= keep;
                if (owned > keep) surplus[key] = owned - keep;
            }
        }

        bool shipped = false;
        foreach (var stack in stacks.Where(stack => !stack.ChestTile.HasValue))
        {
            SObject item = stack.Item;
            string key = item.QualifiedItemId + ":" + item.Quality;
            if (!item.canBeShipped() || !item.canBeTrashed()) continue;
            int quantity = Math.Min(item.Stack, surplus.GetValueOrDefault(key));
            if (quantity <= 0) continue;
            Item copy = item.getOne(); copy.Stack = quantity;
            farm.getShippingBin(Game1.player).Add(copy);
            item.Stack -= quantity;
            if (item.Stack <= 0) Game1.player.Items[Game1.player.Items.IndexOf(item)] = null;
            surplus[key] -= quantity;
            Save.Harvested[key] -= quantity; Status.Shipped += quantity; shipped = true;
            owner.LogEvidence("shipping", new
            {
                item = copy.QualifiedItemId, copy.Stack, source = "backpack",
                reserve = Math.Max(Config.KeepEachCrop, questReserves.GetValueOrDefault(item.QualifiedItemId)),
                questReserve = questReserves.GetValueOrDefault(item.QualifiedItemId), ledgerAfter = Save.Harvested[key]
            });
        }
        if (shipped) return true;
        return storage.TryShipOwnedSurplus(farm, surplus);
    }
    private bool InRegion(Vector2 tile) => Save.RegionX < 0 || tile.X >= Save.RegionX && tile.Y >= Save.RegionY
        && tile.X < Save.RegionX + Save.RegionWidth && tile.Y < Save.RegionY + Save.RegionHeight;
    private bool IsSafeTree(Farm farm, Vector2 tile, Tree tree) => Config.ClearTrees && InRegion(tile)
        && tree.treeType.Value is ("1" or "2" or "3") && !tree.tapped.Value && !tree.fertilized.Value
        && !tree.modData.Any() && !farm.objects.ContainsKey(tile);
    private bool CanFinishTree(Farm farm, Tree tree, Axe axe)
    {
        double damage = axe.UpgradeLevel switch { 1 => 1.25, 2 => 1.67, 3 => 2.5, 4 => 5, _ => 1 };
        int hits = tree.growthStage.Value <= 3 ? 1 : (int)Math.Ceiling(Math.Max(0, tree.health.Value) / damage);
        if (tree.growthStage.Value >= 5 && !tree.stump.Value) hits += (int)Math.Ceiling(5 / damage);
        double energy = axe.enchantments.Any(e => e.GetType().Name == "EfficientEnchantment") ? 0 : Math.Max(0, 2 - .1 * Game1.player.ForagingLevel);
        int dry = farm.IsRainingHere() ? 0 : plots.Count(t => farm.terrainFeatures.TryGetValue(t, out var f)
            && f is HoeDirt hd && hd.crop != null && !hd.crop.dead.Value && !hd.readyForHarvest() && hd.state.Value != 1);
        double watering = dry * Math.Max(0, 2 - .1 * Game1.player.FarmingLevel);
        return Game1.player.Stamina >= Config.ReserveEnergy + watering + hits * energy + 4;
    }
    private bool TryClearFrontier(Farm farm)
    {
        if (!Config.ClearTrees || Status.TreesCleared >= Config.MaxTreesPerDay
            || Game1.player.Items.OfType<Axe>().FirstOrDefault() is not { } axe) return false;
        var boundary = plots.ToHashSet();
        var trees = farm.terrainFeatures.Pairs.Where(p => p.Value is Tree tree && IsSafeTree(farm, p.Key, tree))
            .Where(p => new[] { new Vector2(0, 1), new Vector2(0, -1), new Vector2(1, 0), new Vector2(-1, 0) }.Any(d => boundary.Contains(p.Key + d)))
            .OrderBy(p => ((Tree)p.Value).stump.Value ? 0 : 1)
            .ThenBy(p => Vector2.DistanceSquared(p.Key, Game1.player.Tile));
        return TryNearbyClearing(farm, trees.Where(p => !((Tree)p.Value).falling.Value
            && CanFinishTree(farm, (Tree)p.Value, axe)).Select(p => (p.Key, "Chop")));
    }
    private bool TryExpandFarm(Farm farm, bool allowHoe)
    {
        if (committedGrass.HasValue)
        {
            if (farm.terrainFeatures.TryGetValue(committedGrass.Value, out var grassFeature) && grassFeature is Grass
                && BeginTask(farm, committedGrass.Value, "Clear grass")) return true;
            committedGrass = null;
        }
        if (committedTree.HasValue)
        {
            var treeTile = committedTree.Value;
            if (!farm.terrainFeatures.TryGetValue(treeTile, out var activeFeature) || activeFeature is not Tree activeTree)
                FinishCommittedTree(farm, treeTile);
            else if (activeTree.falling.Value)
            {
                if (fallingTreeSince == DateTime.MinValue) fallingTreeSince = DateTime.UtcNow;
                if ((DateTime.UtcNow - fallingTreeSince).TotalSeconds > 8)
                    owner.PauseSafely("Paused: tree animation stalled", "The original falling-tree animation has not finished. Resume after it finishes.");
                else Status.Activity = "Waiting for tree to fall";
                return true;
            }
            else if (Game1.player.Items.OfType<Axe>().FirstOrDefault() is { } axe && IsSafeTree(farm, treeTile, activeTree)
                && CanFinishTree(farm, activeTree, axe) && BeginTask(farm, treeTile, "Chop"))
            { fallingTreeSince = DateTime.MinValue; return true; }
        }
        committedTree = null; fallingTreeSince = DateTime.MinValue;
        var jobs = new List<(Vector2 Tile, string Kind)>();
        if (Config.ClearDebris)
        {
            jobs.AddRange(farm.objects.Pairs.Where(p => InRegion(p.Key) && IsKnownDebris(p.Value)).Select(p => (p.Key, "Clear")));
            jobs.AddRange(farm.terrainFeatures.Pairs.Where(p => InRegion(p.Key) && p.Value is Grass).Select(p => (p.Key, "Clear grass")));
        }
        if (Config.ClearTrees && Status.TreesCleared < Config.MaxTreesPerDay && Game1.player.Items.OfType<Axe>().FirstOrDefault() is { } treeAxe)
            jobs.AddRange(farm.terrainFeatures.Pairs.Where(p => p.Value is Tree t && IsSafeTree(farm, p.Key, t)
                && !t.falling.Value && CanFinishTree(farm, t, treeAxe)).Select(p => (p.Key, "Chop")));
        if (allowHoe)
            jobs.AddRange(plots.Where(t => !farm.objects.ContainsKey(t) && !farm.terrainFeatures.ContainsKey(t)).Select(t => (t, "Hoe")));
        jobs = jobs.Where(j => !blocked.Contains(j.Tile)).ToList();
        bool Adjacent(Vector2 t) => Math.Abs(t.X - Game1.player.Tile.X) + Math.Abs(t.Y - Game1.player.Tile.Y) == 1;
        // A two-tile empty corridor may connect the next part of the same patch.
        // Only the corridor to the chosen work tile is retained, never the whole farm.
        var corridorRoots = expansionCore.ToList();
        if (corridorRoots.Count == 0 && expansionSeed.HasValue) corridorRoots.Add(expansionSeed.Value.ToPoint());
        var distance = corridorRoots.ToDictionary(p => p, _ => 0);
        var parent = new Dictionary<Point, Point>();
        var queue = new Queue<Point>(corridorRoots);
        var directions = new[] { new Point(0, 1), new Point(-1, 0), new Point(1, 0), new Point(0, -1) };
        while (queue.Count > 0)
        {
            var p = queue.Dequeue(); if (distance[p] >= 2) continue;
            foreach (var d in directions)
            {
                var n = p + d; var tile = n.ToVector2();
                if (distance.ContainsKey(n) || !IsCandidate(farm, tile) || farm.objects.ContainsKey(tile)
                    || farm.terrainFeatures.TryGetValue(tile, out var f) && f is not HoeDirt) continue;
                distance[n] = distance[p] + 1; parent[n] = p; queue.Enqueue(n);
            }
        }
        // Direct-edge and corridor jobs compete together. A farther direct-edge
        // tree must not suppress a closer weed just across one empty tile.
        var bridged = jobs.Where(j => OnExpansionEdge(j.Tile)
            || directions.Any(d => distance.ContainsKey(j.Tile.ToPoint() + d))).ToList();
        if (!TryNearbyClearing(farm, bridged)) return false;
        expansionBridge.Clear(); expansionBridgeTarget = target;
        var joins = directions.Select(d => target!.Value.ToPoint() + d).Where(distance.ContainsKey).OrderBy(p => distance[p]).ToList();
        int bridge = joins.Count == 0 ? 0 : distance[joins[0]];
        if (joins.Count > 0) for (var p = joins[0]; distance[p] > 0; p = parent[p]) expansionBridge.Add(p.ToVector2());
        owner.LogEvidence("expansion_selection", new { kind = task, x = target!.Value.X, y = target.Value.Y,
            edge = OnExpansionEdge(target.Value), adjacent = Adjacent(target.Value), core = expansionCore.Count, candidates = bridged.Count, bridge });
        return true;
    }
    private void FinishCommittedTree(Farm farm, Vector2 tile)
    {
        Status.TreesCleared++; RememberWorkedTile(farm, tile);
        committedTree = null; fallingTreeSince = DateTime.MinValue;
        plots.Clear(); blocked.Clear();
        owner.LogEvidence("tree_cleared", new { x = tile.X, y = tile.Y, total = Status.TreesCleared });
    }
    private bool TryBuySeeds(Farm farm, int slots)
    {
        seedPurchaseNeedsSpace = false;
        // Vanilla inventory APIs inspect Items.Count, not just MaxItems.
        // Maintain the same null-slot invariant used by the game's backpack upgrade.
        while (Game1.player.Items.Count < Game1.player.MaxItems) Game1.player.Items.Add(null);
        if (!Config.AutoBuySeeds || slots <= 0 || Game1.player.Money <= Config.ReserveGold || Game1.dayOfMonth >= 28) return false;
        if ((DateTime.UtcNow - lastPurchase).TotalSeconds < 2) return false;
        bool closed = Game1.Date.DayOfWeek == DayOfWeek.Wednesday && !Game1.MasterPlayer.hasOrWillReceiveMail("ccIsComplete");
        if (closed) { Status.Reason = "Pierre is closed today"; return false; }
        if (Game1.timeOfDay < 900) { Status.Activity = "Waiting for seed delivery at 09:00"; return true; }
        if (Game1.timeOfDay >= 1700) return false;
        lastPurchase = DateTime.UtcNow;
        var crops = DataLoader.Crops(Game1.content);
        var stock = ShopBuilder.GetShopStock("SeedShop");
        var options = new List<CropOption>();
        foreach (var pair in stock)
        {
            if (pair.Key is not SObject item || !crops.TryGetValue(item.ItemId, out var data) || !data.Seasons.Contains(farm.GetSeason()) || data.IsRaised || data.HarvestMethod != HarvestMethod.Grab || pair.Value.TradeItem != null || pair.Value.Price <= 0) continue;
            int remaining = pair.Value.Stock == int.MaxValue ? slots : Math.Max(0, pair.Value.Stock - purchasedToday.GetValueOrDefault(item.ItemId));
            var harvest = ItemRegistry.Create<SObject>(data.HarvestItemId);
            double yield = (data.HarvestMinStack + data.HarvestMaxStack + Math.Floor(data.HarvestMaxIncreasePerFarmingLevel * Game1.player.FarmingLevel)) / 2.0;
            if (data.ExtraHarvestChance > 0 && data.ExtraHarvestChance < 1) yield += data.ExtraHarvestChance / (1 - data.ExtraHarvestChance);
            options.Add(new CropOption(item.ItemId, item.DisplayName, pair.Value.Price, harvest.sellToStorePrice(), yield, data.DaysInPhase.Sum(), data.RegrowDays, remaining, data.IsRaised));
        }
        var plan = CropPlanner.Plan(options, 28 - Game1.dayOfMonth, Math.Min(100000, Game1.player.Money - Config.ReserveGold), slots, Config.ProfitMode);
        Status.CropChoice = plan.Purchases.Count > 0 ? string.Join(" + ", plan.Purchases.Select(a => a.Crop.Name + " ×" + a.Quantity)) : "No affordable crop";
        Status.Reason = plan.Explanation;
        foreach (var allocation in plan.Purchases)
        {
            int quantity = allocation.Quantity;
            var item = ItemRegistry.Create<SObject>(allocation.Crop.SeedId, quantity);
            if (!Game1.player.couldInventoryAcceptThisItem(item))
            {
                seedPurchaseNeedsSpace = true;
                Status.Reason = "Inventory needs space before seed delivery";
                continue;
            }
            int cost = quantity * allocation.Crop.SeedPrice;
            if (Game1.player.Money - cost < Config.ReserveGold) continue;
            Game1.player.addItemToInventoryBool(item); Game1.player.Money -= cost;
            purchasedToday[allocation.Crop.SeedId] = purchasedToday.GetValueOrDefault(allocation.Crop.SeedId) + quantity;
            Status.Bought += quantity;
            owner.LogEvidence("purchase", new { seed = allocation.Crop.SeedId, quantity, cost, moneyAfter = Game1.player.Money, plan.ExpectedProfit, plan.Explanation });
        }
        return Status.Bought > 0 && GetSeed(farm) != null;
    }
    private bool Refill(Farm farm)
    {
        var water = new List<Vector2>();
        for (int y = 1; y < farm.Map.Layers[0].LayerHeight - 1; y++)
            for (int x = 1; x < farm.Map.Layers[0].LayerWidth - 1; x++)
                if (farm.doesTileHaveProperty(x, y, "Water", "Back") != null) water.Add(new Vector2(x, y));
        foreach (var tile in water.OrderBy(t => Vector2.DistanceSquared(t, Game1.player.Tile)).Take(40))
            if (BeginTask(farm, tile, "Refill")) return true;
        Status.Reason = "No reachable water source"; return false;
    }
    private bool GoToSleep()
    {
        if (!returningToSleep)
            Status.SleepReason = Game1.player.Stamina <= Config.ReserveEnergy ? "Energy reserve reached"
                : Game1.timeOfDay >= Config.SleepTime ? "Bedtime reached"
                : "Nearby reachable farm work complete";
        returningToSleep = true;
        if (ShipOwnCrops(Game1.getFarm())) return true;
        var home = Utility.getHomeOfFarmer(Game1.player);
        if (Game1.currentLocation is Farm)
        {
            var entry = Game1.getFarm().GetMainFarmHouseEntry();
            if (Vector2.Distance(Game1.player.Tile, entry.ToVector2()) > 1.1f)
            { WalkTo(entry, "Returning home"); return true; }
            Game1.getFarm().checkAction(new xTile.Dimensions.Location(entry.X, entry.Y - 1), Game1.viewport, Game1.player);
            return true;
        }
        if (Game1.currentLocation != home)
        { owner.PauseSafely("Paused: outside farm", "Return to your farm or farmhouse, then press F8 to resume farming."); return true; }
        var bed = home.GetPlayerBedSpot();
        if (Vector2.Distance(Game1.player.Tile, bed.ToVector2()) > 1f) { WalkTo(bed, "Walking to bed"); return true; }
        Cancel(); sleepCycle = true;
        ownedNightDay = Game1.Date.TotalDays; ownedNightDayStarted = false; nightTransitionWaitLogged = false;
        Game1.player.isInBed.Value = true;
        home.answerDialogueAction("Sleep_Yes", Array.Empty<string>());
        Status.Activity = "Sleeping";
        owner.LogEvidence("sleep", new { day = Game1.dayOfMonth, time = Game1.timeOfDay, Game1.player.Stamina });
        return true;
    }
    public bool TryStep()
    {
        // Purchase blockage belongs to this decision pass, never a prior day/action.
        seedPurchaseNeedsSpace = false;
        if (!IsAvailable) return false;
        if (Game1.isWarping || Game1.locationRequest != null)
        {
            // A player path controller at a warp tile can request the same warp
            // every frame, restarting the original fade before it completes.
            Game1.player.controller = null;
            target = null;
            Status.Activity = "Changing location";
            return true;
        }
        if (Game1.eventUp || Game1.activeClickableMenu != null || Game1.fadeToBlack || Game1.player.UsingTool || Game1.player.isEating) { Status.Activity = "Paused for menu/event"; return true; }
        if (!Game1.player.CanMove) { Status.Activity = "Finishing character action"; return true; }
        if (!Config.AutoSleep && Game1.timeOfDay >= Config.SleepTime)
        { owner.PauseSafely("Paused: manual bedtime reached", "Bedtime is reached and automatic sleep is off. Sleep manually or change bedtime, then press F8."); return true; }
        if (Game1.player.controller != null && task == "travel")
        {
            return true;
        }
        bool lowEnergy = Game1.player.Stamina <= Config.ReserveEnergy;
        bool wantsSleep = Config.AutoSleep && (returningToSleep || Game1.timeOfDay >= Config.SleepTime || lowEnergy && Config.SleepOnLowEnergy || task == "sleep");
        bool forcedSleep = Config.AutoSleep && (returningToSleep || Game1.timeOfDay >= Config.SleepTime || task == "sleep");
        if (forcedSleep && !harvestSettlement.HasPending)
        {
            // Bedtime skips new field work, but must not bypass recovery for a
            // full backpack with mature crops. Try owned shipping/storage first.
            if (Game1.currentLocation is Farm bedtimeFarm)
            {
                if (plots.Count == 0) BuildLayout(bedtimeFarm);
                if (ShipOwnCrops(bedtimeFarm)) return true;
                if (Config.AutoStorage && storage.TryMakeSpace(bedtimeFarm)) return true;
                if (Game1.player.freeSpotsInInventory() == 0 && plots.Any(tile => bedtimeFarm.terrainFeatures.TryGetValue(tile, out var feature) && feature is HoeDirt dirt && dirt.readyForHarvest()))
                {
                    owner.PauseSafely("Paused: backpack needs space", "Mature crops remain, but shipping and storage cannot free a safe slot. Free a backpack slot, then press F8.");
                    return true;
                }
            }
            task = "sleep";
            return GoToSleep();
        }
        if (Game1.currentLocation is FarmHouse home)
        {
            var parcel = home.objects.Pairs.FirstOrDefault(p => p.Value is Chest chest && chest.giftbox.Value);
            if (parcel.Value != null)
            {
                if (!ownedParcelPending) { ownedParcelPending = true; parcelStarted = DateTime.UtcNow; }
                parcel.Value.checkForAction(Game1.player);
                if (Game1.activeClickableMenu is StardewValley.Menus.DialogueBox { isQuestion: false, characterDialogue: null } notification)
                { ownedParcelDialogue = notification; lastParcelAdvance = DateTime.UtcNow; }
                return true;
            }
            var door = home.getWarpPointTo("Farm");
            WalkTo(door, "Walking to farm"); return true;
        }
        if (Game1.currentLocation is not Farm farm)
        { owner.PauseSafely("Paused: outside farm", "Return to your farm or farmhouse, then press F8 to resume farming."); return true; }
        if (plots.Count == 0) BuildLayout(farm);
        if (plots.Count == 0)
        {
            owner.PauseSafely("Paused: no safe farmable tiles", "The selected region has no safe farmable tiles. Change the region, then press F8.");
            return true;
        }
        if (target.HasValue) return ExecuteTask(farm);
        if (ShipOwnCrops(farm)) return true;
        if (Config.AutoStorage && storage.TryMakeSpace(farm)) return true;
        if (harvestSettlement.HasPending && pickupTile.HasValue)
        {
            if (Game1.player.freeSpotsInInventory() == 0)
            {
                owner.PauseSafely("Paused: backpack needs space", "Harvested crop drops are waiting for pickup. Free a backpack slot, then press F8 before sleeping.");
                return true;
            }
            if ((DateTime.UtcNow - pickupStarted).TotalSeconds > 8)
            {
                owner.PauseSafely("Paused: harvest pickup stalled", "Harvested crop drops could not be picked up. Move closer or free a backpack slot, then press F8.");
                return true;
            }
            else
            {
                if (Vector2.Distance(Game1.player.Tile, pickupTile.Value) > 1.6f)
                    WalkTo(pickupTile.Value.ToPoint(), "Walking to harvest pickup");
                if (!Save.Enabled) return true;
                Status.Activity = "Waiting for harvest pickup";
                return true;
            }
        }
        // Work through compact 3x3 sections in serpentine rows, rather than
        // bouncing between isolated tiles across the managed field.
        var ordered = plots.GroupBy(t => ((int)Math.Floor((t.X - layoutX) / 3), (int)Math.Floor((t.Y - layoutY) / 3)))
            .OrderBy(g => g.Key.Item2).ThenBy(g => g.Key.Item2 % 2 == 0 ? g.Key.Item1 : -g.Key.Item1)
            .SelectMany(g => g.OrderBy(t => t.Y).ThenBy(t => ((int)t.Y - layoutY) % 2 == 0 ? t.X : -t.X)).ToList();
        foreach (var tile in ordered)
            if (farm.terrainFeatures.TryGetValue(tile, out var deadFeature) && deadFeature is HoeDirt { crop: not null } deadDirt && deadDirt.crop.dead.Value)
            {
                bool hasScythe = Game1.player.Items.OfType<MeleeWeapon>().Any(w => w.isScythe());
                if (!hasScythe && !Game1.player.Items.OfType<Axe>().Any())
                { owner.PauseSafely("Paused: required farming tool missing", "Dead crops need a scythe or axe. Put one in the backpack, then press F8."); return true; }
                if ((hasScythe || Game1.player.Stamina > Config.ReserveEnergy + 4) && BeginTask(farm, tile, "Clear dead crop")) return true;
            }
        foreach (var tile in ordered)
            if (Game1.player.freeSpotsInInventory() > 0 && farm.terrainFeatures.TryGetValue(tile, out var tf) && tf is HoeDirt hd && hd.readyForHarvest() && BeginTask(farm, tile, "Harvest")) return true;
        if (!returningToSleep && Game1.timeOfDay < Config.SleepTime && GetSeed(farm) != null)
            foreach (var tile in ordered)
                if (farm.terrainFeatures.TryGetValue(tile, out var tf) && tf is HoeDirt { crop: null } emptyDirt
                    && (farm.IsRainingHere() || emptyDirt.state.Value == 1 || Game1.player.Stamina > Config.ReserveEnergy + 4)
                    && BeginTask(farm, tile, "Plant")) return true;
        if ((wantsSleep || lowEnergy) && Game1.player.freeSpotsInInventory() == 0
            && ordered.Any(tile => farm.terrainFeatures.TryGetValue(tile, out var feature) && feature is HoeDirt hd && hd.readyForHarvest()))
        { owner.PauseSafely("Paused: backpack needs space", "Mature crops remain, but shipping and storage cannot free a safe slot. Free a backpack slot, then press F8."); return true; }
        // Zero-energy harvest and scythe cleanup happen before the energy reserve.
        // Watering and expansion still respect that reserve, preventing exhaustion.
        if (ordered.Any(tile => farm.terrainFeatures.TryGetValue(tile, out var feature) && feature is HoeDirt dirt && dirt.readyForHarvest())
            && Game1.player.freeSpotsInInventory() > 0) return RecheckRequiredWork("A mature crop is still waiting on an unreachable work tile.");
        if (ordered.Any(tile => farm.terrainFeatures.TryGetValue(tile, out var feature) && feature is HoeDirt { crop: not null } dirt && dirt.crop.dead.Value)
            && (Game1.player.Items.OfType<MeleeWeapon>().Any(w => w.isScythe()) || !lowEnergy))
            return RecheckRequiredWork("A dead crop is still waiting on an unreachable work tile.");
        if (Game1.timeOfDay < Config.SleepTime && GetSeed(farm) != null
            && ordered.Any(tile => farm.terrainFeatures.TryGetValue(tile, out var feature) && feature is HoeDirt { crop: null } dirt
                && (farm.IsRainingHere() || dirt.state.Value == 1 || Game1.player.Stamina > Config.ReserveEnergy + 4)))
            return RecheckRequiredWork("A prepared plot still needs seed on an unreachable work tile.");
        if (wantsSleep) { task = "sleep"; return GoToSleep(); }
        if (lowEnergy)
        {
            if (!Config.AutoSleep)
            { owner.PauseSafely("Paused: energy reserve reached", "Energy is at the reserve and automatic sleep is off. Eat or rest, then press F8."); return true; }
            if (!Config.SleepOnLowEnergy)
            { owner.PauseSafely("Paused: energy reserve reached", "Energy is at the reserve. Eat or rest, then press F8."); return true; }
            task = "sleep";
            return GoToSleep();
        }
        // Always irrigate living crops before expanding; never sacrifice them to clearing.
        if (!farm.IsRainingHere())
        {
            var dry = ordered.Where(t => farm.terrainFeatures.TryGetValue(t, out var tf) && tf is HoeDirt hd && hd.crop != null && !hd.crop.dead.Value && !hd.readyForHarvest() && hd.state.Value != 1).ToList();
            if (dry.Count > 0)
            {
                var wateringCan = Game1.player.Items.OfType<WateringCan>().FirstOrDefault();
                if (wateringCan == null)
                {
                    owner.PauseSafely("Paused: required farming tool missing", "Watering can missing; put it in the backpack and press F8.");
                    return true;
                }
                if (wateringCan.WaterLeft == 0)
                {
                    if (Refill(farm)) return true;
                    owner.PauseSafely("Paused: no reachable water source", "Watering cannot continue in this region. Change the region or refill the watering can, then press F8.");
                    return true;
                }
                foreach (var t in dry) if (BeginTask(farm, t, "Water")) return true;
                return RecheckRequiredWork("A living crop still needs water on an unreachable work tile.");
            }
        }
        if (ShipOwnCrops(farm)) return true;
        int empty = ordered.Count(t => !farm.terrainFeatures.TryGetValue(t, out var tf) || tf is HoeDirt hd && hd.crop == null);
        if (Config.AutoScarecrow && (DateTime.UtcNow - lastProtectionCheck).TotalSeconds >= 10)
        {
            lastProtectionCheck = DateTime.UtcNow;
            if (protection.TryProtect(farm)) return true;
        }
        var seed = GetSeed(farm);
        if (seed != null)
        {
            if (Game1.player.Items.OfType<Hoe>().FirstOrDefault() == null && ordered.Any(t => !farm.terrainFeatures.ContainsKey(t)))
            {
                owner.PauseSafely("Paused: required farming tool missing", "Hoe missing; put it in the backpack and press F8.");
                return true;
            }
            if (TryExpandFarm(farm, allowHoe: true)) return true;
        }
        else if (TryBuySeeds(farm, empty)) return true;
        if (Config.AutoStorage && Config.ClearDebris && storage.NeedsCraftWood && Game1.player.freeSpotsInInventory() == 0
            && (seedPurchaseNeedsSpace || ordered.Any(t => farm.terrainFeatures.TryGetValue(t, out var f) && f is HoeDirt hd && hd.readyForHarvest()))
            && Game1.player.Stamina > Config.ReserveEnergy + 4)
        {
            // Only ordinary fallen branches supply the real storage recipe.
            // Respect a player-marked region and never cut a tree for storage.
            var branches = farm.objects.Pairs.Where(p => p.Value.Name == "Twig")
                .Where(p => OnExpansionEdge(p.Key))
                .Where(p => Save.RegionX < 0 || p.Key.X >= Save.RegionX && p.Key.Y >= Save.RegionY
                    && p.Key.X < Save.RegionX + Save.RegionWidth && p.Key.Y < Save.RegionY + Save.RegionHeight)
                .Select(p => (p.Key, "Clear"));
            if (TryNearbyClearing(farm, branches)) return true;
        }
        if (Config.PrepareAhead && !seedPurchaseNeedsSpace && Game1.player.Stamina > Config.ReserveEnergy + 4
            && !ordered.Any(t => farm.terrainFeatures.TryGetValue(t, out var f) && f is HoeDirt hd && hd.readyForHarvest()))
        {
            Status.Reason = "Current farming work is cared for; clearing the nearby connected frontier.";
            // All spare-time work competes in one queue at the connected edge.
            // A distant tree or planned plot cannot hide an adjacent weed.
            if (TryExpandFarm(farm, allowHoe: true)) return true;
        }
        if (Game1.player.freeSpotsInInventory() == 0
            && ordered.Any(t => farm.terrainFeatures.TryGetValue(t, out var f) && f is HoeDirt hd && hd.readyForHarvest()))
        {
            owner.PauseSafely("Paused: backpack needs space", "Mature crops remain, but shipping and storage cannot free a safe slot. Free a backpack slot, then press F8.");
            return true;
        }
        if (seedPurchaseNeedsSpace && Game1.player.freeSpotsInInventory() == 0
            && Game1.player.Stamina > Config.ReserveEnergy + 4)
        {
            owner.PauseSafely("Paused: backpack needs space", "Seed purchase needs a backpack slot, and nearby safe storage recovery is unavailable. Free a slot, then press F8.");
            return true;
        }
        if (ordered.Count == 0 && plots.Count > 0)
        {
            owner.PauseSafely("Paused: managed region is unreachable", "No reachable work tile remains. Move the character or change the managed region, then press F8.");
            return true;
        }
        idleFrames++;
        Status.Activity = "Farm work complete";
        Status.Reason = "Current crops are cared for and the reachable management area is prepared. No affordable seeds remain.";
        if (Config.AutoSleep && Config.SleepWhenFinished && idleFrames >= 4) { task = "sleep"; return GoToSleep(); }
        if (idleFrames >= 4)
        { owner.PauseSafely("Farm work complete", "Nearby reachable farming and expansion are complete. Change the region or sleep manually."); return true; }
        return false;
    }
    private bool RecheckRequiredWork(string reason)
    {
        if (!completionRechecked)
        {
            blocked.Clear(); completionRechecked = true;
            Status.Activity = "Replanning interrupted route"; Status.Reason = reason;
            return true;
        }
        owner.PauseSafely("Paused: required route blocked", reason + " Clear the route or move the character, then press F8.");
        return true;
    }
    public void AccelerateOnlyIdle(GameTime time)
    {
        if ((Status.Activity.StartsWith("Waiting for seed") || Status.Activity is "Field ready; waiting until bedtime" or "Energy reserve; waiting until bedtime") && Game1.activeClickableMenu == null && !Game1.eventUp && Game1.shouldTimePass())
            Game1.gameTimeInterval += (int)Math.Min(2000, time.ElapsedGameTime.TotalMilliseconds * (owner.EffectiveWorkSpeed - 1));
    }
}
