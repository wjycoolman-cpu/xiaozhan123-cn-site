# Stardew Farm Assistant

## 1.0.2 路点与木材调度修正

本版按原版脚底碰撞框、当前运动轴和每帧时长限制步长，修复高档位与慢帧下跨过落点后反复换向的机制。实际生产步长函数通过 4356 组几何与帧时长回归；这是几何验证，不是所有地图的穷尽验证。首次修正自然新档记录 277 个移动节点、316 次动作，未记录同路点反向或停滞。

凑箱子木材仅在满包真正阻碍播种/收获、实际缺制作材料时尝试，树枝必须在连通农田边界；不会因为旧提示文字继续寻找木头。普通清树属于农活完成后的开荒，有日上限且保留体力。前期作物未成熟、资金达到保留金额时，可能暂时只有开荒任务；助手会显示当前原因。

下文标为 1.0.1 的性能、经济、化石与跨夜数据是历史原生验证记录，未重新标为本版全量通过；本版新增证据单独列出。

Stardew Farm Assistant is a local SMAPI mod for single-player Stardew Valley farms. After you explicitly start it, the assistant can clear supported obstacles, prepare soil, choose crops using current-season economics, buy seeds at the real SeedShop price, plant, water, harvest, reserve selected crops, ship surplus, and sleep through the normal game flow.

This document describes **version 1.0.2** for local distribution. Two natural farming and reinvestment rounds and four controlled native sleep/save/recovery cycles have passed. No public upload has occurred. The current scope is the farming economy loop. Fishing, mining, full quest progression, the Community Center, and story completion are planned extensions and are not implemented.

## Requirements

- Stardew Valley 1.6.15
- SMAPI 4.5.2 (the current tested target)
- Windows single-player save, with the local player as host

Multiplayer is not currently supported. Stardew Valley and SMAPI are separate dependencies and are not included in this package.

## Install

1. Install Stardew Valley and SMAPI.
2. Close the game and SMAPI.
3. Extract the release ZIP.
4. Copy the extracted `StardewFarmAssistant` folder into your game's `Mods` folder.
5. Launch the game through SMAPI and load a single-player save.
6. Press `F9` to review settings, then stand on the farm and press `F8` to start.

Expected layout:

```text
Stardew Valley/
└─ Mods/
   └─ StardewFarmAssistant/
      ├─ manifest.json
      ├─ StardewFarmAssistant.dll
      └─ ...
```

Any local `.cmd` launchers included with a development workspace are optional test conveniences. They are not required by the community package.

## Controls

| Key | Action |
|---|---|
| `F8` | Start or pause the assistant |
| `F9` | Open or close the assistant settings |
| `F6` | Adjust the work-speed target; Settings supports any integer from 1 to 200 |
| `F7` | Set a managed 12x12 region around the player |
| `F10` | Turn off the managed-region overlay; this build does not turn it back on |
| Arrow keys or `W/A/S/D` | Immediately pause automation and return control to the player |

Every save load starts paused. The mod never resumes control merely because a save was loaded.

## Work modes

| Mode | Policy |
|---|---|
| **Development** | 120-plot target, keep 100g and 5 of each crop, farm first, use remaining capacity for nearby preparation with a 12-tree daily ceiling, sleep when work finishes or energy is low |
| **Showcase** | The same farm-first policy with longer visible native tool timing and a 4-tree daily ceiling |
| **Rush** | Reinvest available money, keep no crops, skip advance preparation and ordinary-tree clearing, sleep when essential farm work finishes or energy is low |
| **Custom** | Keep the user's current combination of settings |

The 120-plot value is a ceiling. Available money, seeds, season timing, safe reachable terrain, backpack room, watering energy, and the configured energy reserve determine how many plots are actually filled.

## 1.0.1 adaptive performance

Adaptive speed uses an integer target from `1` to `200`. Using recent frame P95, assistant P95, task type, and character state, it normally raises the target by 2–5 per adjustment, lowers it by 5 under ordinary pressure, and quickly cuts about 20% when assistant overhead is severe. The HUD labels this value as a work target and reports successful actions per second over the latest three seconds; the Chinese maximum-target text says “200档” rather than “200x”. The no-affordable-crop status is also shown in Chinese. These are work targets, not a whole-engine speed claim.

Manual mode accepts any integer target from `1` to `200`. With the pointer over the work-speed or ceiling control, the mouse wheel changes it by ±1. A click normally adds 5 and adds 1 at low targets. Automatic tuning continues to use 2–5 point adjustments. Target changes preserve the current native action and selected layout.

These values are assistant work targets and do not multiply the whole game engine. Every native tool frame, hit, effect, and callback still runs. Tool candidates keep at least 70 ms of visible time; Showcase uses 160 ms. The obsolete `addedSpeed` setter did not affect movement, so 1.0.1 applies `temporarySpeedBuff` every frame only while the assistant controls the character, capped at 12, and slows near native waypoints to reduce oscillation. Stall detection now measures path-node progress instead of relying only on pixel movement. Unrelated dialogue, cutscenes, menus, warps, and saving pause assistant work. The assistant can acknowledge a matching native item-discovery notice caused by its own farm work after the native presentation finishes.

Performance remains limited by frame rate, pathfinding, collision, native animation timing, energy, inventory space, and the current map. A target of 200 does not mean constant whole-game 200x speed. The controlled target 1/50/200 watering comparison and the separate natural two-round result are documented below; the natural run is not a new whole-engine speed comparison.

## Farming behavior

- Crop selection is recalculated from the current season, remaining days, available money, safe empty plots, crop growth and regrowth, expected yield, sale price, seed cost, and SeedShop inventory.
- Seed purchases deduct the real shop price and add the purchased seed to the backpack.
- Crop reserves are counted per crop across the backpack, exact-owner assistant chests, and all qualities, keeping higher-quality items first. Development defaults to five of each crop, with known quest requirements also protected.
- The harvest ledger follows tracked crops between the backpack and exact-owner assistant chests. Storing a crop does not subtract it; successful shipping does.
- Auto-shipping is limited by tracked harvests and reserve rules. Eligible assistant-grown surplus can be shipped from reachable exact-owner assistant chests, even when the backpack is full.
- Known vanilla quest targets are reserved according to the amount still required. Unknown modded quest formats are not covered.
- Advance preparation clears and hoes safe managed plots after current crops are cared for and affordable seeds are planted.
- Farming always has priority. Clear, grass, chop, and hoe work share one candidate pool on the four-neighbor boundary of a persistent connected worked core. Actual reachable path length sorts first. Adjacent interactions go first only when they belong to that frontier or its allowed safe bridge; being adjacent elsewhere does not start a second clearing island.
- The frontier may bridge at most two safe empty tiles. Only selected safe bridge tiles and completed work enter the core; a partial grass hit does not mark its tile complete. Equal-path candidates use compact-block and snake-order tie breaks; the former “up to two steps farther than global nearest” ordering was removed. Once a tree is selected, the assistant continues through the tree and stump. Safe ordinary trees can be part of the connected plan.
- Existing saved expansion tiles are filtered to one valid four-neighbor connected component. All existing crops still receive care, including crops outside that retained expansion component.
- When no action is selected, the assistant searches nearby for reachable work instead of idling until 23:00. If no work remains, the configured sleep or safe-pause policy applies.
- Sleeping, overnight shipping settlement, and saving use the native game flow.

### Overnight completion and native regression

The latest source revision fixes a premature overnight release: the date could advance before the native new-day sequence finished, and a transient `menu=null` at or after 24:00 had incorrectly been treated as daytime readiness. The assistant now retains overnight ownership through menu gaps and resumes farm work only after the real `DayStarted` acknowledgment and completed menu flow. `DayEnding` and layout changes preserve that state; a genuine cancellation clears it.

Four private native cycles passed: `sleep → SaveGameMenu → SaveGame.Save → actual DayStarted → cycle completion → new farm work`. Saving completed without an exception. During the owned overnight wait, no route, farm action, or tool start occurred, the assistant was not unexpectedly disabled, and no required-route blockage was recorded. Plant, Clear, Water, or Harvest work resumed after the native day-start acknowledgment.

Native experience gains produced pending upgrade entries `(2,1)` and `(2,2)` on Spring 1 and Spring 3, followed by successful saving and recovery. The tests do not directly log or visually confirm a `LevelUpMenu` page. All captured overnight-wait samples were at 06:00 with `SaveGameMenu`; the exact older 24:00/no-menu gap was not dynamically reproduced. Its reviewed code protection is the real `DayStarted` acknowledgment plus continued ownership when the menu is briefly null. These boundaries distinguish the four runtime passes from the additional source coverage.

### Low energy and automatic sleep

In 1.0.1, Sleep When Finished and Sleep on Low Energy are enabled by default. The assistant first searches for safe reachable farm work; when essential work is finished or energy reaches the reserve, it enters the sleep flow instead of waiting without useful work until 23:00.

Disabling Sleep When Finished, Sleep on Low Energy, or Auto Sleep makes the corresponding boundary pause safely for player control. The assistant does not idle indefinitely or continue spending energy until the player passes out.

Before a hard bedtime, the assistant still checks eligible shipping, storage, and the case where mature crops remain but a full backpack has no safe slot. If that inventory condition cannot be resolved, it pauses for backpack space instead of bypassing the check and sleeping.

A backpack pause is based on a real current blockage: remaining mature crops cannot be collected, or the current seed purchase needs an unavailable slot while the backpack is actually full. A full backpack with no mature crop or current purchase blockage is not automatically treated as unfinished harvesting. If there is not yet enough wood for a chest, the assistant may finish feasible work and use the configured sleep policy, then seek the remaining materials the next day. When mature crops still have a usable slot, the early-sleep path rechecks their reachable work. Purchase blockage is recalculated each decision and cleared when work is cancelled, preventing stale purchase state from pausing a later task. Native bookkeeping and the separate two-round natural economic run passed within their documented scope.

## Harvest bookkeeping and shipping from storage

The `Harvested` ledger now covers the backpack and assistant chests whose recorded owner exactly matches the current player. Moving a tracked crop into storage keeps its harvest balance; only the quantity actually shipped is subtracted. The per-crop reserve is one combined amount across these inventories and all qualities, not a separate reserve for every chest or quality. Development keeps five per crop by default, and known unsubmitted quest targets remain protected.

To ship eligible stored surplus, the assistant follows the native path to a four-neighbor interaction tile beside the reachable chest, then adds the actual crop quantity to the real shipping bin. This route can work with a full backpack. Unreachable same-owner assistant chests still participate in bookkeeping and reserve totals but are not shipped from remotely; unknown and other-player chests remain protected.

The mod does not infer missing harvest history from old stored crops. If an older version already erased their ledger, upgrading does not automatically reconstruct it or classify that untracked stock as assistant-grown. Those crops need player review and manual shipping. Tree seeds `309 / 310 / 311` and Moss are storage-only forestry resources and are not automatically sold.

The dedicated private native bookkeeping fixture and a separate natural run covering two harvest/reinvestment rounds passed as documented below. The natural run preserved stored-crop ownership and harvest history through actual storage shipping and repeated reinvestment. Earlier failed accounting behavior is recorded in the changelog. These results do not establish all quest combinations or a globally optimal whole-game strategy.

## Trees, debris, and protected objects

Routine clearing remains inside the managed region. Ordinary-tree clearing only considers internal tree types `1`, `2`, and `3`. It skips tapped trees, fertilized trees, trees carrying mod data, fruit trees, machines, chests, buildings, large rocks, large stumps, and other protected objects.

The daily ordinary-tree limit can be set to `1`, `2`, `4`, `8`, or `12`. Development now defaults to the existing maximum of 12, Showcase to 4, and Rush disables ordinary-tree clearing. This is a ceiling, not a promise to cut that many: the assistant still budgets completion of the whole tree and stump plus the configured energy reserve, which defaults to 25. Tree clearing uses real native axe actions, including repeated hits, falling, and stump removal. A tree counts once only after both the tree and stump are gone. Grass clearing statistics count fully cleared tiles, rather than individual hits on a multi-layer grass tile.

## Assistant storage and scarecrows

When auto-storage is enabled, the mod first looks for its own marked chests and skips those it cannot reach. A new assistant chest requires the vanilla chest recipe, at least 50 wood combined across the backpack and reachable assistant chests owned by the same player, and a safe reachable placement tile near the farmhouse.

The storage resource allowlist includes wood `388`, stone `390`, fiber `771`, coal `382`, clay `330`, sap `92`, mixed seeds `770`, tree seeds `309 / 310 / 311`, and Moss. Hardwood is not included. Tree seeds and Moss are stored without automatic sale. Crafting materials may come from the backpack or reachable assistant chests whose recorded owner exactly matches the current player.

Runtime storage tests consumed 50 wood from 98, left 48, and stored five stacks through native chest storage. A full 36-slot first chest then caused a second chest to be crafted, consuming 50 wood from 128 and leaving 78; the assistant continued by buying and planting 51 seeds. These were targeted capacity/fault-injection scenarios and are not evidence of natural income generation; the separate `run06` loop provides that evidence.

In a third targeted test, every player-owned assistant chest was full and the backpack held zero wood. The assistant consumed chest-sourced wood from 999 to 949, left backpack wood at zero, and placed a third native chest.

The Performance & Clearing page also has an Auto Scarecrow option. The assistant crafts only after the vanilla recipe is learned, the backpack plus reachable player-owned assistant chests contain the real materials, and a safe coverage tile exists. Missing materials do not block other farm work. A 51-crop runtime scene consumed 50 wood, 1 coal, and 20 fiber and placed a native scarecrow covering all 51 crops.

## 1.0.1 controlled performance results

A private native QA run watered the same 24 parsnip tiles in the same 6x4 layout, using native tools and paths with starting energy 270 and watering-can charge 40:

| Work target | Time for 24 waterings | Relative to target 1 | Frame P95 | Assistant P95 |
|---:|---:|---:|---:|---:|
| 1 | 55.175 s | 1.00x | 24.4 ms | 0.0098 ms |
| 50 | 7.506 s | 7.35x | 26.0 ms | 0.6863 ms |
| 200 | 5.917 s | 9.32x | 25.7 ms | 0.6945 ms |

All three runs completed 24 waterings and ended at energy 222. This is evidence for 1.0.1 movement and native-tool performance under a controlled fixture. It is not evidence of natural farm income, whole-engine speed, or stable 200x throughput. Nine Governor mechanism tests also passed.

## 1.0.1 controlled native regression results

The latest private QA scenarios exercised actual game movement, tool actions, item acquisition, and menus:

- With the player at `(30,24)`, the first clearing action handled adjacent grass at `(29,24)` with zero walking steps, before farther clearing candidates. This directly checks the nearby-selection correction; it does not prove every map layout.
- After an assistant-owned native tool action, the game received a Prehistoric Rib, item `(O)583`, through its original acquisition flow. The native item presentation and text confirmation completed, then clearing continued.
- Pausing was tested both before the native tool-begin event was polled and during an active `UsingTool=true` animation. In both cases the original watering action finished once: water changed `40→39`, soil became watered (`dirt.state=1`), energy decreased by 2, `CanMove` returned to true, and `UsingTool` returned to false. Recovery used the paired native tool lifecycle without forcing those state flags.
- An unrelated plain-text notice remained open. Game time and the action count stayed unchanged while it blocked work; the assistant did not acknowledge it as its own discovery notice.
- A follow-up clearing scenario used four-layer grass. The first native hit reduced it from 4 layers to 1 without adding the unfinished tile to saved expansion progress. After the native Prehistoric Rib notice was acknowledged, the assistant continued on the same tile until the remaining layer disappeared; only then did it record expansion completion.
- At the end of that scenario, all 64 saved core tiles belonged to one four-neighbor component, and zero unfinished obstacles had been recorded as completed. Two trees and their stumps disappeared through actual native actions, and each tree was counted exactly once.

These are controlled regression results with their own scope. The separate bookkeeping fixture and natural two-round run below also passed; natural income is supported by that natural run, not inferred from these fixtures.

## 1.0.1 controlled native bookkeeping results

A private economic fixture exercised actual storage transfers, movement, and shipping:

- Moving `7+4=11` crop items from the backpack into the assistant chest left the normal/silver/gold harvest ledger unchanged at `20/4/2`.
- Four tracked crop items were shipped from the backpack through the native flow. After untracked items filled the backpack, the player followed an eight-step native route from `(35,24)` to the chest interaction tile `(29,23)`. Shipping from the chest then added 16 normal and 1 silver crop, bringing the actual shipping-bin total to 21.
- The assistant retained 3 silver and 2 gold tracked crops, a combined reserve of five. Four additional normal-quality items were untracked and remained unsold. An untagged chest's 3 cauliflowers, another owner's chest's 1 artifact, and the untracked backpack samples were also preserved.
- With all four interaction sides of the owned chest blocked, 10 normal-quality crops remained in the chest, their ledger remained 10, and the shipping bin remained empty. No remote sale occurred.

These results establish the tested storage-ledger, quality-retention, full-backpack shipping, and ownership/reachability boundaries. They do not establish a natural two-round farming economy or every quest-reserve combination.

## 1.0.1 natural new-save farming results

The native demonstration began at the title screen, created an independent save through Chinese character creation, and completed two harvest, shipping, settlement, and reinvestment rounds. No QA resources were applied; a test-resource fixture request was explicitly rejected by the native demonstration.

| Stage | Native result |
|---|---|
| Spring 1 | Bought 20 seeds at 20g each, spent 400g, retained 100g, and planted 35 crops including the starting seeds |
| Spring 3 | Crafted an assistant chest by consuming 50 actual wood |
| First harvest, Spring 5 | Harvested 33, shipped 28, and kept five |
| First reinvestment, Spring 6 | Settled at 1,080g, bought 49 seeds for 980g, retained 100g, and planted 49 |
| First scarecrow | Consumed 50 wood, 1 coal, and 20 fiber; covered all 49 crops |
| Second harvest, Spring 10 | Harvested 49 and shipped 49; five storage-origin shipping actions transferred five real crop items after native movement to assistant storage |
| Second reinvestment, Spring 11 | Settled at 1,839g, bought 86 seeds for 1,720g, retained 119g, and planted 86 |
| Expanded protection | A second scarecrow raised covered crops from 75 to all 86 |
| Original save boundary, Spring 12 | Cumulative totals: 170 planted, 300 native waterings, 82 harvested, 77 shipped, and 11 native sleep/save cycles |
| Manual pet event and farm recovery | Native pet handling was completed manually, then the assistant watered another 86 crops, increasing native waterings to 386 |
| Subsequent save boundary, Spring 13 | Cumulative totals: 170 planted, 386 native waterings, 82 harvested, 77 shipped, and 12 native sleep/save cycles |

Stored reserves remained tracked and saleable, so the earlier second-round storage-ledger failure did not recur. With Development's 12-tree ceiling, Spring 5 completed seven whole trees before resting at energy 27.7, above the configured 25 reserve; it did not stop merely at the former four-tree ceiling.

The adaptive work target reached 200. Recent normal native-frame P95 samples were about 16.8–17.1 ms, with assistant P95 about 0.35–0.51 ms. An earlier 23.5 ms frame window did not falsely reduce the target because of base-game timing. These are samples from this computer and run, not a whole-engine 200x claim; the controlled speed comparison above retains its original scope.

At Spring 12, Marnie's pet event paused automation. It was completed manually through the native dialogue pages, Yes response, and naming screen. After the native cat named “达德利” appeared, the assistant automatically resumed farm work and watered all 86 crops, bringing cumulative native waterings from 300 to 386; the following native sleep/save reached Spring 13 with 12 sleeps. This proves farm-work recovery after manual story handling; automatic story and choice progression remain future scope. A helper event action attempted outside an event was rejected by its guard without changing an event.

## Historical 1.0.0 candidate evidence

The following was observed for the 1.0.0 candidate in isolated local saves. It supports the existing farming loop but does not validate the new 1.0.1 scheduler, connected-frontier preparation, or integer speed controller:

- Native actions completed 35 plantings, 35 waterings, 12 grass cuts, and 2 trees. Mature trees received repeated hits, fell, and had their stumps removed through native actions.
- Water, Hoe, and movement tasks reached the effective `200x` tier with observed game-frame P95 around `17–18 ms`. This is a scheduler/performance tier, not constant whole-game 200x speed.
- The region overlay remained off; normalization forces `ShowOverlay=false`, and `F10` only turns it off.
- An empty watering can was refilled and work continued.
- Missing-watering-can behavior passed both rainy-day adaptation and sunny-day pause at 06:00. Eight seconds of `CanMove=false`, no safe region, and an unexpected town map also paused safely with the menu clock held at 06:00; recovery continued afterward.
- Dead crops were prioritized through a real Scythe action in about 316 ms without consuming energy. At low energy, zero-energy harvesting and dead-crop scything complete before sleep, while watering respects the energy reserve.
- The `NoPath` safe-pause guard passed source review, but was not claimed as an in-game fault-injection result. Three save-config normalization groups passed.
- Storage passed the 98→48 wood/five-stack path and the full 36-slot chest plus 128→78 second-chest path, followed by 51 seed purchases and plantings.
- Auto Scarecrow consumed 50 wood, 1 coal, and 20 fiber and placed a native scarecrow covering 51 crops.
- The earlier `run06` farming loop reached 97 planted, 176 watered, 33 harvested, 33 shipped, and 6 sleeps. Revenue was reinvested, and a native save reload succeeded.
- The 1.0.0 mod ZIP was extracted directly into a newly created `StardewFarmAssistant` folder in the actual game `Mods` directory. Its manifest had the correct UniqueID and version 1.0.0. The installed DLL was byte-for-byte hash-identical to that version's final release/bundle DLL, while existing mod folders including ConsoleCommands and SaveBackup remained in place.
- A native Spring 9 reload started paused. `storage_snapshot` confirmed two assistant chests with contents preserved, and `ScarecrowCount=1`.
- One 24-mature-potato fixture on Spring 10 produced five `harvest_extra_collected` events with a total `Stack=5`, all for `(O)192`. Every event was confirmed by `Debris.collect:true` and ended with `pending=0`. These are five collection events from one fixture, not five independent fixtures, and are not a claim of natural global profit outside that fixture.
- Under the 1.0.0 candidate behavior at that time, Development harvested zero-energy mature crops at the reserve of 25 and then waited until 23:00; Rush slept earlier at low energy. This is historical behavior and is not the 1.0.1 default.
- After a native Spring 11 reload of the 1.0.0 candidate, `AutoSleep=false` produced `Paused: manual bedtime reached` at in-game time 23:00. With AssistantMenu open, multiple telemetry samples stayed at the same in-game time. The actual 1280x720 Settings screenshot showed the reason and every button readable without clipping.
- In the same isolated fixture, 24 mature potatoes, zero free backpack slots, energy 25, and `AutoStorage=false` produced `Paused: backpack needs space` after closing the menu at 06:00. Multiple samples remained on Spring 11 at `time=600`.
- After adding the pre-bed shipping/storage/full-backpack mature-crop check, enabling `AutoSleep=true` and starting at in-game time 23:00 still prioritized the backpack pause. Samples remained on Spring 11 at the same in-game time, with cumulative `sleeps=0`.
- The 1.0.0 formal native `--demo` launcher started an independent new-save demonstration. It passed the title screen and Chinese character creation, entered Spring 1 with working audio, and reached Day 1 at in-game time 09:40 with 35 planted, 35 watered, and 0 sleeps. Effective adaptive speed was `200x`; game-frame P95 was `17.1037 ms`, assistant P95 was `0.0052 ms`, `qa_injected=0`, and money was 100. A real-tool rock-clearing screenshot was reviewed and showed no overlay.

## Release scope and validation boundaries

Version 1.0.1 includes the controlled watering, clearing, native bookkeeping, four overnight save/recovery cycles, natural two-round economy, and post-manual-event farming recovery documented above. Install the release folder through the SMAPI instructions at the start of this README. The local demonstration used independent saves; a player's personal save was not loaded through the normal launcher. No public upload has occurred.

Each controlled or natural result applies to its tested scene, map, settings, and recorded boundary. Historical-core migration, every quest-reserve combination, every disabled-sleep combination, other computers or operating systems, and arbitrary third-party mod combinations are not exhaustively validated. NPC story events and choice menus remain a manual pause boundary; assistant-owned vanilla item-discovery notices can be acknowledged through the native flow. Fishing, mining, full quest progression, Community Center completion, and story automation remain future scope.

## Troubleshooting and reports

The assistant pauses when a required tool is missing, no reachable water source or work tile remains, a full backpack blocks current harvesting or seed purchasing and cannot free a safe slot, the managed region is unreachable, or route recovery cannot make progress. Correct the stated cause, close the settings menu, and press `F8` to resume.

When reporting a reproducible issue, include the game, SMAPI, and mod versions; season, date, time, and farm map; selected mode, adaptive setting, speed ceiling, and managed region; exact reproduction steps; relevant SMAPI errors and the log from that run; and other mods that change crops, shops, quests, maps, time, or pathfinding.

Remove personal paths, account names, or other private information before posting logs publicly.

## Uninstall

Pause the assistant, save normally, exit the game and SMAPI, then remove the `StardewFarmAssistant` folder from `Mods`. Chests and scarecrows placed by the assistant are ordinary vanilla `Chest` and `Scarecrow` objects, so they remain in the save as normal game objects after uninstalling the mod. Leftover configuration data cannot run after the mod is removed.

## Build from source

Install the .NET 6 SDK, then provide your own game folder at build time:

```powershell
dotnet build -c Release -p:GamePath="<game folder>"
```

Source and release packages should not contain personal save files, SMAPI logs, fixed personal paths, or redistributed game DLLs.

## License

The original mod source is licensed under the MIT License. Stardew Valley and SMAPI are separate dependencies governed by their own terms and are not redistributed with this project.
