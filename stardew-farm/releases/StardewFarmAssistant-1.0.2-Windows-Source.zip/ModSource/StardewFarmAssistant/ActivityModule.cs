namespace StardewFarmAssistant;

/// <summary>Extensions must use the shared host, pause, resource and verification rules.</summary>
public interface IActivityModule
{
    string Id { get; }
    bool IsAvailable { get; }
    string UnavailableReason { get; }
    void OnDayStarted();
    bool TryStep();
    void Cancel();
}

public sealed class PlannedExtension : IActivityModule
{
    public string Id { get; }
    public bool IsAvailable => false;
    public string UnavailableReason => "Planned extension; no autonomous actions implemented.";
    public PlannedExtension(string id) => Id = id;
    public void OnDayStarted() { }
    public bool TryStep() => false;
    public void Cancel() { }
}
