using StardewValley;

namespace StardewFarmAssistant;

public static class StatusText
{
    public static string ModeName(string mode) => mode switch
    { "development" => "开荒经营", "rush" => "种田速进", "showcase" => "观赏开荒", _ => "自定义" };

    public static string HudSpeed(ModConfig config, FarmStatus status)
    {
        bool zh = LocalizedContentManager.CurrentLanguageCode == LocalizedContentManager.LanguageCode.zh;
        return config.AdaptiveSpeed
            ? (zh ? $"自适应档 {status.EffectiveSpeed}/{config.SpeedCeiling}" : $"Adaptive target {status.EffectiveSpeed}/{config.SpeedCeiling}")
            : (zh ? $"手动档 {status.EffectiveSpeed}" : $"Manual target {status.EffectiveSpeed}");
    }

    public static string HudTaskReason(FarmStatus status)
    {
        string activity = Translate(status.Activity);
        if (status.Reason == "Current farming work is cared for; clearing the nearby connected frontier.")
            return activity + " · " + (LocalizedContentManager.CurrentLanguageCode == LocalizedContentManager.LanguageCode.zh
                ? "农活已照料，沿农田边界就近开荒" : "Crops cared for; expanding the nearby frontier");
        if (status.Activity.StartsWith("Paused:", StringComparison.Ordinal) && !string.IsNullOrWhiteSpace(status.Reason))
            return activity + " · " + CompactTaskReason(status.Reason);
        string reason = CompactSpeedReason(status.SpeedReason);
        return string.IsNullOrWhiteSpace(reason) ? activity : activity + " · " + reason;
    }

    public static string CompactTaskReason(string text)
    {
        bool zh = LocalizedContentManager.CurrentLanguageCode == LocalizedContentManager.LanguageCode.zh;
        return text switch
        {
            "Watering can missing; put it in the backpack and press F8." => zh ? "缺少水壶，请放入背包后按F8" : "Put the watering can in the backpack, then press F8",
            "Hoe missing; put it in the backpack and press F8." => zh ? "缺少锄头，请放入背包后按F8" : "Put the hoe in the backpack, then press F8",
            "Dead crops need a scythe or axe. Put one in the backpack, then press F8." => zh ? "清枯作物需镰刀或斧头，放入背包后按F8" : "Put a scythe or axe in the backpack, then press F8",
            "The route to the farm, home, bed or harvest pickup is blocked. Clear the route or move the character, then press F8." => zh ? "路线被挡住，请清理或移动角色后按F8" : "Clear the route or move the character, then press F8",
            "Return to your farm or farmhouse, then press F8 to resume farming." => zh ? "请回到农场或农舍后按F8" : "Return to the farm or farmhouse, then press F8",
            "Energy is at the reserve and automatic sleep is off. Eat or rest, then press F8." => zh ? "体力到保留值，请进食或手动休息后按F8" : "Energy at reserve; eat or rest, then press F8",
            "Bedtime is reached and automatic sleep is off. Sleep manually or change bedtime, then press F8." => zh ? "请手动睡觉或更改休息时间后按F8" : "Sleep or change bedtime, then press F8",
            "Watering cannot continue in this region. Change the region or refill the watering can, then press F8." => zh ? "无法继续浇水，请更改区域或补满水壶后按F8" : "Change region or refill the watering can, then press F8",
            "Mature crops remain, but shipping and storage cannot free a safe slot. Free a backpack slot, then press F8." => zh ? "成熟作物待收，请腾出背包空位后按F8" : "Free a backpack slot for mature crops, then press F8",
            "Harvested crop drops are waiting for pickup. Free a backpack slot, then press F8 before sleeping." => zh ? "收获掉落待拾取，请先腾出背包空位再按F8" : "Free a backpack slot for harvested drops, then press F8",
            "Harvested crop drops could not be picked up. Move closer or free a backpack slot, then press F8." => zh ? "无法拾取作物，请靠近或腾出背包空位后按F8" : "Move closer or free a slot, then press F8",
            "No reachable work tile remains. Move the character or change the managed region, then press F8." => zh ? "没有可达工作格，请移动角色或更改区域后按F8" : "Move the character or change region, then press F8",
            "The selected region has no safe farmable tiles. Change the region, then press F8." => zh ? "所选区域没有安全耕地，请更改区域后按F8" : "Change the region, then press F8",
            "Automatic recovery could not make progress. Clock stopped in settings; move the character or change the managed region, then press F8." => zh ? "自动恢复失败，请移动角色或更改区域后按F8" : "Move the character or change region, then press F8",
            _ => Translate(text),
        };
    }

    public static string CompactSpeedReason(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        bool zh = LocalizedContentManager.CurrentLanguageCode == LocalizedContentManager.LanguageCode.zh;
        if (!zh) return text switch
        {
            var value when value.StartsWith("Stable window 1/2") => "Stable sample 1/2",
            var value when value.StartsWith("Holding target") => "Holding within budget",
            var value when value.StartsWith("Two stable gameplay windows") => "Stable; raised target",
            var value when value.StartsWith("Low assistant cost") => "Low assistant load; probing or holding ceiling",
            var value when value.Contains("lowered target") => "Load high; lowered target",
            _ => text,
        };
        return text switch
        {
            "Awaiting valid gameplay samples" => "等待性能采样",
            "Adaptive target retained within configured ceiling" => "保持上限内档位",
            "Adaptive control started at the conservative 25x target" => "从25档保守起步",
            "Adaptive control disabled; using the manual target" => "使用手动档位",
            var value when value.StartsWith("Manual target") => "手动目标，持续测量性能",
            var value when value.StartsWith("Stable window 1/2") => "稳定采样1/2",
            var value when value.StartsWith("Holding target") => "负载处于保持区间",
            var value when value.StartsWith("Stable at the configured") => "已达配置上限",
            var value when value.StartsWith("Two stable gameplay windows") => "连续稳定，自动升档",
            var value when value.StartsWith("Three consecutive gameplay frames") => "连续慢帧，自动降档",
            var value when value.StartsWith("Measured load exceeded budget") => "P95超预算，自动降档",
            var value when value.StartsWith("Assistant p95") => "助手负载高，自动降档",
            var value when value.StartsWith("Frame p95") => "帧与助手负载高，降档",
            var value when value.StartsWith("Low assistant cost") => value.Contains("raised target") ? "助手负载低，继续升档" : value.Contains("ceiling") ? "助手负载低，已达上限" : "助手负载低，稳定采样",
            _ => TranslateSpeedReason(text),
        };
    }

    public static string TranslateSpeedReason(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return LocalizedContentManager.CurrentLanguageCode == LocalizedContentManager.LanguageCode.zh ? "等待有效游戏采样" : "Awaiting valid gameplay samples";
        if (LocalizedContentManager.CurrentLanguageCode != LocalizedContentManager.LanguageCode.zh) return text;
        string translated = text
            .Replace("Awaiting valid gameplay samples", "等待有效游戏采样")
            .Replace("Adaptive target retained within configured ceiling", "自适应档位保持在配置上限内")
            .Replace("Adaptive control started at the conservative 25x target", "自适应控制从保守的25档开始")
            .Replace("Adaptive control disabled; using the manual target", "自适应控制已关闭，使用手动目标")
            .Replace("Manual target", "手动目标")
            .Replace("Three consecutive gameplay frames exceeded 45 ms", "连续三个游戏帧超过45毫秒")
            .Replace("Measured load exceeded budget", "测得负载超过预算")
            .Replace("Stable window 1/2", "稳定窗口1/2")
            .Replace("Holding target in the hysteresis band", "档位保持在滞回区间")
            .Replace("Stable at the configured", "已稳定达到配置的")
            .Replace("target ceiling", "目标上限")
            .Replace("Two stable gameplay windows; raised target to", "连续两个稳定游戏窗口，目标提升到")
            .Replace("frame p95", "帧P95")
            .Replace("assistant p95", "助手P95")
            .Replace("Assistant p95", "助手P95")
            .Replace("Frame p95", "帧P95")
            .Replace("exceeded its 8 ms controllable-load budget", "超过8毫秒助手负载预算")
            .Replace("exceeded 24 ms while", "超过24毫秒，同时")
            .Replace("was above 2 ms", "超过2毫秒")
            .Replace("Low assistant cost despite base", "助手负载低；基础")
            .Replace("Low assistant cost with base", "助手负载低；基础")
            .Replace("Holding target: base", "保持档位：基础")
            .Replace("while", "同时")
            .Replace("is low; speed changes are unlikely to affect this render load", "很低；该渲染负载难以通过调速降低")
            .Replace("probe window 1/2", "采样窗口1/2")
            .Replace("holding the configured", "保持配置的")
            .Replace("raised target to", "目标提升到")
            .Replace("for another measured probe", "继续实测")
            .Replace("lowered target to", "目标降低到")
            .Replace("already at minimum target", "已处于最低档位");
        return System.Text.RegularExpressions.Regex.Replace(translated, @"(?<=\d)x\b", "档");
    }

    public static string Translate(string text)
    {
        if (LocalizedContentManager.CurrentLanguageCode != LocalizedContentManager.LanguageCode.zh) return text;
        if (text.StartsWith("Walking to ")) return "前往" + Translate(text[11..]);
        if (text.StartsWith("Waiting for seed")) return "等待皮埃尔09:00开店购种";
        if (text.StartsWith("Objective=")) return "按当前季节、实际价格、可用金币和地块滚动规划；未来收益为预测。";
        if (text.StartsWith("Managed crops need a Scarecrow; missing ")) return "作物需要稻草人，缺少：" + text["Managed crops need a Scarecrow; missing ".Length..];
        if (text.StartsWith("Inventory needs space; ")) return text.Replace("Inventory needs space; ", "背包需要空位；还需").Replace(" more wood is required for a real Chest", "木材制作储物箱");
        return text switch
        {
            "Paused" => "已暂停",
            "F8 to start automatic farming" => "按F8开始自动种田",
            "Planning today's farm" => "规划今天的农活",
            "No affordable crop" => "当前无可购种子",
            "Receiving starter seeds" => "领取开局种子",
            "Receiving farm discovery" => "确认获得物品提示",
            "Harvest" or "harvest" => "收获成熟作物",
            "Water" or "water" => "用水壶浇水",
            "Hoe" or "hoe" => "用锄头开地",
            "Plant" or "plant" => "播种",
            "Clear" or "clear" => "清理石头、树枝和杂草",
            "Clear grass" or "clear grass" => "清除草丛",
            "Clear dead crop" or "clear dead crop" => "用农具清除枯作物",
            "Chop" or "chop" => "砍伐普通树",
            "Refill" or "refill" => "补充水壶用水",
            "farm" => "农田",
            "bed" => "床边",
            "Returning home" => "返回农舍",
            "Changing location" => "等待进出场景",
            "Paused for menu/event" => "等待菜单、剧情或转场结束",
            "Finishing character action" => "等待角色动作完成",
            "Waiting for harvest pickup" => "等待拾取本次收获的额外作物",
            "Walking to harvest pickup" => "返回收获位置拾取作物",
            "Waiting for tree to fall" => "等待普通树倒下",
            "Paused: tree animation stalled" => "已暂停：原生倒树动作未结束",
            "The original falling-tree animation has not finished. Resume after it finishes." => "原生倒树动作尚未结束，请在动作结束后恢复。",
            "Seed purchase needs a backpack slot, and nearby safe storage recovery is unavailable. Free a slot, then press F8." => "购买种子需要背包空位，附近暂时无法安全腾格。请腾出一个空位，再按F8。",
            "Walking to assistant storage" => "前往助手储物箱",
            "assistant storage" => "助手储物箱",
            "ship stored crops" => "助手储物箱出货",
            "Shipped own stored crops" => "已将箱内多余自产作物送入出货箱",
            "Waiting for current movement before storage" => "等待当前移动结束后整理储物箱",
            "Own crop surplus remains in unreachable assistant storage" => "自产余量仍在本人助手箱内，箱旁路线暂时不可达",
            "Assistant storage shipping route timed out" => "前往助手箱出货的路线超时，正在重新规划",
            "Assistant storage has no reachable adjacent tile for shipping" => "助手箱旁没有可达的出货站位",
            "Storage paused for location change" => "转场期间暂停整理背包",
            "Stored farming supplies" => "已存放农场材料，腾出背包空间",
            "Placed a Scarecrow" => "已制作并摆放稻草人",
            "Inventory needs space before seed delivery" => "背包需要空位才能购买新种子",
            "Inventory needs space to harvest this crop quality" => "背包需要空位才能收获这一品质的作物",
            "Farm work complete" => "关键农活完成，准备休息",
            "Field ready; waiting until bedtime" => "田块已准备好，加速等待23:00休息",
            "Energy reserve; waiting until bedtime" => "体力到保留值，加速等待设定时间休息",
            "Energy is at the reserve; zero-energy harvest is complete. Waiting until the configured bedtime." => "体力到保留值，零体力收获已处理；加速等待设定的睡觉时间。",
            "Paused: energy reserve reached" => "已暂停：体力到保留值",
            "Paused: manual bedtime reached" => "已暂停：已到手动休息时间",
            "Bedtime is reached and automatic sleep is off. Sleep manually or change bedtime, then press F8." => "已到休息时间，自动睡觉关闭。请手动睡觉或更改休息时间，再按F8。",
            "Energy is at the reserve and automatic sleep is off. Eat or rest, then press F8." => "体力到保留值，自动睡觉已关闭。请吃东西或休息，再按F8。",
            "Energy is at the reserve. Eat or rest, then press F8." => "体力到保留值，低体力睡觉已关闭。请吃东西或休息，再按F8。",
            "Sleeping" => "正在睡觉",
            "Energy reserve reached" => "休息原因：体力已达到保留值",
            "Bedtime reached" => "休息原因：已到设置的睡觉时间",
            "Key farm work finished in fast mode" => "休息原因：速进模式的关键农活已完成",
            "Nearby reachable farm work complete" => "休息原因：附近可达的农活已完成",
            "Shipping and saving" => "出货结算并保存",
            "Applying overnight farming level" => "确认夜间技能升级",
            "Pierre is closed today" => "今天皮埃尔休息，无法购种",
            "Current crops are cared for and the reachable management area is prepared. No affordable seeds remain." => "现有作物已照料，管理区已准备好；目前没有可购买的种子。",
            "Nearby reachable farming and expansion are complete. Change the region or sleep manually." => "附近可达的种田和开荒已完成。可调整管理范围或手动睡觉。",
            "A mature crop is still waiting on an unreachable work tile." => "成熟作物仍未收取，正在重试被阻挡的路线。",
            "A living crop still needs water on an unreachable work tile." => "仍有作物缺水，正在重试被阻挡的路线。",
            "A dead crop is still waiting on an unreachable work tile." => "仍有枯死作物，正在重试被阻挡的路线。",
            "A prepared plot still needs seed on an unreachable work tile." => "已耕地仍待补种，正在重试被阻挡的路线。",
            "No reachable water source" => "暂时没有可到达的补水点",
            "Not enough spare energy to finish this tree and stump" => "剩余体力不足以安全处理整棵树和树桩",
            "Inventory full or crop changed" => "背包已满或作物状态发生变化",
            "Replanning interrupted route" => "路线中断，正在重新规划",
            "Paused: route or character action stalled" => "已暂停：路线或角色动作停滞",
            "Paused: required farming tool missing" => "已暂停：缺少必需的农具",
            "Paused: required route blocked" => "已暂停：必需路线被挡住",
            "Paused: native tool action failed" => "已暂停：必需工具动作未完成",
            "A required tool action could not finish. Check the tool and target tile, then press F8 to retry." => "必需工具动作未能完成。请检查工具和目标格，再按F8重试。",
            "The route to the farm, home, bed or harvest pickup is blocked. Clear the route or move the character, then press F8." => "农场、家、床或收获物的路线被挡住。请清理路线或移动角色，再按F8。",
            "Paused: outside farm" => "已暂停：角色在农场之外",
            "Return to your farm or farmhouse, then press F8 to resume farming." => "请回到农场或农舍，再按F8恢复种田。",
            "Dead crops need a scythe or axe. Put one in the backpack, then press F8." => "清枯作物需要镰刀或斧头。请放入背包，再按F8。",
            "Managed crops need crow protection; learn the Scarecrow recipe to automate it" => "作物需要防乌鸦；学会稻草人配方后可自动制作。",
            "Managed crops need a Scarecrow, but its real recipe materials are unavailable" => "作物需要稻草人，当前缺少制作材料。",
            "Managed crops need a Scarecrow, but no safe reachable placement tile is available nearby" => "作物需要稻草人，但附近没有安全、可达的摆放位置。",
            "Inventory is full, but no safe owned items can be stored" => "背包已满，当前没有可安全存放的助手物品。",
            "Assistant storage has no reachable adjacent tile" => "储物箱周围没有可达的站位。",
            "Watering can missing; put it in the backpack and press F8." => "缺少水壶；请把水壶放入背包，然后按F8重新启动。",
            "Hoe missing; put it in the backpack and press F8." => "缺少锄头；请把锄头放入背包，然后按F8重新启动。",
            "Paused: no reachable water source" => "已暂停：没有可到达的水源",
            "Watering cannot continue in this region. Change the region or refill the watering can, then press F8." => "当前区域无法继续浇水。请更改管理区域或补满水壶，然后按F8重新启动。",
            "Paused: backpack needs space" => "已暂停：背包需要空位",
            "Paused: harvest pickup stalled" => "已暂停：收获掉落未能拾取",
            "Mature crops remain, but shipping and storage cannot free a safe slot. Free a backpack slot, then press F8." => "仍有成熟作物待收，但出货和存储无法安全腾出空位。请腾出一个背包空位，然后按F8重新启动。",
            "Paused: managed region is unreachable" => "已暂停：管理区域无法到达",
            "No reachable work tile remains. Move the character or change the managed region, then press F8." => "没有剩余的可达工作格。请移动角色或更改管理区域，然后按F8重新启动。",
            "Paused: no safe farmable tiles" => "已暂停：没有安全可耕地块",
            "The selected region has no safe farmable tiles. Change the region, then press F8." => "所选区域没有安全可耕地块。请更改管理区域，然后按F8重新启动。",
            "No progress for 8 seconds; selected another reachable task" => "8秒没有进展，已选择其他可到达的任务",
            "Automatic recovery could not make progress. Clock stopped in settings; move the character or change the managed region, then press F8." => "自动恢复仍无法推进。设置中的时钟已停止；请移动角色或更改管理区域，然后按F8重新启动。",
            _ => text
        };
    }
}
