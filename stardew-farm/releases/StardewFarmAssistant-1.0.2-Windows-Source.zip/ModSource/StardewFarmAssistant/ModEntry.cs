using System.Diagnostics;
using System.Text.Json;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;

namespace StardewFarmAssistant;

public sealed class ModEntry : Mod
{
    public ModConfig Config { get; private set; } = new();
    public SaveSettings Save { get; private set; } = new();
    public FarmStatus Status { get; private set; } = new();
    public FarmEngine Engine { get; private set; } = null!;
    public List<IActivityModule> Modules { get; } = new();
    private double elapsed;
    private string? screenshot;
    private TestHarness? test;
    private bool? originalPauseWhenUnfocused;
    private readonly HashSet<string> toolExamples = new();
    private AdaptiveSpeedController speedController = null!;
    private long previousRendered;
    private double assistantFrameMs;
    private string lastPlanningSignature = "";
    private double throughputWindowMs;
    private long throughputStartingActions;
    public int EffectiveWorkSpeed => speedController?.EffectiveSpeed ?? Config.WorkSpeed;
    public override void Entry(IModHelper helper)
    {
        Config = helper.ReadConfig<ModConfig>(); Config.Normalize();
        lastPlanningSignature = PlanningSignature();
        speedController = new AdaptiveSpeedController((speed, reason) => LogEvidence("adaptive_speed", new { speed, reason }));
        speedController.Configure(Config.AdaptiveSpeed, Config.WorkSpeed, Config.SpeedCeiling);
        Engine = new FarmEngine(this);
        Modules.Add(Engine);
        foreach (string id in new[] { "fishing", "foraging", "mining", "crafting", "community-center", "quests", "story" }) Modules.Add(new PlannedExtension(id));
        helper.Events.GameLoop.SaveLoaded += (_, _) => LoadSave();
        helper.Events.GameLoop.DayStarted += (_, _) => { Engine.OnDayStarted(); Persist(); test?.DayStarted(); };
        helper.Events.GameLoop.Saving += (_, _) => Persist();
        helper.Events.GameLoop.DayEnding += (_, _) => Engine.Cancel(abandonHarvest: true, preserveNight: true);
        helper.Events.GameLoop.ReturnedToTitle += (_, _) => { Engine.Cancel(abandonHarvest: true); RestoreFocusPause(); Save = new(); Status.Enabled = false; };
        helper.Events.GameLoop.UpdateTicking += (_, _) => { if (Context.IsWorldReady && Save.Enabled) Engine.PrepareMovement(); };
        helper.Events.GameLoop.UpdateTicked += Update;
        helper.Events.Input.ButtonPressed += Input;
        helper.Events.Display.RenderedWorld += World;
        helper.Events.Display.RenderedHud += Hud;
        helper.Events.Display.Rendered += Rendered;
        helper.ConsoleCommands.Add("farmbot", "farmbot on|off|menu|status|speed <1..200>|mode <development/rush/showcase>|screenshot <path>", Command);
        if (Environment.GetEnvironmentVariable("STARDEW_AUTOFARM_TEST") == "1")
        { test = new TestHarness(this); helper.Events.GameLoop.GameLaunched += (_, _) => test.GameLaunched(); }
        Monitor.Log("F8 start/pause | F9 settings | F6 work speed | F7 custom region | F10 hide farm overlay", LogLevel.Info);
    }
    private void LoadSave()
    {
        Engine.Cancel(abandonHarvest: true);
        Save = Helper.Data.ReadSaveData<SaveSettings>("farm-settings") ?? new SaveSettings();
        Save.Normalize();
        // Every user load starts paused; no stored enabled flag can seize an old save.
        Save.Enabled = false; Status.Enabled = false; Status.Activity = "F8 to start automatic farming";
        Engine.InvalidateLayout();
        Persist();
    }
    public void Persist()
    {
        if (Context.IsWorldReady && Context.IsMainPlayer) Helper.Data.WriteSaveData("farm-settings", Save);
    }
    public void Toggle()
    {
        if (!Context.IsWorldReady) return;
        if (!Context.IsMainPlayer || Context.IsMultiplayer) { Game1.showRedMessage("Farm assistant supports single-player saves."); return; }
        Save.Enabled = !Save.Enabled; Status.Enabled = Save.Enabled;
        if (Save.Enabled)
        { originalPauseWhenUnfocused ??= Game1.options.pauseWhenOutOfFocus; Game1.options.pauseWhenOutOfFocus = false; }
        else RestoreFocusPause();
        Engine.Cancel(); Status.Activity = Save.Enabled ? "Planning today's farm" : "Paused";
        if (Save.Enabled) { Status.Reason = ""; Engine.InvalidateLayout(); }
        Persist();
        if (Save.Enabled && Game1.activeClickableMenu is AssistantMenu menu) menu.exitThisMenu();
    }
    private void RestoreFocusPause()
    {
        if (originalPauseWhenUnfocused.HasValue) Game1.options.pauseWhenOutOfFocus = originalPauseWhenUnfocused.Value;
        originalPauseWhenUnfocused = null;
    }
    private string PlanningSignature() => string.Join("|", JsonSerializer.SerializeToElement(Config).EnumerateObject()
        .Where(p => p.Name is not ("WorkSpeed" or "AdaptiveSpeed" or "SpeedCeiling" or "WorkMode")).Select(p => p.Name + ":" + p.Value.GetRawText()));
    public void SaveConfig()
    {
        Config.Normalize(); speedController.Configure(Config.AdaptiveSpeed, Config.WorkSpeed, Config.SpeedCeiling); Helper.WriteConfig(Config);
        string signature = PlanningSignature();
        if (signature != lastPlanningSignature) Engine.InvalidateLayout();
        lastPlanningSignature = signature;
    }
    private void AutoRegion() { Save.RegionX = Save.RegionY = -1; Engine.InvalidateLayout(); Persist(); }
    private void MarkRegion()
    {
        if (!Context.IsWorldReady || Game1.currentLocation is not StardewValley.Farm) return;
        Save.RegionX = Math.Max(1, Game1.player.TilePoint.X - 5); Save.RegionY = Math.Max(1, Game1.player.TilePoint.Y - 5);
        Save.RegionWidth = Save.RegionHeight = 12; Engine.InvalidateLayout(); Persist();
    }
    public void OpenMenu()
    {
        if (Game1.activeClickableMenu != null && Game1.activeClickableMenu is not AssistantMenu) return;
        Game1.activeClickableMenu = new AssistantMenu(Config, Status, SaveConfig, Toggle, AutoRegion, MarkRegion);
    }
    private void Input(object? sender, ButtonPressedEventArgs e)
    {
        if (!Context.IsWorldReady) return;
        if (e.Button == SButton.F8) { Toggle(); Helper.Input.Suppress(e.Button); }
        else if (e.Button == SButton.F9 && Game1.activeClickableMenu is AssistantMenu menu) { menu.exitThisMenu(); Helper.Input.Suppress(e.Button); }
        else if (e.Button == SButton.F9 && Game1.activeClickableMenu == null) { OpenMenu(); Helper.Input.Suppress(e.Button); }
        else if (e.Button == SButton.F6) { CycleSpeed(); Helper.Input.Suppress(e.Button); }
        else if (e.Button == SButton.F7) { MarkRegion(); Helper.Input.Suppress(e.Button); }
        else if (e.Button == SButton.F10) { Config.ShowOverlay = false; Helper.WriteConfig(Config); Helper.Input.Suppress(e.Button); }
        else if (Save.Enabled && e.Button is SButton.W or SButton.A or SButton.S or SButton.D or SButton.Up or SButton.Down or SButton.Left or SButton.Right) Toggle();
    }
    private void CycleSpeed()
    {
        Config.WorkSpeed = Config.WorkSpeed >= 200 ? 1 : Math.Min(200, Config.WorkSpeed + (Config.WorkSpeed < 10 ? 1 : 5)); Config.AdaptiveSpeed = false; Config.SpeedCeiling = Math.Max(Config.SpeedCeiling, Config.WorkSpeed); Config.WorkMode = "custom"; SaveConfig();
    }
    private void Update(object? sender, UpdateTickedEventArgs e)
    {
        test?.Tick();
        if (!Context.IsWorldReady || !Save.Enabled || !Engine.IsAvailable) return;
        var watch = Stopwatch.StartNew();
        try
        {
            if (Engine.TickOwnedNightMenu()) return;
            if (Engine.WatchForStall()) return;
            if (Engine.TickNativeTool()) return;
            Engine.AccelerateOnlyIdle(Game1.currentGameTime);
            elapsed += Game1.currentGameTime.ElapsedGameTime.TotalSeconds;
            if (elapsed < Math.Max(1.0 / 60, .8 / EffectiveWorkSpeed)) return;
            elapsed = 0;
            Engine.TryStep();
        }
        catch (Exception ex)
        {
            PauseSafely("Paused after error; see SMAPI log", ex.Message);
            Monitor.Log("Farm assistant stopped safely: " + ex, LogLevel.Error);
        }
        finally
        {
            double cost = watch.Elapsed.TotalMilliseconds;
            assistantFrameMs += cost; Status.WorstTickMs = Math.Max(Status.WorstTickMs, cost);
            if (e.IsMultipleOf(120)) Helper.Data.WriteJsonFile("data/runtime-state.json", new { Status, money = Game1.player.Money, day = Game1.dayOfMonth, stamina = Game1.player.Stamina, speed = EffectiveWorkSpeed });
        }
    }
    public void PauseSafely(string activity, string reason)
    {
        Save.Enabled = Status.Enabled = false; Engine.Cancel(); RestoreFocusPause();
        Status.Activity = activity; Status.Reason = reason; Persist();
        // A native menu stops the clock too, so an explained failure cannot
        // silently consume the rest of the day. Never replace a user's menu.
        if (Context.IsWorldReady && Game1.activeClickableMenu == null) OpenMenu();
    }
    private void Rendered(object? sender, RenderedEventArgs e)
    {
        long now = Stopwatch.GetTimestamp();
        double frameMs = previousRendered == 0 ? 0 : (now - previousRendered) * 1000.0 / Stopwatch.Frequency;
        previousRendered = now;
        bool eligible = Context.IsWorldReady && Save.Enabled && Engine.IsAvailable
            && Game1.activeClickableMenu == null && !Game1.eventUp && !Game1.fadeToBlack
            && !Game1.isWarping && Game1.locationRequest == null;
        if (eligible && frameMs > 0 && frameMs <= 250)
        {
            if (throughputWindowMs == 0) throughputStartingActions = Status.Actions;
            throughputWindowMs += frameMs;
            if (throughputWindowMs >= 3000)
            { Status.ActionsPerSecond = (Status.Actions - throughputStartingActions) * 1000.0 / throughputWindowMs; throughputWindowMs = 0; }
        }
        else throughputWindowMs = 0;
        speedController.Sample(frameMs, assistantFrameMs, eligible);
        assistantFrameMs = 0;
        Status.EffectiveSpeed = EffectiveWorkSpeed;
        Status.FrameP95Ms = speedController.FrameP95Ms; Status.AssistantP95Ms = speedController.AssistantP95Ms;
        Status.SpeedReason = speedController.Reason;
        Capture();
    }
    public void LogEvidence(string kind, object data)
    {
        if (test != null) test.Log(kind, data);
        if (kind.StartsWith("tool_", StringComparison.Ordinal) || kind == "work_route") return;
        Monitor.Log(kind + " " + JsonSerializer.Serialize(data), LogLevel.Trace);
    }
    private void Command(string name, string[] args)
    {
        if (args.Length == 0) { Monitor.Log("F8 start/pause | F9 settings | F6 speed; farmbot on/off/status", LogLevel.Info); return; }
        switch (args[0].ToLowerInvariant())
        {
            case "on": if (!Save.Enabled) Toggle(); break;
            case "off": if (Save.Enabled) Toggle(); break;
            case "menu": if (Context.IsWorldReady) OpenMenu(); break;
            case "status": Monitor.Log(JsonSerializer.Serialize(Status), LogLevel.Info); break;
            case "speed": if (args.Length > 1 && int.TryParse(args[1], out var speed)) { Config.WorkSpeed = speed; Config.AdaptiveSpeed = false; Config.SpeedCeiling = Math.Max(Config.SpeedCeiling, speed); Config.WorkMode = "custom"; SaveConfig(); } break;
            case "mode": if (args.Length > 1) { Config.SetMode(args[1]); SaveConfig(); } break;
            case "screenshot": if (args.Length > 1) screenshot = Path.GetFullPath(string.Join(" ", args.Skip(1))); break;
        }
    }
    public void RequestScreenshot(string path) => screenshot = path;
    public void CaptureToolExample(string kind)
    {
        if (test == null || !toolExamples.Add(kind)) return;
        string root = Environment.GetEnvironmentVariable("STARDEW_AUTOFARM_TEST_ROOT")!;
        RequestScreenshot(Path.Combine(root, "evidence", "tool-" + kind.Replace(' ', '-') + ".png"));
    }
    private void Capture()
    {
        if (screenshot == null) return;
        string path = screenshot; screenshot = null;
        try
        {
            var device = Game1.graphics.GraphicsDevice;
            var targets = device.GetRenderTargets();
            Texture2D? rendered = targets.Length > 0 ? targets[0].RenderTarget as Texture2D : null;
            int w = rendered?.Width ?? device.PresentationParameters.BackBufferWidth;
            int h = rendered?.Height ?? device.PresentationParameters.BackBufferHeight;
            var pixels = new Color[w * h];
            if (rendered != null) rendered.GetData(pixels);
            else
            {
                device.GetBackBufferData(pixels);
                // The installed DesktopGL backend exposes framebuffer rows from
                // the lower left; PNG texture rows start at the upper left.
                for (int y = 0; y < h / 2; y++)
                    for (int x = 0; x < w; x++)
                        (pixels[y * w + x], pixels[(h - 1 - y) * w + x]) = (pixels[(h - 1 - y) * w + x], pixels[y * w + x]);
            }
            var ui = Game1.game1.uiScreen;
            if (ui != null && ui != rendered)
            {
                var uiPixels = new Color[ui.Width * ui.Height]; ui.GetData(uiPixels);
                float uiScale = Game1.options.uiScale;
                float worldScale = Game1.options.zoomLevel;
                // Recombine the same world/UI buffers used by the game's final
                // presentation. DesktopGL's raw framebuffer omits the UI layer.
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                    {
                        int ux = (int)(x * worldScale / uiScale), uy = (int)(y * worldScale / uiScale);
                        if (ux >= ui.Width || uy >= ui.Height) continue;
                        Color front = uiPixels[uy * ui.Width + ux], back = pixels[y * w + x];
                        if (front.A == 0) continue;
                        int inverse = 255 - front.A;
                        pixels[y * w + x] = new Color(Math.Min(255, front.R + back.R * inverse / 255), Math.Min(255, front.G + back.G * inverse / 255), Math.Min(255, front.B + back.B * inverse / 255), 255);
                    }
            }
            using var texture = new Texture2D(device, w, h); texture.SetData(pixels);
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            using var stream = File.Create(path); texture.SaveAsPng(stream, w, h);
        }
        catch (Exception ex) { Monitor.Log("Screenshot unavailable: " + ex.Message, LogLevel.Warn); }
    }
    private void World(object? sender, RenderedWorldEventArgs e)
    {
        if (!Context.IsWorldReady || !Config.ShowOverlay || Game1.currentLocation is not StardewValley.Farm) return;
        foreach (var tile in Engine.Plots)
        {
            var position = Game1.GlobalToLocal(tile * 64f);
            Color color = Engine.CurrentTarget == tile ? Color.Gold : Color.ForestGreen;
            e.SpriteBatch.Draw(Game1.staminaRect, new Rectangle((int)position.X, (int)position.Y, 64, 3), color * .65f);
            e.SpriteBatch.Draw(Game1.staminaRect, new Rectangle((int)position.X, (int)position.Y + 61, 64, 3), color * .65f);
        }
    }
    private void Hud(object? sender, RenderedHudEventArgs e)
    {
        if (!Context.IsWorldReady) return;
        bool zh = LocalizedContentManager.CurrentLanguageCode == LocalizedContentManager.LanguageCode.zh;
        string text = zh
            ? $"自动农场 {(Save.Enabled ? "运行" : "暂停")}  {(Config.AdaptiveSpeed ? "自动 " : "")}目标档 {EffectiveWorkSpeed} · {StatusText.ModeName(Config.WorkMode)} | F8启停 / F9设置\n{StatusText.HudTaskReason(Status)}\n播种 {Status.Planted}  浇水 {Status.Watered}  收获 {Status.Harvested}  出货 {Status.Shipped}  清树 {Status.TreesCleared} · 作业 {Status.ActionsPerSecond:0.0}次/秒"
            : $"Farm assistant {(Save.Enabled ? "ON" : "OFF")}  {(Config.AdaptiveSpeed ? "auto " : "")}target {EffectiveWorkSpeed} · {Config.WorkMode} | F8 / F9\n{Status.Activity}\nPlant {Status.Planted}  Water {Status.Watered}  Harvest {Status.Harvested}  Ship {Status.Shipped}  Trees {Status.TreesCleared} · {Status.ActionsPerSecond:0.0} actions/s";
        if (Status.Activity is "Sleeping" or "Returning home" or "Walking to bed") text = text.Replace(StatusText.Translate(Status.Activity) + "\n", StatusText.Translate(Status.Activity) + " · " + StatusText.Translate(Status.SleepReason) + "\n");
        Vector2 size = Game1.smallFont.MeasureString(text);
        e.SpriteBatch.Draw(Game1.staminaRect, new Rectangle(12, 12, (int)size.X + 24, (int)size.Y + 18), Color.Black * .7f);
        e.SpriteBatch.DrawString(Game1.smallFont, text, new Vector2(24, 20), Color.White);
    }
}
