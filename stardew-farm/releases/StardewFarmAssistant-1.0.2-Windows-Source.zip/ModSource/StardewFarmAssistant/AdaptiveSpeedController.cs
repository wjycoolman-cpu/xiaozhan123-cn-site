namespace StardewFarmAssistant;

/// <summary>
/// Selects an acceleration target from measured render and assistant costs.
/// Samples should only be submitted while normal gameplay is actively rendering.
/// </summary>
public sealed class AdaptiveSpeedController
{
    private const int MinimumWindowFrames = 80;
    private const double WindowMilliseconds = 2000;

    private readonly Action<int, string> changed;
    private readonly List<double> frameSamples = new();
    private readonly List<double> assistantSamples = new();
    private bool enabled;
    private int ceiling = 100;
    private double sampledMilliseconds;
    private int stableWindows;
    private int consecutiveSevereFrames;

    public int EffectiveSpeed { get; private set; } = 25;
    public double FrameP95Ms { get; private set; }
    public double AssistantP95Ms { get; private set; }
    public string Reason { get; private set; } = "Awaiting valid gameplay samples";

    public AdaptiveSpeedController(Action<int, string> changed)
    {
        this.changed = changed ?? throw new ArgumentNullException(nameof(changed));
    }

    public void Configure(bool enabled, int manualSpeed, int ceiling)
    {
        int newCeiling = Math.Clamp(ceiling, 1, 200);
        int oldSpeed = EffectiveSpeed;
        bool wasEnabled = this.enabled;
        bool settingsChanged = wasEnabled != enabled || this.ceiling != newCeiling;

        this.enabled = enabled;
        this.ceiling = newCeiling;
        if (enabled)
        {
            EffectiveSpeed = wasEnabled
                ? Math.Min(EffectiveSpeed, newCeiling)
                : Math.Min(25, newCeiling);
            Reason = wasEnabled
                ? "Adaptive target retained within configured ceiling"
                : "Adaptive control started at the conservative 25x target";
        }
        else
        {
            EffectiveSpeed = Math.Clamp(manualSpeed, 1, newCeiling);
            Reason = "Adaptive control disabled; using the manual target";
            settingsChanged = true;
        }

        if (settingsChanged)
            ResetWindow();
        NotifyIfChanged(oldSpeed);
    }

    public void Sample(double frameMs, double assistantMs, bool eligible)
    {
        if (!eligible || !double.IsFinite(frameMs) || !double.IsFinite(assistantMs)
            || frameMs <= 0 || assistantMs < 0 || frameMs > 250)
        {
            consecutiveSevereFrames = 0;
            return;
        }

        if (enabled && frameMs > 45 && assistantMs > 1)
        {
            consecutiveSevereFrames++;
            if (consecutiveSevereFrames >= 3)
            {
                LowerOneStep("Three consecutive gameplay frames exceeded 45 ms", severe: true);
                return;
            }
        }
        else
        {
            consecutiveSevereFrames = 0;
        }

        frameSamples.Add(frameMs);
        assistantSamples.Add(assistantMs);
        sampledMilliseconds += frameMs;
        if (frameSamples.Count < MinimumWindowFrames || sampledMilliseconds < WindowMilliseconds)
            return;

        FrameP95Ms = Percentile95(frameSamples);
        AssistantP95Ms = Percentile95(assistantSamples);
        if (!enabled)
        {
            Reason = $"Manual target {EffectiveSpeed}x (frame p95 {FrameP95Ms:0.0} ms, assistant p95 {AssistantP95Ms:0.0} ms)";
            ClearSamples();
            return;
        }

        if (AssistantP95Ms > 8)
        {
            LowerOneStep($"Assistant p95 {AssistantP95Ms:0.0} ms exceeded its 8 ms controllable-load budget (frame p95 {FrameP95Ms:0.0} ms)");
            return;
        }

        if (FrameP95Ms > 24 && AssistantP95Ms > 2)
        {
            LowerOneStep($"Frame p95 {FrameP95Ms:0.0} ms exceeded 24 ms while assistant p95 {AssistantP95Ms:0.0} ms was above 2 ms");
            return;
        }

        bool ordinaryStable = FrameP95Ms <= 20 && AssistantP95Ms <= 5;
        bool lowAssistantProbe = FrameP95Ms <= 45 && AssistantP95Ms <= 1;
        if (ordinaryStable || lowAssistantProbe)
        {
            stableWindows++;
            if (stableWindows >= 2)
            {
                RaiseOneStep(lowAssistantProbe);
                return;
            }
            Reason = lowAssistantProbe && !ordinaryStable
                ? $"Low assistant cost despite base frame p95 {FrameP95Ms:0.0} ms; probe window 1/2 (assistant p95 {AssistantP95Ms:0.0} ms)"
                : $"Stable window 1/2 (frame p95 {FrameP95Ms:0.0} ms, assistant p95 {AssistantP95Ms:0.0} ms)";
        }
        else
        {
            stableWindows = 0;
            Reason = FrameP95Ms > 30 && AssistantP95Ms <= 2
                ? $"Holding target: base frame p95 {FrameP95Ms:0.0} ms while assistant p95 {AssistantP95Ms:0.0} ms is low; speed changes are unlikely to affect this render load"
                : $"Holding target in the hysteresis band (frame p95 {FrameP95Ms:0.0} ms, assistant p95 {AssistantP95Ms:0.0} ms)";
        }

        ClearSamples();
    }

    private void RaiseOneStep(bool lowAssistantProbe)
    {
        int oldSpeed = EffectiveSpeed;
        EffectiveSpeed = Math.Min(EffectiveSpeed + (EffectiveSpeed < 20 ? 2 : 5), ceiling);

        Reason = EffectiveSpeed == oldSpeed
            ? lowAssistantProbe
                ? $"Low assistant cost with base frame p95 {FrameP95Ms:0.0} ms; holding the configured {ceiling}x target ceiling"
                : $"Stable at the configured {ceiling}x target ceiling"
            : lowAssistantProbe
                ? $"Low assistant cost despite base frame p95 {FrameP95Ms:0.0} ms; raised target to {EffectiveSpeed}x for another measured probe"
                : $"Two stable gameplay windows; raised target to {EffectiveSpeed}x";
        ResetWindow();
        NotifyIfChanged(oldSpeed);
    }

    private void LowerOneStep(string reason, bool severe = false)
    {
        int oldSpeed = EffectiveSpeed;
        EffectiveSpeed = Math.Max(1, EffectiveSpeed - (severe ? Math.Max(5, (int)Math.Ceiling(EffectiveSpeed * .2)) : 5));
        Reason = EffectiveSpeed == oldSpeed
            ? $"{reason}; already at minimum target"
            : $"{reason}; lowered target to {EffectiveSpeed}x";
        ResetWindow();
        NotifyIfChanged(oldSpeed);
    }

    private void NotifyIfChanged(int oldSpeed)
    {
        if (EffectiveSpeed != oldSpeed)
            changed(EffectiveSpeed, Reason);
    }

    private void ResetWindow()
    {
        stableWindows = 0;
        consecutiveSevereFrames = 0;
        ClearSamples();
    }

    private void ClearSamples()
    {
        frameSamples.Clear();
        assistantSamples.Clear();
        sampledMilliseconds = 0;
    }

    private static double Percentile95(List<double> values)
    {
        double[] sorted = values.ToArray();
        Array.Sort(sorted);
        int index = Math.Max(0, (int)Math.Ceiling(sorted.Length * 0.95) - 1);
        return sorted[index];
    }
}
