using Microsoft.Xna.Framework.Input;
using StardewValley;
using StardewValley.Menus;

namespace StardewFarmAssistant;

/// <summary>Advances only the end-of-night menus already owned by the farm assistant.</summary>
public static class NightMenuHandler
{
    private const int TillerProfession = 1;
    private const int ArtisanProfession = 4;

    /// <summary>
    /// Advance an assistant-owned end-of-night menu.
    /// The caller must only invoke this while its sleep cycle owns the menu.
    /// </summary>
    /// <returns>Whether this is a recognized menu whose ownership should be retained.</returns>
    public static bool Advance(IClickableMenu menu, ModEntry owner)
    {
        ArgumentNullException.ThrowIfNull(menu);
        ArgumentNullException.ThrowIfNull(owner);

        if (menu is ShippingMenu shipping)
        {
            // ShippingMenu ignores Escape while its intro, outro, or SaveGameMenu
            // is active. Its own update loop performs the save and new-day sync.
            shipping.receiveKeyPress(Keys.Escape);
            owner.Status.Activity = "Shipping and saving";
            return true;
        }

        if (menu is not LevelUpMenu level)
            return false;

        if (!level.isProfessionChooser)
        {
            // The native LevelUpMenu cleanup path grants the level perk and
            // removes the displayed entry from Farmer.newLevels.
            level.receiveKeyPress(Keys.Escape);
            owner.Status.Activity = "Applying overnight farming level";
            return true;
        }

        if (!level.hasUpdatedProfessions)
        {
            owner.Status.Activity = "Waiting for profession choices";
            return true;
        }

        var field = owner.Helper.Reflection.GetField<List<int>>(level, "professionsToChoose", required: false);
        var candidates = field?.GetValue();
        if (candidates is null)
        {
            owner.Status.Activity = "Waiting for player profession choice";
            owner.Status.Reason = "The game's profession choices could not be read safely";
            return true;
        }

        int profession = candidates.Contains(TillerProfession)
            ? TillerProfession
            : candidates.Contains(ArtisanProfession)
                ? ArtisanProfession
                : -1;

        if (profession < 0)
        {
            owner.Status.Activity = "Waiting for player profession choice";
            owner.Status.Reason = "This profession choice is outside automatic farming's Tiller/Artisan route";
            return true;
        }

        // Mirror LevelUpMenu's native successful-choice transition, using its
        // public methods. Never add a profession which the menu didn't offer.
        if (!Game1.player.professions.Contains(profession))
            Game1.player.professions.Add(profession);
        level.getImmediateProfessionPerk(profession);
        level.RemoveLevelFromLevelList();
        level.isActive = false;
        level.informationUp = false;
        level.isProfessionChooser = false;

        owner.Status.Activity = profession == TillerProfession
            ? "Selected Tiller profession"
            : "Selected Artisan profession";
        owner.Status.Reason = "";
        owner.LogEvidence("profession", new
        {
            profession,
            name = profession == TillerProfession ? "Tiller" : "Artisan"
        });
        return true;
    }
}
