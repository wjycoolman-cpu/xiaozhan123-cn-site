using System.Text.Json;
using HarmonyLib;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Menus;

namespace StardewFarmAssistant;

/// <summary>Private, opt-in driver for the isolated acceptance profile.</summary>
public sealed class TestHarness
{
    private enum ReloadStage
    {
        None,
        ReturningToTitle,
        WaitingForSlots,
        WaitingForWorld
    }

    private const string QaMarkerName = ".autofarm-qa-root";
    private const string QaMarkerValue = "LocalTools.StardewFarmAssistant private QA v1";
    private const string DemoMarkerName = ".autofarm-demo-root";
    private const string DemoMarkerValue = "LocalTools.StardewFarmAssistant v1";
    private readonly ModEntry owner;
    private readonly string profileRoot;
    private readonly string evidencePath;
    private readonly string commandPath;
    private readonly Harmony harmony;
    private readonly bool continuousDemo;
    private readonly string? startupSlot;
    private bool launched;
    private bool characterCreationStarted;
    private bool initializedRun;
    private bool complete;
    private int tick;
    private int screenshotCountdown;
    private int planted;
    private int watered;
    private int harvested;
    private int shipped;
    private int sleeps;
    private ReloadStage reloadStage;
    private string? reloadSlotName;
    private int reloadStartedTick;
    private Item? heldWateringCan;
    private int heldWateringCanSlot = -1;
    private static string? isolatedRoot;
    private List<Microsoft.Xna.Framework.Vector2>? benchmarkPlots;
    private DateTime benchmarkStarted;
    private int benchmarkSpeed;
    private StreamWriter? evidenceWriter;
    private bool discoveryOnNextAction;
    private int interruptToolAtTick;

    public TestHarness(ModEntry owner)
    {
        this.owner = owner;
        this.continuousDemo = Environment.GetEnvironmentVariable("STARDEW_AUTOFARM_DEMO") == "1";
        this.profileRoot = ValidateProfileRoot(Environment.GetEnvironmentVariable("STARDEW_AUTOFARM_TEST_ROOT"), this.continuousDemo);
        string? requestedSlot = Environment.GetEnvironmentVariable("STARDEW_AUTOFARM_LOAD_SLOT");
        if (!string.IsNullOrWhiteSpace(requestedSlot))
        {
            if (this.continuousDemo || Path.GetFileName(requestedSlot) != requestedSlot
                || requestedSlot.Contains("..", StringComparison.Ordinal)
                || !Directory.Exists(Path.Combine(this.profileRoot, "Saves", requestedSlot)))
                throw new InvalidOperationException("Only an existing save inside the current isolated test profile can be resumed.");
            this.startupSlot = requestedSlot;
        }
        this.evidencePath = Path.Combine(this.profileRoot, "evidence", "events.jsonl");
        this.commandPath = Path.Combine(this.profileRoot, "command.txt");
        Directory.CreateDirectory(this.profileRoot);
        isolatedRoot = this.profileRoot;
        this.harmony = new Harmony("Codex.StardewFarmAssistant.isolated-test");
        this.PatchAppDataAccessors();
        this.AssertIsolation("constructor");
        this.Log("harness_ready", new { profileRoot = this.profileRoot, continuousDemo = this.continuousDemo });
    }

    public void GameLaunched()
    {
        this.AssertIsolation("game_launched");
        this.launched = true;
        this.ApplyProcessOptions();
        this.owner.RequestScreenshot(Path.Combine(this.profileRoot, "evidence", "title.png"));
        this.Log("game_launched", new
        {
            gameVersion = Game1.version,
            pauseWhenOutOfFocus = Game1.options?.pauseWhenOutOfFocus,
            soundVolume = Game1.options?.soundVolumeLevel,
            musicVolume = Game1.options?.musicVolumeLevel,
            gameSaves = StardewValley.Program.GetSavesFolder(),
            smapiData = Constants.DataPath,
            smapiLogs = Constants.LogDir,
            smapiSaves = Constants.SavesPath,
            existingIsolatedSaves = Directory.EnumerateDirectories(StardewValley.Program.GetSavesFolder()).Select(Path.GetFileName).ToArray()
        });
    }

    public void Tick()
    {
        if (!this.launched)
            return;
        this.tick++;
        if (this.interruptToolAtTick > 0 && this.tick >= this.interruptToolAtTick)
        {
            this.interruptToolAtTick = 0; this.owner.Engine.Cancel();
            this.Log("qa_tool_interrupted", new { stage = "after_native_begin_poll", Game1.player.UsingTool });
        }
        if (this.tick % 60 == 0) this.evidenceWriter?.Flush();
        if (this.benchmarkPlots != null && Context.IsWorldReady && this.owner.Status.Watered >= this.benchmarkPlots.Count
            && this.benchmarkPlots.All(t => Game1.getFarm().terrainFeatures.TryGetValue(t, out var f) && f is StardewValley.TerrainFeatures.HoeDirt dirt && dirt.state.Value == 1))
        {
            this.Log("benchmark_complete", new { target = benchmarkSpeed, plots = benchmarkPlots.Count,
                wallMs = (DateTime.UtcNow - benchmarkStarted).TotalMilliseconds, this.owner.Status.Watered,
                this.owner.Status.FrameP95Ms, this.owner.Status.AssistantP95Ms, stamina = Game1.player.Stamina });
            this.benchmarkPlots = null;
            if (this.owner.Save.Enabled) this.owner.Toggle();
            this.owner.OpenMenu();
        }
        // ExitToTitle creates fresh Options. Keep the isolated loader advancing
        // even while this acceptance process is behind the Codex window.
        if ((!Context.IsWorldReady || this.reloadStage != ReloadStage.None) && Game1.options != null)
            Game1.options.pauseWhenOutOfFocus = false;
        if (this.tick % 30 == 0)
            this.HandleCommand();
        if (this.tick % 180 == 0)
            this.LogTelemetry();
        if (this.reloadStage != ReloadStage.None)
        {
            this.DriveReload();
            return;
        }
        if (this.complete)
            return;
        if (this.screenshotCountdown > 0 && --this.screenshotCountdown == 0 && Context.IsWorldReady)
            this.owner.RequestScreenshot(Path.Combine(this.profileRoot, "evidence", $"day-{Game1.dayOfMonth:00}.png"));
        if (!Context.IsWorldReady)
        {
            this.TryCreateNewGame();
            return;
        }
        this.TryComplete();
    }

    private void StartSpeedBenchmark(int speed)
    {
        this.AssertIsolation("speed_benchmark");
        if (this.owner.Save.Enabled) this.owner.Toggle();
        if (Game1.activeClickableMenu is AssistantMenu menu) menu.exitThisMenu();
        var farm = Game1.getFarm();
        const int x0 = 30, y0 = 20, width = 6, height = 4;
        var fixture = new List<Microsoft.Xna.Framework.Vector2>();
        for (int y = y0 - 1; y <= y0 + height; y++)
            for (int x = x0 - 1; x <= x0 + width; x++)
            {
                var t = new Microsoft.Xna.Framework.Vector2(x, y);
                if (farm.doesTileHaveProperty(x, y, "Diggable", "Back") == null || farm.getBuildingAt(t) != null
                    || farm.resourceClumps.Any(c => c.getBoundingBox().Intersects(new Microsoft.Xna.Framework.Rectangle(x * 64, y * 64, 64, 64)))
                    || farm.objects.TryGetValue(t, out var obj) && obj.Name is not ("Stone" or "Twig" or "Weeds")
                    || farm.terrainFeatures.TryGetValue(t, out var tf) && tf is not (StardewValley.TerrainFeatures.HoeDirt or StardewValley.TerrainFeatures.Grass or StardewValley.TerrainFeatures.Tree))
                    throw new InvalidOperationException("Private benchmark region contains a protected or non-farmable tile.");
                fixture.Add(t);
            }
        // Explicit disposable QA fixture; never available in the continuous demo.
        foreach (var t in fixture) { farm.objects.Remove(t); farm.terrainFeatures.Remove(t); }
        this.benchmarkPlots = new();
        for (int y = y0; y < y0 + height; y++)
            for (int x = x0; x < x0 + width; x++)
            {
                var t = new Microsoft.Xna.Framework.Vector2(x, y);
                farm.terrainFeatures[t] = new StardewValley.TerrainFeatures.HoeDirt(0, farm)
                { crop = new StardewValley.Crop("472", x, y, farm) };
                this.benchmarkPlots.Add(t);
            }
        this.owner.Config.WorkMode = "custom"; this.owner.Config.AdaptiveSpeed = false; this.owner.Config.WorkSpeed = speed;
        this.owner.Config.SpeedCeiling = 200; this.owner.Config.MaxPlots = 24;
        this.owner.Config.AutoBuySeeds = this.owner.Config.AutoSleep = this.owner.Config.AutoShip = this.owner.Config.AutoStorage = this.owner.Config.AutoScarecrow = this.owner.Config.PrepareAhead = false;
        this.owner.Save.RegionX = x0; this.owner.Save.RegionY = y0;
        this.owner.Save.RegionWidth = width; this.owner.Save.RegionHeight = height;
        Game1.player.Halt(); Game1.player.Position = new Microsoft.Xna.Framework.Vector2((x0 - 1) * 64, y0 * 64);
        Game1.player.CanMove = true; Game1.player.freezePause = 0;
        Game1.player.Stamina = Game1.player.MaxStamina;
        if (Game1.player.Items.OfType<StardewValley.Tools.WateringCan>().FirstOrDefault() is { } can) can.WaterLeft = can.waterCanMax;
        Game1.timeOfDay = 800;
        this.owner.SaveConfig(); this.owner.Engine.OnDayStarted();
        this.benchmarkSpeed = speed; this.benchmarkStarted = DateTime.UtcNow;
        this.Log("qa_injected", new { fault = "uniform_24_dry_parsnip_speed_benchmark", speed, columns = width, rows = height, x = x0, y = y0, startingStamina = Game1.player.Stamina });
        this.owner.Toggle();
    }
    public void DayStarted()
    {
        this.AssertIsolation("day_started");
        this.screenshotCountdown = 120;
        this.Log("day_started", new
        {
            day = Game1.dayOfMonth,
            season = Game1.season.ToString(),
            year = Game1.year,
            money = Game1.player.Money,
            location = Game1.currentLocation?.NameOrUniqueName,
            smapiCurrentSave = Constants.CurrentSavePath,
            accumulated = new { this.planted, this.watered, this.harvested, this.shipped, this.sleeps }
        });
        if (!this.initializedRun)
        {
            this.initializedRun = true;
            if (!this.owner.Save.Enabled)
                this.owner.Toggle();
            this.Log("assistant_initialized", new { day = Game1.dayOfMonth, enabled = this.owner.Save.Enabled });
        }
        this.TryComplete();
    }

    public void Log(string kind, object data)
    {
        this.CountEvidence(kind, data);
        Directory.CreateDirectory(Path.GetDirectoryName(this.evidencePath)!);
        string line = JsonSerializer.Serialize(new
        {
            utc = DateTime.UtcNow,
            kind,
            day = Context.IsWorldReady ? Game1.dayOfMonth : 0,
            time = Context.IsWorldReady ? Game1.timeOfDay : 0,
            data
        });
        this.evidenceWriter ??= new StreamWriter(new FileStream(this.evidencePath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite), new System.Text.UTF8Encoding(false), 16384);
        this.evidenceWriter.WriteLine(line);
        if (kind is "benchmark_complete" or "quit_requested" or "qa_injected" or "harness_ready") this.evidenceWriter.Flush();
    }

    private static string ValidateProfileRoot(string? requested, bool demo)
    {
        if (string.IsNullOrWhiteSpace(requested) || !Path.IsPathFullyQualified(requested))
            throw new InvalidOperationException("STARDEW_AUTOFARM_TEST_ROOT must be an absolute path.");
        string actual = Path.GetFullPath(requested).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        RejectRealProfileOverlap(actual);
        RejectReparsePoints(actual);

        if (!demo)
        {
            DirectoryInfo? qaParent = new DirectoryInfo(actual).Parent;
            if (qaParent is null || qaParent.Name != "test-profile"
                || !File.Exists(Path.Combine(qaParent.FullName, QaMarkerName))
                || File.ReadAllText(Path.Combine(qaParent.FullName, QaMarkerName)) != QaMarkerValue)
                throw new InvalidOperationException("A private QA profile must be a direct child of a deliberately marked test-profile directory.");
            return actual;
        }

        var runDirectory = new DirectoryInfo(actual);
        DirectoryInfo? demoParent = runDirectory.Parent;
        if (demoParent is null || !string.Equals(demoParent.Name, "demo-profile", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("A demo run root must be a direct child of a directory named 'demo-profile'.");
        DirectoryInfo? markedRoot = FindMarkedDemoRoot(demoParent);
        if (markedRoot is null)
            throw new InvalidOperationException($"No ancestor contains a valid {DemoMarkerName} marker.");
        if (!IsAtOrUnder(actual, markedRoot.FullName))
            throw new InvalidOperationException("The demo run root escaped its marked demo directory.");
        return actual;
    }

    private static DirectoryInfo? FindMarkedDemoRoot(DirectoryInfo start)
    {
        for (DirectoryInfo? directory = start; directory is not null; directory = directory.Parent)
        {
            string marker = Path.Combine(directory.FullName, DemoMarkerName);
            if (File.Exists(marker))
            {
                if ((File.GetAttributes(marker) & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidOperationException($"Refusing reparse-point marker '{marker}'.");
                if (string.Equals(File.ReadAllText(marker).Trim(), DemoMarkerValue, StringComparison.Ordinal))
                    return directory;
            }
        }
        return null;
    }

    private static void RejectRealProfileOverlap(string candidate)
    {
        string realProfile = Path.GetFullPath(Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StardewValley"));
        if (IsAtOrUnder(candidate, realProfile) || IsAtOrUnder(realProfile, candidate))
            throw new InvalidOperationException("Refusing a profile root which overlaps the real Stardew Valley app-data tree.");
    }

    private static void RejectReparsePoints(string candidate)
    {
        var current = new DirectoryInfo(candidate);
        while (current is not null)
        {
            if (current.Exists && (current.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new InvalidOperationException($"Refusing reparse-point path component '{current.FullName}'.");
            current = current.Parent;
        }
    }

    private static bool IsAtOrUnder(string candidate, string root)
    {
        string normalizedRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        string normalizedCandidate = Path.GetFullPath(candidate).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        return string.Equals(normalizedCandidate, normalizedRoot, StringComparison.OrdinalIgnoreCase)
            || normalizedCandidate.StartsWith(normalizedRoot + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    }

    private void PatchAppDataAccessors()
    {
        var stringBool = new[] { typeof(string), typeof(bool) };
        this.harmony.Patch(AccessTools.Method(typeof(StardewValley.Program), nameof(StardewValley.Program.GetAppDataFolder), stringBool), prefix: new HarmonyMethod(typeof(TestHarness), nameof(PrefixFolder)));
        this.harmony.Patch(AccessTools.Method(typeof(StardewValley.Program), nameof(StardewValley.Program.GetLocalAppDataFolder), stringBool), prefix: new HarmonyMethod(typeof(TestHarness), nameof(PrefixFolder)));
        this.harmony.Patch(AccessTools.Method(typeof(StardewValley.Program), nameof(StardewValley.Program.GetSavesFolder)), prefix: new HarmonyMethod(typeof(TestHarness), nameof(PrefixSavesFolder)));
        // SMAPI computes these once in Constants' static constructor instead of
        // delegating to the game Program methods, so redirect its cached getters too.
        this.harmony.Patch(AccessTools.PropertyGetter(typeof(Constants), nameof(Constants.DataPath)), prefix: new HarmonyMethod(typeof(TestHarness), nameof(PrefixSmapiDataPath)));
        this.harmony.Patch(AccessTools.PropertyGetter(typeof(Constants), nameof(Constants.LogDir)), prefix: new HarmonyMethod(typeof(TestHarness), nameof(PrefixSmapiLogDir)));
        this.harmony.Patch(AccessTools.PropertyGetter(typeof(Constants), nameof(Constants.SavesPath)), prefix: new HarmonyMethod(typeof(TestHarness), nameof(PrefixSmapiSavesPath)));
    }

    private static bool PrefixFolder(string? subfolder, bool createIfMissing, ref string __result)
    {
        string root = isolatedRoot ?? throw new InvalidOperationException("The isolated test root was not initialized.");
        __result = subfolder is null ? root : Path.Combine(root, subfolder);
        if (createIfMissing) Directory.CreateDirectory(__result);
        return false;
    }

    private static bool PrefixSavesFolder(ref string __result)
    {
        string root = isolatedRoot ?? throw new InvalidOperationException("The isolated test root was not initialized.");
        __result = Path.Combine(root, "Saves");
        Directory.CreateDirectory(__result);
        return false;
    }

    private static bool PrefixSmapiDataPath(ref string __result)
    {
        __result = isolatedRoot ?? throw new InvalidOperationException("The isolated test root was not initialized.");
        Directory.CreateDirectory(__result);
        return false;
    }

    private static bool PrefixSmapiLogDir(ref string __result)
    {
        string root = isolatedRoot ?? throw new InvalidOperationException("The isolated test root was not initialized.");
        __result = Path.Combine(root, "ErrorLogs");
        Directory.CreateDirectory(__result);
        return false;
    }

    private static bool PrefixSmapiSavesPath(ref string __result) => PrefixSavesFolder(ref __result);

    private void AssertIsolation(string stage)
    {
        string expected = Path.GetFullPath(Path.Combine(this.profileRoot, "Saves"));
        string actual = Path.GetFullPath(StardewValley.Program.GetSavesFolder());
        if (!string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Save isolation failed at {stage}: expected '{expected}', got '{actual}'.");
        AssertExactPath(stage, "SMAPI DataPath", this.profileRoot, Constants.DataPath);
        AssertExactPath(stage, "SMAPI LogDir", Path.Combine(this.profileRoot, "ErrorLogs"), Constants.LogDir);
        AssertExactPath(stage, "SMAPI SavesPath", expected, Constants.SavesPath);
        if (Context.IsWorldReady)
        {
            string? currentSave = Constants.CurrentSavePath;
            if (string.IsNullOrWhiteSpace(currentSave) || !IsUnder(currentSave, expected))
                throw new InvalidOperationException($"SMAPI CurrentSavePath escaped isolation at {stage}: '{currentSave ?? "<null>"}'.");
        }
    }

    private static void AssertExactPath(string stage, string label, string expected, string actual)
    {
        if (!string.Equals(Path.GetFullPath(expected), Path.GetFullPath(actual), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"{label} isolation failed at {stage}: expected '{expected}', got '{actual}'.");
    }

    private static bool IsUnder(string candidate, string root)
    {
        string normalizedRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string normalizedCandidate = Path.GetFullPath(candidate).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        return normalizedCandidate.StartsWith(normalizedRoot, StringComparison.OrdinalIgnoreCase);
    }

    private void TryCreateNewGame()
    {
        if (this.characterCreationStarted || Game1.activeClickableMenu is not TitleMenu)
            return;
        this.AssertIsolation("before_character_creation");
        this.characterCreationStarted = true;
        if (this.startupSlot != null)
        {
            this.initializedRun = true;
            this.reloadSlotName = this.startupSlot;
            this.reloadStartedTick = this.tick;
            this.reloadStage = ReloadStage.WaitingForSlots;
            ((TitleMenu)Game1.activeClickableMenu).skipToTitleButtons();
            TitleMenu.subMenu = new LoadGameMenu("");
            this.Log("resume_isolated_requested", new { slotName = this.startupSlot });
            return;
        }
        Game1.resetPlayer();
        Game1.whichFarm = 0;
        Game1.whichModFarm = null;
        Game1.spawnMonstersAtNight = false;
        var menu = new CharacterCustomization(CharacterCustomization.Source.NewGame);
        TitleMenu.subMenu = menu;
        string farmerName = this.continuousDemo ? "AutoFarmer" : "CodexTest";
        string farmName = this.continuousDemo ? "AutoFarm" : "Proof";
        const string favorite = "Parsnip";
        this.owner.Helper.Reflection.GetField<TextBox>(menu, "nameBox").GetValue().Text = farmerName;
        this.owner.Helper.Reflection.GetField<TextBox>(menu, "farmnameBox").GetValue().Text = farmName;
        this.owner.Helper.Reflection.GetField<TextBox>(menu, "favThingBox").GetValue().Text = favorite;
        Game1.player.Name = farmerName;
        Game1.player.displayName = farmerName;
        Game1.player.farmName.Value = farmName;
        Game1.player.favoriteThing.Value = favorite;
        Game1.player.isCustomized.Value = true;
        menu.receiveLeftClick(menu.skipIntroButton.bounds.Center.X, menu.skipIntroButton.bounds.Center.Y);
        this.Log("character_profile", new { farmerName, farmName, favorite, farmType = Game1.whichFarm, skipIntro = true });
        menu.receiveLeftClick(menu.okButton.bounds.Center.X, menu.okButton.bounds.Center.Y);
        // createdNewCharacter(true) calls loadForNewGame(false), which replaces
        // Game1.options with defaults. Reapply before the next NewDay update can
        // be paused by loss of focus.
        this.ApplyProcessOptions();
    }

    private void ApplyProcessOptions()
    {
        if (this.continuousDemo || Environment.GetEnvironmentVariable("STARDEW_AUTOFARM_CHINESE") == "1")
            LocalizedContentManager.CurrentLanguageCode = LocalizedContentManager.LanguageCode.zh;
        // Process-local acceptance settings. Any preferences written by the game
        // are already routed into this harness's isolated app-data directory.
        if (Game1.options is null) return;
        Game1.options.pauseWhenOutOfFocus = false;
        Game1.options.setWindowedOption(1);
        bool silent = !this.continuousDemo || Environment.GetEnvironmentVariable("STARDEW_AUTOFARM_SILENT") == "1";
        if (!silent) return;
        Game1.options.soundVolumeLevel = 0f;
        Game1.options.musicVolumeLevel = 0f;
        Game1.soundCategory?.SetVolume(0f);
        Game1.musicCategory?.SetVolume(0f);
    }

    private void CountEvidence(string kind, object data)
    {
        if (kind == "sleep") { this.sleeps++; return; }
        if (kind == "shipping") { this.shipped += Math.Max(1, ReadInt(data, "Stack")); return; }
        if (kind != "action") return;
        string task = ReadString(data, "task");
        if (this.discoveryOnNextAction && task is "Clear" or "Clear grass" or "Hoe" or "Chop")
        {
            this.discoveryOnNextAction = false;
            var item = ItemRegistry.Create("(O)583");
            bool added = Game1.player.addItemToInventoryBool(item);
            this.Log("qa_injected", new { fault = "first_native_artifact_discovery_after_owned_action", added, item = item.QualifiedItemId, item.DisplayName });
        }
        if (task.Equals("Plant", StringComparison.OrdinalIgnoreCase)) this.planted++;
        else if (task.Equals("Water", StringComparison.OrdinalIgnoreCase)) this.watered++;
        else if (task.Equals("Harvest", StringComparison.OrdinalIgnoreCase)) this.harvested++;
    }

    private static int ReadInt(object value, string name) => value.GetType().GetProperty(name)?.GetValue(value) is int number ? number : 0;
    private static string ReadString(object value, string name) => value.GetType().GetProperty(name)?.GetValue(value)?.ToString() ?? "";

    private const string StorageTag = "LocalTools.StardewFarmAssistant/storage";
    private const string QaFixtureTag = "LocalTools.StardewFarmAssistant/qa-fixture";
    private const string EconomyFixture = "economy-v1";
    private static readonly Microsoft.Xna.Framework.Vector2 EconomyNearChest = new(29, 24);
    private static readonly Microsoft.Xna.Framework.Vector2 EconomyUnknownChest = new(30, 24);
    private static readonly Microsoft.Xna.Framework.Vector2 EconomyOtherChest = new(31, 24);
    private static readonly Microsoft.Xna.Framework.Vector2 EconomyFarChest = new(36, 24);

    private StardewValley.Objects.Chest CreateQaChest(StardewValley.Farm farm, Microsoft.Xna.Framework.Vector2 tile, string? storageOwner, string role)
    {
        var chest = new StardewValley.Objects.Chest(playerChest: true);
        chest.modData[QaFixtureTag] = EconomyFixture + "/" + role;
        if (storageOwner != null) chest.modData[StorageTag] = storageOwner;
        farm.objects[tile] = chest;
        return chest;
    }

    private static StardewValley.Object QaObject(string id, int stack, int quality = 0)
    {
        var item = ItemRegistry.Create<StardewValley.Object>(id, stack);
        item.Quality = quality;
        return item;
    }

    private void SetupEconomyFixture()
    {
        this.AssertIsolation("qa_economy_fixture");
        this.StartSpeedBenchmark(200);
        this.benchmarkPlots = null;
        if (this.owner.Save.Enabled) this.owner.Toggle();
        if (Game1.activeClickableMenu is AssistantMenu menu) menu.exitThisMenu();
        var farm = Game1.getFarm();
        for (int y = 20; y < 24; y++)
            for (int x = 30; x < 36; x++)
                if (farm.terrainFeatures.TryGetValue(new Microsoft.Xna.Framework.Vector2(x, y), out var feature)
                    && feature is StardewValley.TerrainFeatures.HoeDirt dirt)
                    dirt.state.Value = 1;

        string ownerId = Game1.player.UniqueMultiplayerID.ToString(System.Globalization.CultureInfo.InvariantCulture);
        var near = this.CreateQaChest(farm, EconomyNearChest, ownerId, "near-owned");
        var unknown = this.CreateQaChest(farm, EconomyUnknownChest, null, "unknown-untagged");
        var other = this.CreateQaChest(farm, EconomyOtherChest, "qa-other-owner", "other-owner");
        var far = this.CreateQaChest(farm, EconomyFarChest, ownerId, "far-owned");
        near.GetItemsForPlayer(Game1.player.UniqueMultiplayerID).Add(QaObject("(O)24", 9));
        near.GetItemsForPlayer(Game1.player.UniqueMultiplayerID).Add(QaObject("(O)24", 4, 1));
        far.GetItemsForPlayer(Game1.player.UniqueMultiplayerID).Add(QaObject("(O)24", 2, 2));
        unknown.GetItemsForPlayer(Game1.player.UniqueMultiplayerID).Add(QaObject("(O)190", 3));
        other.GetItemsForPlayer(Game1.player.UniqueMultiplayerID).Add(QaObject("(O)583", 1));

        while (Game1.player.Items.Count < Game1.player.MaxItems) Game1.player.Items.Add(null);
        for (int i = 0; i < Game1.player.MaxItems; i++)
            if (Game1.player.Items[i] is not StardewValley.Tool) Game1.player.Items[i] = null;
        var open = Enumerable.Range(0, Game1.player.MaxItems).Where(i => Game1.player.Items[i] == null).ToList();
        if (open.Count < 2) throw new InvalidOperationException("Economy fixture requires two non-tool backpack slots.");
        Game1.player.Items[open[0]] = QaObject("(O)24", 8);
        Game1.player.Items[open[1]] = QaObject("(O)24", 7);
        for (int i = 2; i < open.Count; i++)
        {
            var protectedItem = QaObject(i % 2 == 0 ? "(O)190" : "(O)583", 1);
            protectedItem.Stack = protectedItem.maximumStackSize();
            Game1.player.Items[open[i]] = protectedItem;
        }

        this.owner.Save.Harvested.Clear();
        this.owner.Save.Harvested["(O)24:0"] = 20;
        this.owner.Save.Harvested["(O)24:1"] = 4;
        this.owner.Save.Harvested["(O)24:2"] = 2;
        farm.getShippingBin(Game1.player).Clear();
        this.owner.Config.KeepEachCrop = 5;
        this.owner.Config.AutoShip = true;
        this.owner.Config.AutoStorage = false;
        this.owner.Config.AutoBuySeeds = false;
        this.owner.Config.AutoSleep = false;
        this.owner.Config.PrepareAhead = false;
        Game1.player.Halt();
        Game1.player.Position = new Microsoft.Xna.Framework.Vector2(29 * 64, 23 * 64);
        Game1.player.CanMove = true;
        this.owner.SaveConfig();
        this.owner.Engine.OnDayStarted();
        this.Log("qa_injected", new
        {
            fault = "economy_owned_storage_provenance_and_reserve_fixture",
            source = "private_qa_command",
            near = new { x = EconomyNearChest.X, y = EconomyNearChest.Y },
            far = new { x = EconomyFarChest.X, y = EconomyFarChest.Y },
            backpackLow = new[] { 8, 7 }, nearLow = 9, nearSilver = 4, farGold = 2,
            ledger = new { low = 20, silver = 4, gold = 2 }, keep = 5,
            expectedDeposit = 11, expectedShip = 21, expectedPhysicalRemaining = 9
        });
    }

    private void RunEconomyDeposit()
    {
        this.AssertIsolation("qa_economy_deposit");
        var farm = Game1.getFarm();
        string ownerId = Game1.player.UniqueMultiplayerID.ToString(System.Globalization.CultureInfo.InvariantCulture);
        if (!farm.objects.TryGetValue(EconomyNearChest, out var placed)
            || placed is not StardewValley.Objects.Chest chest
            || !chest.modData.TryGetValue(QaFixtureTag, out string? fixtureTag) || fixtureTag != EconomyFixture + "/near-owned"
            || !chest.modData.TryGetValue(StorageTag, out string? taggedOwner) || taggedOwner != ownerId
            || Math.Abs(Game1.player.TilePoint.X - (int)EconomyNearChest.X) + Math.Abs(Game1.player.TilePoint.Y - (int)EconomyNearChest.Y) != 1)
        {
            this.Log("qa_rejected", new { command = "qa-economy-deposit", reason = "Fixture near chest or native adjacent position is missing" });
            return;
        }
        var storage = this.owner.Helper.Reflection.GetField<InventoryStorage>(this.owner.Engine, "storage").GetValue();
        int deposited = this.owner.Helper.Reflection.GetMethod(storage, "DepositEligibleItems").Invoke<int>(farm, chest);
        this.Log("qa_economy_deposit", new
        {
            source = "private_qa_reflection_probe", deposited, expected = 11,
            ledger = this.owner.Save.Harvested.ToDictionary(pair => pair.Key, pair => pair.Value)
        });
    }

    private void SetupEconomyBlockFixture()
    {
        this.AssertIsolation("qa_economy_block");
        if (this.owner.Save.Enabled) this.owner.Toggle();
        var farm = Game1.getFarm();
        foreach (var tile in new[] { EconomyNearChest, EconomyUnknownChest, EconomyOtherChest, EconomyFarChest })
            if (farm.objects.TryGetValue(tile, out var existing) && existing.modData.ContainsKey(QaFixtureTag)) farm.objects.Remove(tile);
        var center = new Microsoft.Xna.Framework.Vector2(34, 22);
        var blockers = new[] { new Microsoft.Xna.Framework.Vector2(34, 21), new(33, 22), new(35, 22), new(34, 23) };
        foreach (var tile in blockers.Append(center)) { farm.objects.Remove(tile); farm.terrainFeatures.Remove(tile); }
        string ownerId = Game1.player.UniqueMultiplayerID.ToString(System.Globalization.CultureInfo.InvariantCulture);
        var chest = this.CreateQaChest(farm, center, ownerId, "blocked-owned");
        chest.GetItemsForPlayer(Game1.player.UniqueMultiplayerID).Add(QaObject("(O)24", 10));
        foreach (var tile in blockers)
        {
            var blocker = QaObject("(O)390", 1);
            blocker.modData[QaFixtureTag] = EconomyFixture + "/native-hard-blocker";
            farm.objects[tile] = blocker;
        }
        for (int i = 0; i < Game1.player.MaxItems; i++)
            if (Game1.player.Items[i] is StardewValley.Object item && item.QualifiedItemId == "(O)24") Game1.player.Items[i] = null;
        this.owner.Save.Harvested.Clear();
        this.owner.Save.Harvested["(O)24:0"] = 10;
        farm.getShippingBin(Game1.player).Clear();
        this.owner.Config.KeepEachCrop = 0;
        this.owner.Config.AutoShip = true;
        this.owner.Config.AutoStorage = false;
        this.owner.Config.ClearDebris = false;
        this.owner.SaveConfig();
        this.owner.Engine.OnDayStarted();
        this.Log("qa_injected", new
        {
            fault = "unreachable_owned_storage_surplus",
            source = "private_qa_command", chest = new { x = center.X, y = center.Y },
            blockers = blockers.Select(tile => new { x = tile.X, y = tile.Y }).ToArray(), ledger = 10, backpackParsnip = 0
        });
    }

    private void PrepareEconomyShippingWalk()
    {
        this.AssertIsolation("qa_economy_shipping_walk");
        var farm = Game1.getFarm();
        if (!farm.objects.TryGetValue(EconomyNearChest, out var chest)
            || !chest.modData.TryGetValue(QaFixtureTag, out string? tag) || tag != EconomyFixture + "/near-owned")
        { this.Log("qa_rejected", new { command = "qa-economy-trip", reason = "Economy fixture missing" }); return; }
        if (this.owner.Save.Enabled) this.owner.Toggle();
        if (Game1.activeClickableMenu is AssistantMenu menu) menu.exitThisMenu();
        bool firstShippingStep = this.owner.Helper.Reflection.GetMethod(this.owner.Engine, "ShipOwnCrops").Invoke<bool>(farm);
        while (Game1.player.Items.Count < Game1.player.MaxItems) Game1.player.Items.Add(null);
        for (int slot = 0; slot < Game1.player.MaxItems; slot++)
            if (Game1.player.Items[slot] == null) Game1.player.Items[slot] = QaObject("(O)583", 999);
        Game1.player.Halt();
        Game1.player.Position = new Microsoft.Xna.Framework.Vector2(35 * 64, 24 * 64);
        this.Log("qa_injected", new
        {
            fault = "full_backpack_real_owned_storage_shipping_walk", source = "private_qa_command",
            firstShippingStep, slotsFree = Game1.player.freeSpotsInInventory(),
            position = new { x = 35, y = 24 }, ledger = this.owner.Save.Harvested.ToDictionary(pair => pair.Key, pair => pair.Value)
        });
    }

    private void LogStorageState()
    {
        if (!Context.IsWorldReady) return;
        var farm = Game1.getFarm();
        string ownerId = Game1.player.UniqueMultiplayerID.ToString(System.Globalization.CultureInfo.InvariantCulture);
        object ItemState(Item item) => new { item.QualifiedItemId, quality = item is StardewValley.Object obj ? obj.Quality : 0, item.Stack };
        this.Log("storage_state", new
        {
            player = new { x = Game1.player.TilePoint.X, y = Game1.player.TilePoint.Y },
            chests = farm.objects.Pairs.Where(pair => pair.Value is StardewValley.Objects.Chest)
                .OrderBy(pair => pair.Key.Y).ThenBy(pair => pair.Key.X)
                .Select(pair =>
                {
                    var chest = (StardewValley.Objects.Chest)pair.Value;
                    chest.modData.TryGetValue(StorageTag, out string? tag);
                    chest.modData.TryGetValue(QaFixtureTag, out string? qaSource);
                    return new
                    {
                        x = pair.Key.X, y = pair.Key.Y, storageTag = tag,
                        relation = tag == null ? "untagged" : tag == ownerId ? "current-owner" : "other-owner",
                        qaSource,
                        items = chest.GetItemsForPlayer(Game1.player.UniqueMultiplayerID).OfType<Item>().Select(ItemState).ToArray()
                    };
                }).ToArray(),
            backpack = Game1.player.Items.OfType<Item>().Select(ItemState).ToArray(),
            ledger = this.owner.Save.Harvested.ToDictionary(pair => pair.Key, pair => pair.Value),
            shippingBin = farm.getShippingBin(Game1.player).OfType<Item>().Select(ItemState).ToArray()
        });
    }

    private static (StardewValley.Event? Event, string? Command, bool IsPetEvent) GetPetEventState()
    {
        var ev = Game1.currentLocation?.currentEvent;
        string? command = ev != null && ev.CurrentCommand >= 0 && ev.CurrentCommand < ev.eventCommands.Length
            ? ev.eventCommands[ev.CurrentCommand]
            : null;
        bool petEvent = ev != null && Game1.eventUp
            && StardewValley.Characters.Pet.TryGetData(Game1.player.whichPetType, out var petData)
            && ev.id == petData.AdoptionEventId;
        return (ev, command, petEvent);
    }

    private void LogPetInput(string commandName, bool accepted, string reason)
    {
        var state = GetPetEventState();
        this.Log("manual_native_input", new
        {
            command = commandName, accepted, reason,
            eventId = state.Event?.id,
            menu = Game1.activeClickableMenu?.GetType().Name,
            commandIndex = state.Event?.CurrentCommand,
            currentCommand = state.Command
        });
    }

    private void PetNext()
    {
        var state = GetPetEventState();
        if (!state.IsPetEvent) { this.LogPetInput("pet-next", false, "not_the_native_pet_adoption_event"); return; }
        if (Game1.activeClickableMenu is not DialogueBox { isQuestion: false } dialogue
            || dialogue.characterDialogue?.speaker?.Name != "Marnie")
        { this.LogPetInput("pet-next", false, "current_menu_is_not_marnie_native_dialogue"); return; }
        dialogue.receiveLeftClick(0, 0);
        this.LogPetInput("pet-next", true, "one_native_dialogue_click");
    }

    private void PetYes()
    {
        var state = GetPetEventState();
        if (!state.IsPetEvent) { this.LogPetInput("pet-yes", false, "not_the_native_pet_adoption_event"); return; }
        if (Game1.activeClickableMenu is not DialogueBox dialogue || !dialogue.isQuestion
            || dialogue.characterDialogue != null || Game1.currentLocation.lastQuestionKey != "pet")
        { this.LogPetInput("pet-yes", false, "current_menu_is_not_the_native_pet_question"); return; }
        string text = dialogue.getCurrentString() ?? "";
        if (dialogue.transitioning || dialogue.safetyTimer > 0 || dialogue.characterIndexInDialogue < text.Length - 1)
        { this.LogPetInput("pet-yes", false, "native_question_is_still_transitioning_typing_or_safety_locked"); return; }
        int responseIndex = Array.FindIndex(dialogue.responses, response => response.responseKey == "Yes");
        if (responseIndex < 0 || dialogue.responseCC == null || responseIndex >= dialogue.responseCC.Count)
        { this.LogPetInput("pet-yes", false, "native_yes_response_or_click_target_is_missing"); return; }
        var center = dialogue.responseCC[responseIndex].bounds.Center;
        dialogue.performHoverAction(center.X, center.Y);
        if (dialogue.selectedResponse != responseIndex)
        { this.LogPetInput("pet-yes", false, "native_hover_did_not_select_yes"); return; }
        dialogue.receiveLeftClick(center.X, center.Y);
        this.LogPetInput("pet-yes", true, "one_native_yes_click");
    }

    private void PetName()
    {
        var state = GetPetEventState();
        if (!state.IsPetEvent) { this.LogPetInput("pet-name", false, "not_the_native_pet_adoption_event"); return; }
        if (Game1.activeClickableMenu is not NamingMenu naming || naming.doneNaming == null
            || !ReferenceEquals(naming.doneNaming.Target, state.Event) || naming.doneNaming.Method.Name != "namePet")
        { this.LogPetInput("pet-name", false, "current_menu_callback_is_not_native_event_namePet"); return; }
        var center = naming.doneNamingButton.bounds.Center;
        naming.receiveLeftClick(center.X, center.Y);
        this.LogPetInput("pet-name", true, "one_native_default_name_click");
    }

    private void LogPetState()
    {
        var state = GetPetEventState();
        var dialogue = Game1.activeClickableMenu as DialogueBox;
        this.Log("pet_state", new
        {
            eventUp = Game1.eventUp,
            eventId = state.Event?.id,
            commandIndex = state.Event?.CurrentCommand,
            command = state.Command,
            isPetEvent = state.IsPetEvent,
            menu = Game1.activeClickableMenu?.GetType().Name,
            dialogueText = dialogue?.getCurrentString(),
            isQuestion = dialogue?.isQuestion,
            responseKeys = dialogue?.responses?.Select(response => response.responseKey).ToArray(),
            nativePetCount = Game1.locations.Sum(location => location.characters.OfType<StardewValley.Characters.Pet>().Count())
        });
    }

    private void InjectNextForagingLevel()
    {
        this.AssertIsolation("qa_night_level");
        Farmer who = Game1.player;
        int levelBefore = who.foragingLevel.Value;
        int experienceBefore = who.experiencePoints[2];
        if (levelBefore >= 10)
        {
            this.Log("qa_rejected", new { command = "qa-night-level", reason = "Foraging is already level 10", levelBefore, experienceBefore });
            return;
        }
        if (who.newLevels.Any(level => level.X == 2))
        {
            this.Log("qa_rejected", new { command = "qa-night-level", reason = "A native foraging level-up is already pending", levelBefore, experienceBefore });
            return;
        }
        int targetLevel = levelBefore + 1;
        int targetExperience = Farmer.getBaseExperienceForLevel(targetLevel);
        int grantedExperience = Math.Max(1, targetExperience - experienceBefore);
        who.gainExperience(2, grantedExperience);
        this.Log("qa_injected", new
        {
            fault = "native_foraging_level_for_next_sleep",
            source = "private_qa_command",
            skill = 2,
            targetLevel,
            grantedExperience,
            experienceBefore,
            experienceAfter = who.experiencePoints[2],
            levelBefore,
            levelAfter = who.foragingLevel.Value,
            pendingNativeLevels = who.newLevels.Where(level => level.X == 2)
                .Select(level => new { skill = level.X, level = level.Y }).ToArray()
        });
    }

    private void TryComplete()
    {
        if (this.continuousDemo)
            return;
        if (!Context.IsWorldReady || Game1.dayOfMonth < 7 || this.planted <= 0 || this.watered <= 0 || this.harvested <= 0 || this.shipped <= 0 || this.sleeps < 2)
            return;
        if (this.owner.Save.Enabled) this.owner.Toggle();
        this.complete = true;
        this.owner.RequestScreenshot(Path.Combine(this.profileRoot, "evidence", "complete.png"));
        this.Log("acceptance_complete", new { day = Game1.dayOfMonth, this.planted, this.watered, this.harvested, this.shipped, this.sleeps, money = Game1.player.Money, status = this.owner.Status });
    }

    private void HandleCommand()
    {
        if (!File.Exists(this.commandPath)) return;
        string command = File.ReadAllText(this.commandPath).Trim();
        File.Delete(this.commandPath);
        string[] parts = command.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        string verb = parts.FirstOrDefault()?.ToLowerInvariant() ?? "";
        switch (verb)
        {
            case "qa-night-level":
                if (!this.continuousDemo && Context.IsWorldReady && !this.owner.Save.Enabled
                    && Game1.activeClickableMenu == null && !Game1.eventUp && !Game1.player.UsingTool)
                    this.InjectNextForagingLevel();
                else this.Log("qa_rejected", new
                {
                    command = verb,
                    reason = "Requires a private non-demo world with the assistant off and no menu, event, or native tool action",
                    continuousDemo = this.continuousDemo,
                    worldReady = Context.IsWorldReady,
                    assistantEnabled = Context.IsWorldReady && this.owner.Save.Enabled,
                    menu = Game1.activeClickableMenu?.GetType().Name,
                    eventUp = Game1.eventUp,
                    usingTool = Context.IsWorldReady && Game1.player.UsingTool
                });
                break;
            case "qa-economy-fixture":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm && !Game1.player.UsingTool)
                    this.SetupEconomyFixture();
                else this.Log("qa_rejected", new { command = verb, reason = "Requires an idle private QA farm; continuous demo injection is forbidden" });
                break;
            case "qa-economy-deposit":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm && !Game1.player.UsingTool)
                    this.RunEconomyDeposit();
                else this.Log("qa_rejected", new { command = verb, reason = "Requires an idle private QA farm; continuous demo injection is forbidden" });
                break;
            case "qa-economy-block":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm && !Game1.player.UsingTool)
                    this.SetupEconomyBlockFixture();
                else this.Log("qa_rejected", new { command = verb, reason = "Requires an idle private QA farm; continuous demo injection is forbidden" });
                break;
            case "qa-economy-trip":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm && !Game1.player.UsingTool)
                    this.PrepareEconomyShippingWalk();
                else this.Log("qa_rejected", new { command = verb, reason = "Requires an idle private QA farm; continuous demo injection is forbidden" });
                break;
            case "storage-state":
                this.LogStorageState();
                break;
            case "pet-next":
                if (Context.IsWorldReady) this.PetNext();
                else this.LogPetInput(verb, false, "world_not_ready");
                break;
            case "pet-yes":
                if (Context.IsWorldReady) this.PetYes();
                else this.LogPetInput(verb, false, "world_not_ready");
                break;
            case "pet-name":
                if (Context.IsWorldReady) this.PetName();
                else this.LogPetInput(verb, false, "world_not_ready");
                break;
            case "pet-state":
                if (Context.IsWorldReady) this.LogPetState();
                else this.Log("pet_state", new { worldReady = false });
                break;
            case "qa-nearby-clearing":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm && !Game1.player.UsingTool)
                {
                    this.StartSpeedBenchmark(200); this.benchmarkPlots = null;
                    if (this.owner.Save.Enabled) this.owner.Toggle();
                    var nearFarm = Game1.getFarm();
                    for (int y = 20; y < 24; y++) for (int x = 30; x < 36; x++)
                        ((StardewValley.TerrainFeatures.HoeDirt)nearFarm.terrainFeatures[new Microsoft.Xna.Framework.Vector2(x, y)]).state.Value = 1;
                    foreach (var item in Game1.player.Items.OfType<StardewValley.Object>().Where(i => DataLoader.Crops(Game1.content).ContainsKey(i.ItemId)).ToList())
                        Game1.player.Items[Game1.player.Items.IndexOf(item)] = null;
                    this.owner.Save.RegionX = 28; this.owner.Save.RegionY = 18; this.owner.Save.RegionWidth = 12; this.owner.Save.RegionHeight = 10;
                    this.owner.Save.ExpansionTiles.Clear(); this.owner.Config.PrepareAhead = true;
                    Game1.player.Position = new Microsoft.Xna.Framework.Vector2(30 * 64, 24 * 64);
                    nearFarm.terrainFeatures[new Microsoft.Xna.Framework.Vector2(29, 24)] = new StardewValley.TerrainFeatures.Grass(1, 4);
                    nearFarm.objects[new Microsoft.Xna.Framework.Vector2(32, 24)] = ItemRegistry.Create<StardewValley.Object>("(O)2");
                    nearFarm.terrainFeatures[new Microsoft.Xna.Framework.Vector2(36, 23)] = new StardewValley.TerrainFeatures.Tree("1", 5);
                    this.discoveryOnNextAction = true; this.owner.SaveConfig(); this.owner.Engine.OnDayStarted();
                    this.Log("qa_injected", new { fault = "adjacent_grass_vs_far_tree_and_stone", playerX = 30, playerY = 24, grassX = 29, grassY = 24, treeX = 36, treeY = 23, stoneX = 32, stoneY = 24 });
                    this.owner.Toggle();
                }
                break;
            case "qa-interrupt-tool":
            case "qa-interrupt-animation":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm interruptFarm && !Game1.player.UsingTool)
                {
                    if (this.owner.Save.Enabled) this.owner.Toggle();
                    if (Game1.activeClickableMenu is AssistantMenu oldMenu) oldMenu.exitThisMenu();
                    var can = Game1.player.Items.OfType<StardewValley.Tools.WateringCan>().First();
                    var tile = new Microsoft.Xna.Framework.Vector2(30, 20);
                    if (interruptFarm.terrainFeatures.TryGetValue(tile, out var feature) && feature is StardewValley.TerrainFeatures.HoeDirt dry)
                    {
                        dry.state.Value = 0; can.WaterLeft = can.waterCanMax;
                        Game1.player.Position = new Microsoft.Xna.Framework.Vector2(29 * 64, 20 * 64);
                        this.owner.Helper.Reflection.GetField<string>(this.owner.Engine, "task").SetValue("Water");
                        this.owner.Helper.Reflection.GetMethod(this.owner.Engine, "StartTool").Invoke(can, interruptFarm, tile);
                        if (verb == "qa-interrupt-tool") this.owner.Engine.Cancel();
                        else this.interruptToolAtTick = this.tick + 3;
                        this.Log("qa_injected", new { fault = verb, stage = verb == "qa-interrupt-tool" ? "before_native_begin_poll" : "during_native_begin", can.WaterLeft, Game1.player.Stamina });
                    }
                }
                break;
            case "qa-tool-state":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm toolFarm)
                {
                    var probe = new Microsoft.Xna.Framework.Vector2(30, 20);
                    this.Log("qa_tool_state", new
                    {
                        Game1.player.UsingTool, Game1.player.CanMove, Game1.player.freezePause,
                        Game1.player.FarmerSprite.PauseForSingleAnimation,
                        tool = Game1.player.CurrentTool?.GetType().Name,
                        water = Game1.player.Items.OfType<StardewValley.Tools.WateringCan>().FirstOrDefault()?.WaterLeft,
                        dirtState = toolFarm.terrainFeatures.TryGetValue(probe, out var probeFeature)
                            && probeFeature is StardewValley.TerrainFeatures.HoeDirt probeDirt ? (int?)probeDirt.state.Value : null,
                        Game1.player.Stamina, menu = Game1.activeClickableMenu?.GetType().Name
                    });
                }
                break;
            case "qa-expansion-state":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm expansionFarm)
                {
                    var core = this.owner.Save.ExpansionTiles.ToHashSet();
                    var reached = new HashSet<Microsoft.Xna.Framework.Point>();
                    var frontier = new Queue<Microsoft.Xna.Framework.Point>();
                    if (core.Count > 0) { frontier.Enqueue(core.First()); reached.Add(core.First()); }
                    while (frontier.Count > 0)
                    {
                        var point = frontier.Dequeue();
                        foreach (var direction in new[] { new Microsoft.Xna.Framework.Point(0, 1), new Microsoft.Xna.Framework.Point(-1, 0), new Microsoft.Xna.Framework.Point(1, 0), new Microsoft.Xna.Framework.Point(0, -1) })
                            if (core.Contains(point + direction) && reached.Add(point + direction)) frontier.Enqueue(point + direction);
                    }
                    this.Log("qa_expansion_state", new
                    {
                        core = core.Count, connected = reached.Count,
                        unfinished = core.Count(p => expansionFarm.objects.ContainsKey(p.ToVector2())
                            || expansionFarm.terrainFeatures.TryGetValue(p.ToVector2(), out var f) && f is not StardewValley.TerrainFeatures.HoeDirt),
                        this.owner.Status.TreesCleared
                    });
                }
                break;
            case "qa-foreign-notice":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.activeClickableMenu == null)
                { Game1.drawObjectDialogue("Private unrelated notice"); this.Log("qa_injected", new { fault = "unowned_plain_dialogue" }); }
                break;
            case "qa-dismiss-notice":
                if (!this.continuousDemo && Game1.activeClickableMenu is DialogueBox { isQuestion: false, characterDialogue: null } plain)
                    plain.receiveLeftClick(0, 0);
                break;
            case "qa-speed-benchmark":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.currentLocation is StardewValley.Farm
                    && !Game1.player.UsingTool && parts.Length == 2 && int.TryParse(parts[1], out int benchSpeed) && benchSpeed >= 1 && benchSpeed <= 200)
                    this.StartSpeedBenchmark(benchSpeed);
                else this.Log("benchmark_rejected", new { reason = "Requires a private QA farm, completed native swing and integer target 1..200" });
                break;
            case "on": if (Context.IsWorldReady && !this.owner.Save.Enabled) this.owner.Toggle(); break;
            case "off": if (Context.IsWorldReady && this.owner.Save.Enabled) this.owner.Toggle(); break;
            case "menu":
            case "open": if (Context.IsWorldReady) this.owner.OpenMenu(); break;
            case "close":
                if (Game1.activeClickableMenu is AssistantMenu assistantMenu) assistantMenu.exitThisMenu();
                break;
            case "click":
                if (Game1.activeClickableMenu is AssistantMenu clickable && parts.Length == 3
                    && int.TryParse(parts[1], out int clickX) && int.TryParse(parts[2], out int clickY))
                {
                    clickable.receiveLeftClick(clickX, clickY);
                    this.Log("settings_click", new { clickX, clickY, this.owner.Config.WorkMode, this.owner.Config.WorkSpeed, this.owner.Config.PrepareAhead, this.owner.Config.SleepWhenFinished, this.owner.Save.Enabled });
                }
                break;
            case "screenshot":
                this.owner.RequestScreenshot(Path.Combine(this.profileRoot, "evidence", $"manual-{DateTime.Now:yyyyMMdd-HHmmss}.png"));
                break;
            case "speed":
                if (parts.Length == 2 && int.TryParse(parts[1], out int speed))
                {
                    this.owner.Config.WorkSpeed = speed;
                    this.owner.Config.AdaptiveSpeed = false;
                    this.owner.Config.SpeedCeiling = Math.Max(this.owner.Config.SpeedCeiling, speed);
                    this.owner.Config.WorkMode = "custom";
                    this.owner.SaveConfig();
                    this.Log("speed_changed", new { requested = speed, applied = this.owner.Config.WorkSpeed });
                }
                else this.Log("invalid_command", new { command, expected = "speed 1|2|5|10|25|50" });
                break;
            case "adaptive-target":
                if (parts.Length == 2 && int.TryParse(parts[1], out int ceiling) && ceiling >= 1 && ceiling <= 200)
                {
                    this.owner.Config.WorkSpeed = ceiling;
                    this.owner.Config.AdaptiveSpeed = true;
                    this.owner.Config.SpeedCeiling = ceiling;
                    this.owner.SaveConfig();
                    this.Log("adaptive_target_changed", new { ceiling, adaptive = true });
                }
                break;
            case "status": this.Log("status", new { this.owner.Status, this.planted, this.watered, this.harvested, this.shipped, this.sleeps }); break;
            case "mode":
                if (parts.Length == 2) { this.owner.Config.SetMode(parts[1]); this.owner.SaveConfig(); this.Log("mode_changed", new { this.owner.Config.WorkMode, this.owner.Config.WorkSpeed, this.owner.Config.PrepareAhead, this.owner.Config.SleepWhenFinished }); }
                break;
            case "inventory": this.Log("inventory", new { items = Game1.player.Items.Where(i => i != null).Select(i => new { i.QualifiedItemId, i.Stack, i.DisplayName }).ToArray(), maxItems = Game1.player.MaxItems, slots = Game1.player.Items.Count, freeSlots = Game1.player.freeSpotsInInventory(), harvestedLedger = this.owner.Save.Harvested }); break;
            case "qa-empty-water":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.player.Items.OfType<StardewValley.Tools.WateringCan>().FirstOrDefault() is { } emptyCan)
                { emptyCan.WaterLeft = 0; this.Log("qa_injected", new { fault = "empty_watering_can" }); }
                break;
            case "qa-storage":
                if (!this.continuousDemo && Context.IsWorldReady)
                {
                    string[] resourceIds = { "388", "390", "771", "92", "382", "330", "770" };
                    int resourceIndex = 0;
                    while (Game1.player.Items.Count < Game1.player.MaxItems) Game1.player.Items.Add(null);
                    for (int index = 0; index < Game1.player.MaxItems && resourceIndex < resourceIds.Length; index++)
                    {
                        if (Game1.player.Items[index] != null) continue;
                        string resourceId = resourceIds[resourceIndex++];
                        Game1.player.Items[index] = ItemRegistry.Create(resourceId, resourceId == "388" ? 80 : 99);
                    }
                    this.Log("qa_injected", new { fault = "full_backpack_with_storage_materials", resourceStacks = resourceIndex, slotsFree = Game1.player.freeSpotsInInventory() });
                }
                break;
            case "qa-missing-water":
                if (!this.continuousDemo && Context.IsWorldReady && heldWateringCan == null && Game1.player.Items.OfType<StardewValley.Tools.WateringCan>().FirstOrDefault() is { } missingCan)
                { heldWateringCan = missingCan; heldWateringCanSlot = Game1.player.Items.IndexOf(missingCan); Game1.player.Items[heldWateringCanSlot] = null; this.owner.Engine.InvalidateLayout(); this.Log("qa_injected", new { fault = "missing_watering_can" }); }
                break;
            case "qa-restore-water":
                if (!this.continuousDemo && Context.IsWorldReady && heldWateringCan != null)
                {
                    int slot = Game1.player.Items[heldWateringCanSlot] == null ? heldWateringCanSlot : Game1.player.Items.IndexOf(null);
                    if (slot >= 0 && slot < Game1.player.MaxItems)
                    { Game1.player.Items[slot] = heldWateringCan; heldWateringCan = null; heldWateringCanSlot = -1; this.Log("qa_restored", new { fault = "missing_watering_can", slot }); }
                    else this.Log("qa_restore_blocked", new { fault = "missing_watering_can", reason = "no free slot; held item preserved" });
                }
                break;
            case "qa-stall":
                if (!this.continuousDemo && Context.IsWorldReady)
                { this.owner.Engine.InvalidateLayout(); Game1.player.freezePause = 20000; Game1.player.CanMove = false; this.Log("qa_injected", new { fault = "character_action_stall", durationMs = 20000 }); }
                break;
            case "qa-restore-stall":
                if (!this.continuousDemo && Context.IsWorldReady)
                { Game1.player.freezePause = 0; Game1.player.CanMove = true; this.Log("qa_restored", new { fault = "character_action_stall" }); }
                break;
            case "qa-storage-state":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.getFarm() is { } storageFarm)
                    this.Log("storage_snapshot", new
                    {
                        scarecrowCount = storageFarm.objects.Values.Count(item => item.IsScarecrow()),
                        wood = Game1.player.Items.CountId("388"),
                        slotsFree = Game1.player.freeSpotsInInventory(),
                        chests = storageFarm.objects.Pairs.Where(p => p.Value is StardewValley.Objects.Chest c && c.modData.ContainsKey("LocalTools.StardewFarmAssistant/storage"))
                            .Select(p => new { x = p.Key.X, y = p.Key.Y, capacity = ((StardewValley.Objects.Chest)p.Value).GetActualCapacity(), items = ((StardewValley.Objects.Chest)p.Value).GetItemsForPlayer(Game1.player.UniqueMultiplayerID).Where(i => i != null).Select(i => new { i.QualifiedItemId, i.Stack }).ToArray() }).ToArray()
                    });
                break;
            case "qa-full-chest":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.getFarm() is { } fullChestFarm)
                {
                    var chest = fullChestFarm.objects.Values.OfType<StardewValley.Objects.Chest>().FirstOrDefault(c => c.modData.ContainsKey("LocalTools.StardewFarmAssistant/storage"));
                    if (chest != null)
                    {
                        var items = chest.GetItemsForPlayer(Game1.player.UniqueMultiplayerID);
                        foreach (Item item in items.Where(i => i != null)) item.Stack = item.maximumStackSize();
                        for (int index = 0; index < chest.GetActualCapacity(); index++)
                        {
                            while (items.Count <= index) items.Add(null);
                            if (items[index] == null) items[index] = ItemRegistry.Create("768", 999);
                        }
                        this.Log("qa_injected", new { fault = "assistant_chest_full", capacity = chest.GetActualCapacity(), occupied = items.Count(i => i != null) });
                    }
                }
                break;
            case "qa-scarecrow-materials":
                if (!this.continuousDemo && Context.IsWorldReady)
                {
                    foreach (var material in new[] { (Id: "388", Count: 50), (Id: "382", Count: 1), (Id: "771", Count: 20) })
                    {
                        int missing = Math.Max(0, material.Count - Game1.player.Items.CountId(material.Id));
                        if (missing > 0 && Game1.player.couldInventoryAcceptThisItem(ItemRegistry.Create(material.Id, missing)))
                            Game1.player.addItemToInventoryBool(ItemRegistry.Create(material.Id, missing));
                    }
                    this.Log("qa_injected", new { fault = "scarecrow_material_fixture", learned = Game1.player.craftingRecipes.ContainsKey("Scarecrow"), wood = Game1.player.Items.CountId("388"), coal = Game1.player.Items.CountId("382"), fiber = Game1.player.Items.CountId("771") });
                }
                break;
            case "qa-storage-no-wood":
                if (!this.continuousDemo && Context.IsWorldReady)
                {
                    string[] ids = { "390", "771", "382", "330", "92", "770" };
                    int fixtureIndex = 0;
                    while (Game1.player.Items.Count < Game1.player.MaxItems) Game1.player.Items.Add(null);
                    for (int slot = 0; slot < Game1.player.MaxItems && fixtureIndex < ids.Length; slot++)
                        if (Game1.player.Items[slot] == null) Game1.player.Items[slot] = ItemRegistry.Create(ids[fixtureIndex++], 99);
                    foreach (var box in Game1.getFarm().objects.Values.OfType<StardewValley.Objects.Chest>().Where(c => c.modData.ContainsKey("LocalTools.StardewFarmAssistant/storage")))
                    {
                        var items = box.GetItemsForPlayer(Game1.player.UniqueMultiplayerID);
                        foreach (Item item in items.Where(item => item != null)) item.Stack = item.maximumStackSize();
                        for (int slot = 0; slot < box.GetActualCapacity(); slot++)
                        { while (items.Count <= slot) items.Add(null); if (items[slot] == null) items[slot] = ItemRegistry.Create("768", 999); }
                    }
                    this.Log("qa_injected", new { fault = "all_assistant_chests_full_no_added_backpack_wood", addedResourceStacks = fixtureIndex, woodInBackpack = Game1.player.Items.CountId("388"), freeSlots = Game1.player.freeSpotsInInventory() });
                }
                break;
            case "qa-low-energy":
                if (!this.continuousDemo && Context.IsWorldReady)
                { Game1.player.Stamina = this.owner.Config.ReserveEnergy; this.Log("qa_injected", new { fault = "energy_at_reserve", stamina = Game1.player.Stamina }); }
                break;
            case "qa-clock":
                if (!this.continuousDemo && Context.IsWorldReady && parts.Length == 2
                    && int.TryParse(parts[1], out int fixtureTime) && fixtureTime >= 600 && fixtureTime <= 2400
                    && fixtureTime % 100 <= 50 && fixtureTime % 10 == 0)
                {
                    this.AssertIsolation("qa_clock");
                    Game1.timeOfDay = fixtureTime;
                    this.Log("qa_injected", new { fault = "configured_clock_for_boundary", time = fixtureTime });
                }
                break;
            case "qa-outside":
                if (!this.continuousDemo && Context.IsWorldReady)
                { Game1.warpFarmer("Town", 30, 57, false); this.Log("qa_injected", new { fault = "outside_farm" }); }
                break;
            case "qa-return-farm":
                if (!this.continuousDemo && Context.IsWorldReady)
                { var entry = Game1.getFarm().GetMainFarmHouseEntry(); Game1.warpFarmer("Farm", entry.X, entry.Y, false); this.Log("qa_restored", new { fault = "outside_farm" }); }
                break;
            case "qa-dead-crop":
                if (!this.continuousDemo && Context.IsWorldReady && Game1.getFarm() is { } deadFarm)
                {
                    var dirt = this.owner.Engine.Plots.Select(tile => (Tile: tile, Dirt: deadFarm.terrainFeatures.TryGetValue(tile, out var feature) ? feature as StardewValley.TerrainFeatures.HoeDirt : null))
                        .FirstOrDefault(pair => pair.Dirt?.crop != null && !pair.Dirt.crop.dead.Value);
                    if (dirt.Dirt?.crop != null)
                    { dirt.Dirt.crop.dead.Value = true; this.owner.Engine.InvalidateLayout(); this.Log("qa_injected", new { fault = "dead_managed_crop", x = dirt.Tile.X, y = dirt.Tile.Y }); }
                }
                break;
            case "qa-extra-potatoes":
                if (!this.continuousDemo
                    && Context.IsWorldReady
                    && Game1.currentLocation is StardewValley.Farm farm)
                {
                    this.AssertIsolation("qa_extra_potatoes");
            
                    var candidates = this.owner.Engine.Plots
                        .Where(tile => farm.terrainFeatures.TryGetValue(tile, out var feature)
                            && feature is StardewValley.TerrainFeatures.HoeDirt { crop: null })
                        .Distinct()
                        .Take(24)
                        .ToList();
                    var injectedTiles = new List<Microsoft.Xna.Framework.Point>();
            
                    foreach (var tile in candidates)
                    {
                        // Recheck immediately before mutation so an existing crop can never
                        // be replaced if the tile changed after candidate enumeration.
                        if (!farm.terrainFeatures.TryGetValue(tile, out var feature)
                            || feature is not StardewValley.TerrainFeatures.HoeDirt dirt
                            || dirt.crop != null)
                            continue;
            
                        var crop = new StardewValley.Crop("475", (int)tile.X, (int)tile.Y, farm);
                        crop.currentPhase.Value = Math.Max(0, crop.phaseDays.Count - 1);
                        crop.dayOfCurrentPhase.Value = 0;
                        crop.fullyGrown.Value = false;
                        crop.dead.Value = false;
                        dirt.crop = crop;
            
                        // HoeDirt.readyForHarvest is the same predicate used by FarmEngine.
                        // Fail closed and restore the empty plot if game data did not create
                        // a normal mature potato crop.
                        if (!dirt.readyForHarvest() || crop.indexOfHarvest.Value != "192")
                        {
                            dirt.crop = null;
                            continue;
                        }
            
                        injectedTiles.Add(tile.ToPoint());
                    }
            
                    this.Log("qa_injected", new
                    {
                        fault = "mature_potatoes_for_native_extra_harvest",
                        seedId = "475",
                        harvestItemId = "192",
                        requested = 24,
                        quantity = injectedTiles.Count,
                        tiles = injectedTiles.Select(tile => new { x = tile.X, y = tile.Y }).ToArray()
                    });
                }
                break;
            case "qa-unsafe-region":
                if (!this.continuousDemo && Context.IsWorldReady)
                { this.owner.Save.RegionX = this.owner.Save.RegionY = 1; this.owner.Save.RegionWidth = this.owner.Save.RegionHeight = 1; this.owner.Engine.InvalidateLayout(); this.Log("qa_injected", new { fault = "unsafe_managed_region" }); }
                break;
            case "qa-restore-region":
                if (!this.continuousDemo && Context.IsWorldReady)
                { this.owner.Save.RegionX = this.owner.Save.RegionY = -1; this.owner.Save.RegionWidth = this.owner.Save.RegionHeight = 12; this.owner.Engine.InvalidateLayout(); this.Log("qa_restored", new { fault = "unsafe_managed_region" }); }
                break;
            case "adaptive":
                if (parts.Length == 2 && bool.TryParse(parts[1], out bool adaptive))
                { this.owner.Config.AdaptiveSpeed = adaptive; this.owner.SaveConfig(); this.Log("adaptive_setting", new { adaptive, this.owner.Config.SpeedCeiling }); }
                break;
            case "reload": this.StartReload(); break;
            case "stop": if (Context.IsWorldReady && this.owner.Save.Enabled) this.owner.Toggle(); this.complete = true; break;
            case "quit":
                this.Log("quit_requested", new { command });
                Game1.game1.Exit();
                break;
            default: this.Log("unknown_command", new { command }); break;
        }
    }

    private void StartReload()
    {
        if (!Context.IsWorldReady || this.reloadStage != ReloadStage.None)
        {
            this.Log("reload_rejected", new { worldReady = Context.IsWorldReady, stage = this.reloadStage.ToString() });
            return;
        }

        this.AssertIsolation("reload_command");
        string savesRoot = Path.GetFullPath(Path.Combine(this.profileRoot, "Saves"));
        string? currentSave = Constants.CurrentSavePath;
        if (string.IsNullOrWhiteSpace(currentSave) || !IsUnder(currentSave, savesRoot))
            throw new InvalidOperationException($"Refusing reload outside the isolated save root: '{currentSave ?? "<null>"}'.");

        string slotName = Path.GetFileName(Path.GetFullPath(currentSave).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        if (string.IsNullOrWhiteSpace(slotName) || !Directory.Exists(currentSave))
            throw new InvalidOperationException($"The isolated save slot is unavailable for reload: '{currentSave}'.");

        this.reloadSlotName = slotName;
        this.reloadStartedTick = this.tick;
        this.reloadStage = ReloadStage.ReturningToTitle;
        this.complete = false;
        this.LogReloadSnapshot("reload_started", currentSave);
        Game1.ExitToTitle(() =>
        {
            try
            {
                this.AssertIsolation("reload_title");
                if (Game1.activeClickableMenu is not TitleMenu title)
                    throw new InvalidOperationException($"Expected TitleMenu after ExitToTitle, got '{Game1.activeClickableMenu?.GetType().FullName ?? "<null>"}'.");
                title.skipToTitleButtons();
                // The save root is already isolated. Scan every isolated slot, then
                // match the exact folder name before invoking the original slot loader.
                TitleMenu.subMenu = new LoadGameMenu("");
                this.reloadStage = ReloadStage.WaitingForSlots;
                this.Log("reload_title_ready", new { slotName = this.reloadSlotName });
            }
            catch (Exception ex)
            {
                this.FailReload("title_callback", ex);
            }
        });
    }

    private void DriveReload()
    {
        if (this.tick - this.reloadStartedTick > 3600)
        {
            this.FailReload("timeout", new TimeoutException($"Reload remained in stage {this.reloadStage} for over 3600 ticks."));
            return;
        }

        if (this.reloadStage == ReloadStage.ReturningToTitle)
            return;

        if (this.reloadStage == ReloadStage.WaitingForSlots)
        {
            if (TitleMenu.subMenu is not LoadGameMenu loadMenu || loadMenu.IsDoingTask())
                return;
            LoadGameMenu.SaveFileSlot? slot = loadMenu.MenuSlots
                .OfType<LoadGameMenu.SaveFileSlot>()
                .FirstOrDefault(candidate => string.Equals(candidate.Farmer.slotName, this.reloadSlotName, StringComparison.OrdinalIgnoreCase));
            if (slot is null)
            {
                this.FailReload("slot_not_found", new InvalidOperationException($"The isolated slot '{this.reloadSlotName}' was not returned by LoadGameMenu."));
                return;
            }
            this.reloadStage = ReloadStage.WaitingForWorld;
            slot.Activate();
            return;
        }

        if (this.reloadStage != ReloadStage.WaitingForWorld || !Context.IsWorldReady)
            return;

        this.AssertIsolation("reload_verified");
        this.LogReloadSnapshot("reload_verified", Constants.CurrentSavePath);
        this.ApplyProcessOptions();
        this.owner.RequestScreenshot(Path.Combine(this.profileRoot, "evidence", "reload.png"));
        this.reloadStage = ReloadStage.None;
        this.reloadSlotName = null;
    }

    private void LogReloadSnapshot(string kind, string? currentSave)
    {
        this.Log(kind, new
        {
            money = Context.IsWorldReady ? Game1.player.Money : 0,
            day = Context.IsWorldReady ? Game1.dayOfMonth : 0,
            region = new { this.owner.Save.RegionX, this.owner.Save.RegionY, this.owner.Save.RegionWidth, this.owner.Save.RegionHeight },
            Harvested = new Dictionary<string, int>(this.owner.Save.Harvested),
            Enabled = this.owner.Save.Enabled,
            currentSave,
            slotName = this.reloadSlotName
        });
    }

    private void FailReload(string reason, Exception error)
    {
        this.Log("reload_failed", new { reason, stage = this.reloadStage.ToString(), error = error.ToString(), slotName = this.reloadSlotName });
        this.reloadStage = ReloadStage.None;
        this.reloadSlotName = null;
    }

    private void LogTelemetry()
    {
        var player = Game1.player;
        var controller = player?.controller;
        this.Log("telemetry", new
        {
            tick = this.tick,
            worldReady = Context.IsWorldReady,
            gameMode = Game1.gameMode,
            menu = Game1.activeClickableMenu?.GetType().FullName,
            titleSubMenu = TitleMenu.subMenu?.GetType().FullName,
            location = player?.currentLocation?.NameOrUniqueName ?? Game1.currentLocation?.NameOrUniqueName,
            tile = player is null ? null : new { player.TilePoint.X, player.TilePoint.Y },
            canMove = player?.CanMove,
            usingTool = player?.UsingTool,
            controller = controller?.GetType().FullName,
            controllerPathCount = controller?.pathToEndPoint?.Count,
            stamina = player?.Stamina,
            money = player?.Money,
            status = this.owner.Status,
            accumulated = new { this.planted, this.watered, this.harvested, this.shipped, this.sleeps }
        });
    }
}
