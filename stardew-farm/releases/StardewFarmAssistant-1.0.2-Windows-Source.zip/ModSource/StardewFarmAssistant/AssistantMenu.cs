using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using StardewValley;
using StardewValley.Menus;

namespace StardewFarmAssistant;

public sealed class AssistantMenu : IClickableMenu
{
    private const int PreferredWidth = 780;
    private const int PreferredHeight = 660;
    private readonly ModConfig config;
    private readonly FarmStatus status;
    private readonly Action saveConfig;
    private readonly Action toggle;
    private readonly Action resetRegion;
    private readonly Action markRegion;
    private readonly List<MenuButton> buttons = new();
    private int page;
    private int lastViewportWidth;
    private int lastViewportHeight;
    private int settingButtonHeight = 36;
    private bool isChinese;

    public AssistantMenu(
        ModConfig config,
        FarmStatus status,
        Action saveConfig,
        Action toggle,
        Action resetRegion,
        Action markRegion)
        : base(0, 0, PreferredWidth, PreferredHeight, true)
    {
        this.config = config;
        this.status = status;
        this.saveConfig = saveConfig;
        this.toggle = toggle;
        this.resetRegion = resetRegion;
        this.markRegion = markRegion;
        this.config.Normalize();
        this.RebuildLayout();
    }

    public override void receiveLeftClick(int x, int y, bool playSound = true)
    {
        if (this.upperRightCloseButton?.containsPoint(x, y) == true)
        {
            this.exitThisMenu();
            return;
        }

        foreach (MenuButton button in this.buttons)
        {
            if (!button.Bounds.Contains(x, y))
                continue;

            Game1.playSound("smallSelect");
            button.Click();
            this.config.Normalize();
            this.RebuildLayout();
            return;
        }
    }
    public override void receiveScrollWheelAction(int direction)
    {
        var button = this.buttons.FirstOrDefault(b => b.Bounds.Contains(Game1.getMouseX(), Game1.getMouseY()));
        if (button == null || direction == 0) return;
        int delta = direction > 0 ? 1 : -1;
        if (button.Text().StartsWith(this.T("工作速度", "Work speed"), StringComparison.Ordinal))
        {
            this.config.WorkSpeed = Math.Clamp(this.config.WorkSpeed + delta, 1, 200);
            this.config.AdaptiveSpeed = false; this.config.SpeedCeiling = Math.Max(this.config.SpeedCeiling, this.config.WorkSpeed);
        }
        else if (button.Text().StartsWith(this.T("自适应上限", "Adaptive ceiling"), StringComparison.Ordinal))
            this.config.SpeedCeiling = Math.Clamp(this.config.SpeedCeiling + delta, 1, 200);
        else return;
        this.PersistConfig(); this.RebuildLayout();
    }

    public override void receiveKeyPress(Keys key)
    {
        if (key == Keys.Escape)
        {
            this.exitThisMenu();
            return;
        }

        base.receiveKeyPress(key);
    }

    public override void performHoverAction(int x, int y)
    {
        foreach (MenuButton button in this.buttons)
            button.Hovered = button.Bounds.Contains(x, y);
    }

    public override void draw(SpriteBatch b)
    {
        if (this.lastViewportWidth != Game1.uiViewport.Width || this.lastViewportHeight != Game1.uiViewport.Height)
            this.RebuildLayout();

        this.drawBackground(b);
        IClickableMenu.drawTextureBox(b, this.xPositionOnScreen, this.yPositionOnScreen, this.width, this.height, Color.White);

        int left = this.xPositionOnScreen + 32;
        int top = this.yPositionOnScreen + 24;
        string title = this.T("农场助手", "Farm Assistant");
        b.DrawString(Game1.dialogueFont, title, new Vector2(left, top), Game1.textColor);

        this.DrawTabs(b);
        if (this.page == 0)
            this.DrawSettingsPage(b);
        else if (this.page == 1)
            this.DrawPerformancePage(b);
        else
            this.DrawExtensionsPage(b);

        this.upperRightCloseButton?.draw(b);
        this.drawMouse(b);
    }

    private void RebuildLayout()
    {
        this.lastViewportWidth = Game1.uiViewport.Width;
        this.lastViewportHeight = Game1.uiViewport.Height;
        this.isChinese = LocalizedContentManager.CurrentLanguageCode == LocalizedContentManager.LanguageCode.zh;
        this.width = Math.Min(PreferredWidth, Math.Max(560, this.lastViewportWidth - 32));
        this.height = Math.Min(PreferredHeight, Math.Max(0, this.lastViewportHeight - 24));
        this.xPositionOnScreen = (this.lastViewportWidth - this.width) / 2;
        this.yPositionOnScreen = (this.lastViewportHeight - this.height) / 2;
        this.initializeUpperRightCloseButton();
        this.buttons.Clear();

        int tabY = this.yPositionOnScreen + 76;
        int tabGap = 8;
        int tabWidth = (this.width - 64 - tabGap * 2) / 3;
        int tabLeft = this.xPositionOnScreen + 32;
        this.AddButton(new Rectangle(tabLeft, tabY, tabWidth, 38),
            () => this.page = 0, () => this.T("设置", "Settings"), this.page == 0);
        this.AddButton(new Rectangle(tabLeft + tabWidth + tabGap, tabY, tabWidth, 38),
            () => this.page = 1, () => this.T("性能与开荒", "Performance"), this.page == 1);
        this.AddButton(new Rectangle(tabLeft + (tabWidth + tabGap) * 2, tabY, tabWidth, 38),
            () => this.page = 2, () => this.T("扩展", "Extensions"), this.page == 2);

        if (this.page == 0)
            this.BuildSettingsButtons();
        else if (this.page == 1)
            this.BuildPerformanceButtons();
    }

    private void BuildSettingsButtons()
    {
        int gap = 16;
        int contentLeft = this.xPositionOnScreen + 32;
        int columnWidth = (this.width - 64 - gap) / 2;
        int modeY = this.yPositionOnScreen + 254;
        int firstY = this.yPositionOnScreen + 300;
        int startY = this.yPositionOnScreen + this.height - 58;
        int rowHeight = Math.Min(44, Math.Max(24, (startY - firstY - 4) / 8));
        this.settingButtonHeight = Math.Min(36, Math.Max(20, rowHeight - 6));

        this.AddButton(new Rectangle(contentLeft, modeY, this.width - 64, 40),
            this.CycleMode, () => this.T("工作模式", "Work mode") + ":  " + this.ModeName(),
            isPrimary: true);

        this.AddValueButton(contentLeft, firstY, columnWidth, this.T("工作速度", "Work speed"),
            () => this.T($"{this.config.WorkSpeed}档", $"Target {this.config.WorkSpeed}"), this.CycleWorkSpeed);
        this.AddValueButton(contentLeft + columnWidth + gap, firstY, columnWidth, this.T("管理地块", "Managed plots"),
            () => this.config.MaxPlots.ToString(), () => this.Cycle(new[] { 12, 24, 36, 60, 90, 120 }, this.config.MaxPlots, value => this.config.MaxPlots = value));

        this.AddValueButton(contentLeft, firstY + rowHeight, columnWidth, this.T("收益策略", "Profit strategy"),
            () => this.config.ProfitMode == "seasonProfit" ? this.T("本季利润", "Season profit") : this.T("均衡", "Balanced"),
            () => this.ChangeConfig(() => this.config.ProfitMode = this.config.ProfitMode == "seasonProfit" ? "balanced" : "seasonProfit"));
        this.AddValueButton(contentLeft + columnWidth + gap, firstY + rowHeight, columnWidth, this.T("保留金币", "Reserve gold"),
            () => this.config.ReserveGold.ToString(), () => this.Cycle(new[] { 0, 100, 500, 1000 }, this.config.ReserveGold, value => this.config.ReserveGold = value));

        this.AddValueButton(contentLeft, firstY + rowHeight * 2, columnWidth, this.T("每种作物保留", "Keep each crop"),
            () => this.config.KeepEachCrop.ToString(), () => this.Cycle(new[] { 0, 3, 5, 10 }, this.config.KeepEachCrop, value => this.config.KeepEachCrop = value));
        this.AddToggleButton(contentLeft + columnWidth + gap, firstY + rowHeight * 2, columnWidth, this.T("自动买种", "Buy seeds"), () => this.config.AutoBuySeeds, value => this.config.AutoBuySeeds = value);

        this.AddToggleButton(contentLeft, firstY + rowHeight * 3, columnWidth, this.T("自动出货", "Auto ship"), () => this.config.AutoShip, value => this.config.AutoShip = value);
        this.AddToggleButton(contentLeft + columnWidth + gap, firstY + rowHeight * 3, columnWidth, this.T("自动睡觉", "Auto sleep"), () => this.config.AutoSleep, value => this.config.AutoSleep = value);

        this.AddToggleButton(contentLeft, firstY + rowHeight * 4, columnWidth, this.T("完成后睡觉", "Sleep when finished"), () => this.config.SleepWhenFinished, value => this.config.SleepWhenFinished = value);
        this.AddToggleButton(contentLeft + columnWidth + gap, firstY + rowHeight * 4, columnWidth, this.T("清理杂物", "Clear debris"), () => this.config.ClearDebris, value => this.config.ClearDebris = value);

        this.AddToggleButton(contentLeft, firstY + rowHeight * 5, columnWidth, this.T("提前整理空地", "Prepare ahead"), () => this.config.PrepareAhead, value => this.config.PrepareAhead = value);
        this.AddToggleButton(contentLeft + columnWidth + gap, firstY + rowHeight * 5, columnWidth, this.T("自动整理背包", "Auto storage"), () => this.config.AutoStorage, value => this.config.AutoStorage = value);

        this.AddValueButton(contentLeft, firstY + rowHeight * 6, columnWidth, this.T("保留体力", "Reserve energy"),
            () => this.config.ReserveEnergy.ToString(), () => this.Cycle(new[] { 15, 25, 50, 100 }, this.config.ReserveEnergy, value => this.config.ReserveEnergy = value));
        this.AddValueButton(contentLeft + columnWidth + gap, firstY + rowHeight * 6, columnWidth, this.T("睡觉时间", "Bedtime"),
            () => $"{this.config.SleepTime / 100:00}:{this.config.SleepTime % 100:00}", () => this.Cycle(new[] { 1800, 2000, 2200, 2300, 2400 }, this.config.SleepTime, value => this.config.SleepTime = value));

        int regionHalf = (this.width - 64 - 8) / 2;
        this.AddButton(new Rectangle(contentLeft, firstY + rowHeight * 7 + 3, regionHalf, this.settingButtonHeight),
            this.RunResetRegion, () => this.T("自动范围", "Auto region"));
        this.AddButton(new Rectangle(contentLeft + regionHalf + 8, firstY + rowHeight * 7 + 3, regionHalf, this.settingButtonHeight),
            this.RunMarkRegion, () => this.T("标记范围", "Mark region"));

        this.AddButton(new Rectangle(contentLeft, startY, this.width - 64, 42), this.toggle,
            () => this.status.Enabled ? this.T("暂停助手", "Pause assistant") : this.T("启动助手", "Start assistant"),
            this.status.Enabled, isPrimary: true);
    }

    private void BuildPerformanceButtons()
    {
        int gap = 16;
        int left = this.xPositionOnScreen + 32;
        int columnWidth = (this.width - 64 - gap) / 2;
        int firstY = this.yPositionOnScreen + 342;
        const int rowHeight = 54;
        const int buttonHeight = 42;

        this.AddButton(new Rectangle(left, firstY, columnWidth, buttonHeight),
            () => this.ChangePerformanceConfig(() => this.config.AdaptiveSpeed = !this.config.AdaptiveSpeed),
            () => this.T("自适应速度", "Adaptive speed") + ":  " + (this.config.AdaptiveSpeed ? this.T("开", "On") : this.T("关", "Off")),
            this.config.AdaptiveSpeed);
        this.AddButton(new Rectangle(left + columnWidth + gap, firstY, columnWidth, buttonHeight),
            () => this.ChangePerformanceConfig(() => this.config.SpeedCeiling = this.config.SpeedCeiling >= 200 ? 5 : Math.Min(200, this.config.SpeedCeiling + 5)),
            () => this.T("自适应上限", "Adaptive ceiling") + $":  {this.config.SpeedCeiling}");

        this.AddButton(new Rectangle(left, firstY + rowHeight, columnWidth, buttonHeight),
            () => this.ChangeConfig(() => this.config.ClearTrees = !this.config.ClearTrees),
            () => this.T("清理普通树", "Clear common trees") + ":  " + (this.config.ClearTrees ? this.T("开", "On") : this.T("关", "Off")),
            this.config.ClearTrees);
        this.AddButton(new Rectangle(left + columnWidth + gap, firstY + rowHeight, columnWidth, buttonHeight),
            () => this.ChangeConfig(() => this.config.MaxTreesPerDay = this.Next(new[] { 1, 2, 4, 8, 12 }, this.config.MaxTreesPerDay)),
            () => this.T("每天最多清树", "Daily tree limit") + $":  {this.config.MaxTreesPerDay}");

        this.AddButton(new Rectangle(left, firstY + rowHeight * 2, this.width - 64, buttonHeight),
            this.DisableOverlay,
            () => this.config.ShowOverlay ? this.T("关闭辅助线", "Hide farm overlay") : this.T("辅助线已关闭", "Farm overlay is off"),
            !this.config.ShowOverlay);
        this.AddButton(new Rectangle(left, firstY + rowHeight * 3, this.width - 64, buttonHeight),
            () => this.ChangeConfig(() => this.config.AutoScarecrow = !this.config.AutoScarecrow),
            () => this.T("自动稻草人", "Auto scarecrow") + ":  " + (this.config.AutoScarecrow ? this.T("开", "On") : this.T("关", "Off")),
            this.config.AutoScarecrow);
        this.AddButton(new Rectangle(left, firstY + rowHeight * 4, this.width - 64, buttonHeight),
            () => this.ChangeConfig(() => this.config.SleepOnLowEnergy = !this.config.SleepOnLowEnergy),
            () => this.T("低体力立即睡觉", "Sleep on low energy") + ":  " + (this.config.SleepOnLowEnergy ? this.T("开", "On") : this.T("关", "Off")),
            this.config.SleepOnLowEnergy);
    }

    private void DrawTabs(SpriteBatch b)
    {
        foreach (MenuButton button in this.buttons.Where(p => p.Bounds.Y == this.yPositionOnScreen + 76))
            this.DrawButton(b, button);
    }

    private void DrawSettingsPage(SpriteBatch b)
    {
        int left = this.xPositionOnScreen + 32;
        int statusY = this.yPositionOnScreen + 126;
        int statusHeight = 120;
        IClickableMenu.drawTextureBox(b, Game1.mouseCursors, new Rectangle(384, 373, 18, 18), left, statusY, this.width - 64, statusHeight, Color.White, 4f, false);

        Color stateColor = this.status.Enabled ? new Color(55, 125, 62) : new Color(135, 76, 62);
        string state = this.status.Enabled ? this.T("运行中", "Running") : this.T("已暂停", "Paused");
        b.DrawString(Game1.smallFont, state, new Vector2(left + 18, statusY + 10), stateColor);
        this.DrawClippedText(b, StatusText.Translate(this.status.Activity), new Vector2(left + 124, statusY + 10), this.width - 220, Game1.textColor);

        string crop = this.T("作物", "Crop") + ": " + StatusText.Translate(this.status.CropChoice);
        string plots = this.T("地块", "Plots") + $": {this.status.ManagedPlots}/{this.config.MaxPlots}";
        this.DrawClippedText(b, crop, new Vector2(left + 18, statusY + 36), (this.width - 64) / 2 - 26, Game1.textColor);
        b.DrawString(Game1.smallFont, plots, new Vector2(left + (this.width - 64) / 2, statusY + 36), Game1.textColor);

        string counts = this.isChinese
            ? $"今日：播种{this.status.Planted} 浇水{this.status.Watered} 收获{this.status.Harvested} 清杂{this.status.Cleared} 出货{this.status.Shipped}"
            : $"Today: Plant {this.status.Planted} Water {this.status.Watered} Harvest {this.status.Harvested} Clear {this.status.Cleared} Ship {this.status.Shipped}";
        this.DrawClippedText(b, counts, new Vector2(left + 18, statusY + 62), this.width - 100, new Color(92, 67, 44));
        string reason = StatusText.CompactTaskReason(this.status.Reason);
        this.DrawClippedText(b, reason, new Vector2(left + 18, statusY + 88), this.width - 100, new Color(126, 79, 45));

        foreach (MenuButton button in this.buttons.Where(p => p.Bounds.Y > statusY + statusHeight))
            this.DrawButton(b, button);
    }

    private void DrawPerformancePage(SpriteBatch b)
    {
        int left = this.xPositionOnScreen + 32;
        int top = this.yPositionOnScreen + 136;
        int cardWidth = this.width - 64;
        const int cardHeight = 184;
        IClickableMenu.drawTextureBox(b, Game1.mouseCursors, new Rectangle(384, 373, 18, 18),
            left, top, cardWidth, cardHeight, Color.White, 4f, false);

        b.DrawString(Game1.dialogueFont, this.T("实际性能", "Measured performance"), new Vector2(left + 20, top + 14), Game1.textColor);
        string speed = this.config.AdaptiveSpeed
            ? this.T($"工作目标档 {this.status.EffectiveSpeed} · 自适应上限 {this.config.SpeedCeiling}", $"Work target {this.status.EffectiveSpeed} · adaptive ceiling {this.config.SpeedCeiling}")
            : this.T($"工作目标档 {this.status.EffectiveSpeed} · 手动目标 {this.config.WorkSpeed}", $"Work target {this.status.EffectiveSpeed} · manual target {this.config.WorkSpeed}");
        this.DrawClippedText(b, speed, new Vector2(left + 22, top + 58), cardWidth - 44, new Color(55, 125, 62));

        string budget = this.T(
            $"帧 P95 {this.status.FrameP95Ms:0.0} ms · 助手 P95 {this.status.AssistantP95Ms:0.0} ms",
            $"Frame p95 {this.status.FrameP95Ms:0.0} ms · assistant p95 {this.status.AssistantP95Ms:0.0} ms");
        this.DrawClippedText(b, budget, new Vector2(left + 22, top + 84), cardWidth - 44, Game1.textColor);

        string reason = this.T("预算理由：", "Budget reason: ") + StatusText.TranslateSpeedReason(this.status.SpeedReason);
        this.DrawClippedText(b, reason, new Vector2(left + 22, top + 110), cardWidth - 44, new Color(92, 67, 44));

        string clearing = this.T(
            $"今日树 {this.status.TreesCleared}/{this.config.MaxTreesPerDay} · 草 {this.status.GrassCleared} · 作业 {this.status.ActionsPerSecond:0.0}次/秒",
            $"Trees {this.status.TreesCleared}/{this.config.MaxTreesPerDay} · grass {this.status.GrassCleared} · {this.status.ActionsPerSecond:0.0} actions/s");
        this.DrawClippedText(b, clearing, new Vector2(left + 22, top + 136), cardWidth - 44, new Color(92, 67, 44));

        foreach (MenuButton button in this.buttons.Where(p => p.Bounds.Y > top + cardHeight))
            this.DrawButton(b, button);
    }

    private void DrawExtensionsPage(SpriteBatch b)
    {
        int left = this.xPositionOnScreen + 32;
        int top = this.yPositionOnScreen + 136;
        int cardWidth = this.width - 64;
        IClickableMenu.drawTextureBox(b, Game1.mouseCursors, new Rectangle(384, 373, 18, 18), left, top, cardWidth, 150, Color.White, 4f, false);
        b.DrawString(Game1.dialogueFont, this.T("后续扩展", "Planned extensions"), new Vector2(left + 22, top + 18), Game1.textColor);
        b.DrawString(Game1.smallFont,
            this.T("钓鱼、矿洞和剧情：已规划，尚未启用", "Fishing, mines, and story: planned, not active"),
            new Vector2(left + 24, top + 74), new Color(126, 79, 45));

        IClickableMenu.drawTextureBox(b, Game1.mouseCursors, new Rectangle(384, 373, 18, 18), left, top + 170, cardWidth, 150, Color.White, 4f, false);
        b.DrawString(Game1.smallFont, this.T("当前版本专注农场循环", "This version focuses on the farm loop"), new Vector2(left + 24, top + 194), Game1.textColor);
        string details = this.T(
            "清理、锄地、选种、播种、浇水、收割、补种、出货和休息。",
            "Clear, till, choose crops, plant, water, harvest, replant, ship, and sleep.");
        b.DrawString(Game1.smallFont, details, new Vector2(left + 24, top + 238), new Color(92, 67, 44));

        foreach (MenuButton button in this.buttons.Where(p => p.Bounds.Y == this.yPositionOnScreen + 76))
            this.DrawButton(b, button);
    }

    private void AddValueButton(int x, int y, int width, string label, Func<string> value, Action click)
    {
        this.AddButton(new Rectangle(x, y + 3, width, this.settingButtonHeight), click, () => label + ":  " + value());
    }

    private void AddToggleButton(int x, int y, int width, string label, Func<bool> get, Action<bool> set)
    {
        this.AddButton(new Rectangle(x, y + 3, width, this.settingButtonHeight),
            () => this.ChangeConfig(() => set(!get())),
            () => label + ":  " + (get() ? this.T("开", "On") : this.T("关", "Off")),
            get());
    }

    private void AddButton(Rectangle bounds, Action click, Func<string> text, bool selected = false, bool isPrimary = false)
    {
        this.buttons.Add(new MenuButton(bounds, click, text) { Selected = selected, IsPrimary = isPrimary });
    }

    private void DrawButton(SpriteBatch b, MenuButton button)
    {
        Color tint = button.IsPrimary
            ? (button.Selected ? new Color(219, 170, 101) : new Color(236, 193, 111))
            : button.Selected ? new Color(228, 205, 157) : Color.White;
        if (button.Hovered)
            tint = Color.Lerp(tint, Color.White, 0.3f);

        IClickableMenu.drawTextureBox(b, Game1.mouseCursors, new Rectangle(384, 373, 18, 18),
            button.Bounds.X, button.Bounds.Y, button.Bounds.Width, button.Bounds.Height, tint, 4f, false);
        string text = this.Fit(button.Text(), button.Bounds.Width - 22);
        Vector2 size = Game1.smallFont.MeasureString(text);
        Vector2 pos = new(button.Bounds.Center.X - size.X / 2f, button.Bounds.Center.Y - size.Y / 2f);
        b.DrawString(Game1.smallFont, text, pos, Game1.textColor);
    }

    private void Cycle(int[] refValues, int current, Action<int> set)
    {
        int index = Array.IndexOf(refValues, current);
        this.config.WorkMode = "custom";
        set(refValues[(index + 1 + refValues.Length) % refValues.Length]);
        this.PersistConfig();
    }

    private void CycleWorkSpeed()
    {
        this.config.WorkMode = "custom";
        this.config.AdaptiveSpeed = false;
        this.config.WorkSpeed = this.config.WorkSpeed >= 200 ? 1 : Math.Min(200, this.config.WorkSpeed + (this.config.WorkSpeed < 10 ? 1 : 5));
        this.config.SpeedCeiling = Math.Max(this.config.SpeedCeiling, this.config.WorkSpeed);
        this.PersistConfig();
    }

    private int Next(int[] values, int current)
    {
        int index = Array.IndexOf(values, current);
        return values[(index + 1 + values.Length) % values.Length];
    }

    private void ChangeConfig(Action change)
    {
        this.config.WorkMode = "custom";
        change();
        this.PersistConfig();
    }

    private void ChangePerformanceConfig(Action change)
    {
        change();
        this.PersistConfig();
    }

    private void DisableOverlay()
    {
        this.config.ShowOverlay = false;
        this.PersistConfig();
    }

    private void CycleMode()
    {
        string[] modes = { "development", "rush", "showcase", "custom" };
        int index = Array.IndexOf(modes, this.config.WorkMode);
        this.config.SetMode(modes[(index + 1 + modes.Length) % modes.Length]);
        this.saveConfig();
    }

    private string ModeName() => this.config.WorkMode switch
    {
        "development" => this.T("开荒经营", "Homestead"),
        "rush" => this.T("种田速进", "Farm rush"),
        "showcase" => this.T("观赏开荒", "Showcase"),
        _ => this.T("自定义", "Custom"),
    };

    private void PersistConfig()
    {
        this.config.Normalize();
        this.saveConfig();
    }

    private void RunResetRegion()
    {
        this.resetRegion();
        this.saveConfig();
    }

    private void RunMarkRegion()
    {
        this.markRegion();
        this.saveConfig();
    }

    private void DrawClippedText(SpriteBatch b, string? text, Vector2 position, float maxWidth, Color color)
    {
        b.DrawString(Game1.smallFont, this.Fit(string.IsNullOrWhiteSpace(text) ? "--" : text, maxWidth), position, color);
    }

    private string Fit(string text, float maxWidth)
    {
        if (Game1.smallFont.MeasureString(text).X <= maxWidth)
            return text;

        const string ellipsis = "…";
        while (text.Length > 1 && Game1.smallFont.MeasureString(text + ellipsis).X > maxWidth)
            text = text[..^1];
        return text + ellipsis;
    }

    private string T(string chinese, string english) => this.isChinese ? chinese : english;

    private sealed class MenuButton
    {
        public Rectangle Bounds { get; }
        public Action Click { get; }
        public Func<string> Text { get; }
        public bool Selected { get; set; }
        public bool IsPrimary { get; set; }
        public bool Hovered { get; set; }

        public MenuButton(Rectangle bounds, Action click, Func<string> text)
        {
            this.Bounds = bounds;
            this.Click = click;
            this.Text = text;
        }
    }
}
