using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using Microsoft.Win32;

namespace FarmAssistantManager
{
    public sealed class Detection
    {
        public string GamePath = "", Version = "", Status = "";
        public bool GameFound, SmapiFound, ModInstalled;
    }

    public sealed class ManagerBackend
    {
        public const string ModId = "LocalTools.StardewFarmAssistant";
        public const string ModVersion = "1.0.2";
        public const string SmapiVersion = "4.5.2";
        private const string SmapiZipName = "SMAPI-4.5.2-installer.zip";
        private const string SmapiUrl = "https://github.com/Pathoschild/SMAPI/releases/download/4.5.2/SMAPI-4.5.2-installer.zip";
        private const string SmapiHash = "dd01ddca7b566bfe0d3b3d2d03833496abc56c53da976241f2ab443f5484acc4";
        private static readonly string[] OwnedFiles = { "manifest.json", "config.json", "LICENSE.txt", "README.md", "使用说明.md", "CHANGELOG.md", "社区发布说明.md", "StardewFarmAssistant.dll" };
        private readonly string bundleRoot;
        private readonly string stateRoot;
        private readonly JavaScriptSerializer json = new JavaScriptSerializer { MaxJsonLength = 1024 * 1024 };

        public ManagerBackend(string bundleRoot) : this(bundleRoot, Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FarmAssistantManager")) { }

        // The explicit state root also permits tests without touching the user's own manager settings.
        public ManagerBackend(string bundleRoot, string stateRoot)
        {
            this.bundleRoot = Canonical(bundleRoot);
            this.stateRoot = Canonical(stateRoot);
        }

        public Detection Inspect(string path)
        {
            Detection d = new Detection();
            try
            {
                if (String.IsNullOrWhiteSpace(path)) { d.Status = "请选择星露谷物语的游戏文件夹。"; return d; }
                d.GamePath = Canonical(path);
                EnsureSafePath(d.GamePath);
                string mod = ModDirectory(d.GamePath);
                if (Directory.Exists(mod))
                {
                    EnsureSafePath(mod);
                    if (IsOurMod(mod))
                    {
                        Dictionary<string, object> manifest = ReadJson(Path.Combine(mod, "manifest.json"));
                        d.Version = Value(manifest, "Version");
                        string dll = Path.Combine(mod, "StardewFarmAssistant.dll");
                        d.ModInstalled = File.Exists(dll) && AssemblyVersion(dll).ToString(3) == d.Version;
                    }
                    else RequireOwnedOrEmpty(d.GamePath, mod);
                }
                RequireGame(d.GamePath);
                d.GameFound = true;
                Version gameVersion = AssemblyVersion(Path.Combine(d.GamePath, "Stardew Valley.dll"));
                d.SmapiFound = IsCompatibleSmapi(d.GamePath);
                d.Status = "游戏 " + gameVersion.ToString(3) + " · " + (d.SmapiFound ? "SMAPI 兼容" : "需要 SMAPI 4.5.2") + " · " + (d.ModInstalled ? "助手已安装" : "助手未安装或文件不完整");
            }
            catch (Exception ex) { d.Status = ex.Message; }
            return d;
        }

        public List<string> FindGamePaths()
        {
            HashSet<string> candidates = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            HashSet<string> steamRoots = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                string last = LoadProtected("last-game.bin");
                if (!String.IsNullOrWhiteSpace(last)) candidates.Add(last);
            }
            catch { /* A damaged optional preference never prevents manual selection. */ }
            AddSteam(steamRoots, Registry.CurrentUser, "Software\\Valve\\Steam", "SteamPath");
            AddSteam(steamRoots, Registry.LocalMachine, "SOFTWARE\\Valve\\Steam", "InstallPath");
            AddSteam(steamRoots, Registry.LocalMachine, "SOFTWARE\\WOW6432Node\\Valve\\Steam", "InstallPath");
            steamRoots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam"));
            steamRoots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Steam"));
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                if (drive.DriveType == DriveType.Fixed && drive.IsReady) steamRoots.Add(Path.Combine(drive.RootDirectory.FullName, "Steam"));
            }
            foreach (string steam in steamRoots.ToArray())
            {
                string vdf = Path.Combine(steam, "steamapps", "libraryfolders.vdf");
                try
                {
                    if (File.Exists(vdf) && new FileInfo(vdf).Length < 2 * 1024 * 1024)
                        foreach (Match match in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                            steamRoots.Add(match.Groups[1].Value.Replace("\\\\", "\\"));
                }
                catch { }
            }
            foreach (string steam in steamRoots)
            {
                string installDir = "Stardew Valley";
                try
                {
                    string acf = Path.Combine(steam, "steamapps", "appmanifest_413150.acf");
                    if (File.Exists(acf))
                    {
                        Match match = Regex.Match(File.ReadAllText(acf), "\"installdir\"\\s+\"([^\"]+)\"");
                        if (match.Success && Path.GetFileName(match.Groups[1].Value) == match.Groups[1].Value) installDir = match.Groups[1].Value;
                    }
                }
                catch { }
                candidates.Add(Path.Combine(steam, "steamapps", "common", installDir));
            }
            candidates.Add(bundleRoot);
            DirectoryInfo parent = Directory.GetParent(bundleRoot);
            if (parent != null) candidates.Add(parent.FullName);
            return candidates.Select(Inspect).Where(d => d.GameFound).Select(d => d.GamePath).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        public void Install(string gamePath, string preset, int speedCeiling, bool autoDependency, Action<string> progress, CancellationToken token)
        {
            string game = Canonical(gamePath);
            using (GameLock gameLock = new GameLock(game))
            {
                RequireGame(game);
                RequireNotRunning();
                if (speedCeiling < 1 || speedCeiling > 200) throw new InvalidOperationException("速度上限应在 1 到 200 之间。实际工作速度会随电脑负载调整。");
                if (preset != "development" && preset != "rush" && preset != "showcase") throw new InvalidOperationException("请选择养成、速通或演示模式。");
                string mod = ModDirectory(game);
                RequireOwnedOrEmpty(game, mod);
                progress("检查发行包、游戏版本和文件边界…");
                Dictionary<string, byte[]> payload = ValidatePayload();
                token.ThrowIfCancellationRequested();
                Dictionary<string, object> config = ReadConfiguration(game, mod, payload["config.json"]);
                ApplyPreset(config, preset, speedCeiling);
                byte[] configBytes = Encoding.UTF8.GetBytes(json.Serialize(config));
                Dictionary<string, byte[]> dependency = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
                bool bootstrap = !IsCompatibleSmapi(game);
                if (bootstrap)
                {
                    if (File.Exists(Path.Combine(game, "StardewModdingAPI.exe")) || File.Exists(Path.Combine(game, "StardewModdingAPI.dll")) || Directory.Exists(Path.Combine(game, "smapi-internal")))
                        throw new InvalidOperationException("检测到已有但不兼容或不完整的 SMAPI。请先用 SMAPI 官方安装器更新到 4.5.2 或更高版本，再点击安装配置。现有共享文件已保留。");
                    if (!autoDependency) throw new InvalidOperationException("此游戏尚未安装 SMAPI。勾选自动配置 SMAPI 后重试，或先从 smapi.io 安装 4.5.2 以上版本。");
                    string zip = AcquireSmapi(progress, token);
                    dependency = ReadSmapiPayload(zip, game);
                }
                // All data, including configuration, are ready before any game file is changed.
                Dictionary<string, byte[]> planned = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
                foreach (var file in dependency) planned.Add(SafeChild(game, file.Key), file.Value);
                foreach (string name in OwnedFiles) planned.Add(SafeChild(mod, name), name == "config.json" ? configBytes : payload[name]);
                foreach (string file in planned.Keys) PreflightWritable(file);
                RequireNotRunning();
                token.ThrowIfCancellationRequested();
                using (FileTransaction transaction = new FileTransaction())
                {
                    if (bootstrap) progress("按官方文件步骤配置 SMAPI（仅当前游戏目录）…");
                    foreach (var file in dependency)
                    {
                        token.ThrowIfCancellationRequested();
                        transaction.Write(SafeChild(game, file.Key), file.Value);
                    }
                    progress("安装农场助手并应用模式与自适应速度…");
                    foreach (string name in OwnedFiles.Where(n => n != "manifest.json"))
                    {
                        token.ThrowIfCancellationRequested();
                        transaction.Write(SafeChild(mod, name), planned[SafeChild(mod, name)]);
                    }
                    token.ThrowIfCancellationRequested();
                    transaction.Write(SafeChild(mod, "manifest.json"), payload["manifest.json"]);
                    Detection actual = Inspect(game);
                    if (!actual.SmapiFound || !actual.ModInstalled || actual.Version != ModVersion) throw new IOException("安装后的版本读回不匹配，已尝试恢复原文件。");
                    foreach (var file in planned) if (!File.ReadAllBytes(file.Key).SequenceEqual(file.Value)) throw new IOException("安装后的文件内容核验不匹配，已尝试恢复原文件。");
                    token.ThrowIfCancellationRequested();
                    transaction.Commit();
                }
                SavePreferences(game, configBytes, progress);
                progress("配置完成：助手 " + ModVersion + "。进入存档后按 F8 开启，F9 调整该存档的设置。");
            }
        }

        public void Uninstall(string gamePath, Action<string> progress)
        {
            string game = Canonical(gamePath);
            using (GameLock gameLock = new GameLock(game))
            {
                EnsureSafePath(game);
                if (!Directory.Exists(game)) throw new InvalidOperationException("游戏目录不存在，请选择原来安装农场助手的文件夹。");
                RequireNotRunning();
                string mod = ModDirectory(game);
                if (!Directory.Exists(mod)) { progress("农场助手未安装，无需卸载。"); return; }
                EnsureSafePath(mod);
                if (IsEmptyDirectory(mod)) { Directory.Delete(mod, false); progress("已移除空的助手目录。"); return; }
                if (!IsOurMod(mod)) throw new InvalidOperationException("无法确认同名目录属于农场助手，未删除任何文件。");
                List<string> targets = OwnedFiles.Select(n => SafeChild(mod, n)).Where(File.Exists).ToList();
                string runtime = SafeChild(mod, "data/runtime-state.json");
                if (File.Exists(runtime)) targets.Add(runtime);
                foreach (string path in targets) { EnsureSafePath(path); PreflightWritable(path); }
                string config = Path.Combine(mod, "config.json");
                if (File.Exists(config))
                {
                    string original = File.ReadAllText(config, Encoding.UTF8);
                    bool valid = true;
                    try { ReadJson(config); } catch (IOException) { valid = false; }
                    SaveProtected(ConfigName(game) + (valid ? "" : ".invalid.bin"), original);
                    if (!valid) progress("配置格式损坏：已加密保留原始文本，重新安装时不会自动套用这份损坏配置。");
                }
                // Proof of the exact directory previously owned by this manager; not an executable marker in the game.
                SaveProtected(OwnershipName(game), ModId);
                progress("卸载已识别的农场助手文件…");
                using (FileTransaction transaction = new FileTransaction())
                {
                    foreach (string path in targets.Where(p => Path.GetFileName(p) != "manifest.json")) transaction.Delete(path);
                    transaction.Delete(SafeChild(mod, "manifest.json"));
                    if (File.Exists(Path.Combine(mod, "StardewFarmAssistant.dll")) || File.Exists(Path.Combine(mod, "manifest.json"))) throw new IOException("卸载读回失败，已尝试恢复文件。");
                    transaction.Commit();
                }
                RemoveEmptyDirectory(SafeChild(mod, "data"));
                RemoveEmptyDirectory(mod);
                progress("已卸载农场助手。存档、其他模组、共享 SMAPI 均保留；设置保存在本机，重新安装时可恢复。" + (Directory.Exists(mod) ? "助手目录里的额外文件也已保留。" : ""));
            }
        }

        public void Launch(string gamePath)
        {
            string game = Canonical(gamePath);
            RequireGame(game);
            RequireNotRunning();
            Detection d = Inspect(game);
            if (!d.SmapiFound || !d.ModInstalled) throw new InvalidOperationException("请先完成安装配置，再启动游戏。");
            ProcessStartInfo info = new ProcessStartInfo(Path.Combine(game, "StardewModdingAPI.exe"));
            info.WorkingDirectory = game;
            info.UseShellExecute = false;
            info.Arguments = "";
            info.EnvironmentVariables["SteamAppId"] = "413150";
            Process process = Process.Start(info);
            if (process == null) throw new IOException("Windows 未能创建游戏进程。");
            process.Dispose();
        }

        private Dictionary<string, byte[]> ValidatePayload()
        {
            string folder = SafeChild(bundleRoot, "FarmAssistantMod");
            Dictionary<string, object> hashes;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload-hashes.json"))
            {
                if (stream == null) throw new InvalidOperationException("配置器缺少发行包校验信息，请重新解压完整玩家包。");
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8)) hashes = json.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
            }
            if (hashes.Count != OwnedFiles.Length || OwnedFiles.Any(n => !hashes.ContainsKey(n))) throw new InvalidOperationException("发行包校验清单无效。");
            Dictionary<string, byte[]> result = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
            foreach (string name in OwnedFiles)
            {
                string file = SafeChild(folder, name);
                EnsureSafePath(file);
                if (!File.Exists(file) || new FileInfo(file).Length > 16 * 1024 * 1024) throw new InvalidOperationException("玩家包文件缺失或异常：" + name + "。请重新解压完整包。");
                byte[] bytes = File.ReadAllBytes(file);
                if (Hash(bytes) != Convert.ToString(hashes[name])) throw new InvalidOperationException("玩家包校验失败：" + name + "。请重新解压原始发行包，勿修改安装载荷。");
                result.Add(name, bytes);
            }
            Dictionary<string, object> manifest = ParseJson(Encoding.UTF8.GetString(result["manifest.json"]));
            if (Value(manifest, "UniqueID") != ModId || Value(manifest, "Version") != ModVersion || AssemblyVersion(SafeChild(folder, "StardewFarmAssistant.dll")).ToString(3) != ModVersion)
                throw new InvalidOperationException("模组版本或身份与配置器不匹配。");
            return result;
        }

        private Dictionary<string, object> ReadConfiguration(string game, string mod, byte[] defaults)
        {
            Dictionary<string, object> values = ParseJson(Encoding.UTF8.GetString(defaults));
            string text = null;
            if (File.Exists(Path.Combine(mod, "config.json"))) text = File.ReadAllText(Path.Combine(mod, "config.json"), Encoding.UTF8);
            else text = LoadProtected(ConfigName(game));
            if (!String.IsNullOrWhiteSpace(text)) foreach (var field in ParseJson(text)) values[field.Key] = field.Value;
            return values;
        }

        private static void ApplyPreset(Dictionary<string, object> config, string mode, int ceiling)
        {
            config["WorkMode"] = mode;
            config["WorkSpeed"] = Math.Min(mode == "rush" ? 50 : mode == "showcase" ? 25 : 10, ceiling);
            config["SpeedCeiling"] = ceiling;
            config["AdaptiveSpeed"] = true;
            config["ReserveGold"] = mode == "rush" ? 0 : 100;
            config["KeepEachCrop"] = mode == "rush" ? 0 : 5;
            config["PrepareAhead"] = mode != "rush";
            config["ClearTrees"] = mode != "rush";
            config["MaxTreesPerDay"] = mode == "development" ? 12 : 4;
            config["ShowOverlay"] = false;
        }

        private string AcquireSmapi(Action<string> progress, CancellationToken token)
        {
            string local = SafeChild(bundleRoot, SmapiZipName);
            if (File.Exists(local)) { progress("校验旁边的 SMAPI 官方离线安装包…"); VerifySmapiZip(local); return local; }
            string cached = SafeChild(stateRoot, "Downloads/" + SmapiZipName);
            if (File.Exists(cached)) { progress("校验已下载的 SMAPI 安装包…"); VerifySmapiZip(cached); return cached; }
            EnsureDirectory(Path.GetDirectoryName(cached));
            string partial = cached + "." + Guid.NewGuid().ToString("N") + ".part";
            progress("从 SMAPI 官方 GitHub 下载 4.5.2（约 40 MB）…");
            try
            {
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                HttpWebRequest request = CreateOfficialRequest(new Uri(SmapiUrl));
                HttpWebResponse response = null;
                for (int redirects = 0; redirects < 6; redirects++)
                {
                    token.ThrowIfCancellationRequested();
                    using (token.Register(request.Abort)) response = (HttpWebResponse)request.GetResponse();
                    int status = (int)response.StatusCode;
                    if (status < 300 || status >= 400) break;
                    string location = response.Headers["Location"];
                    Uri next = new Uri(request.RequestUri, location);
                    response.Dispose(); response = null;
                    request = CreateOfficialRequest(next);
                }
                if (response == null) throw new IOException("官方地址重定向过多。");
                using (response)
                using (token.Register(request.Abort))
                using (Stream input = response.GetResponseStream())
                using (FileStream output = new FileStream(partial, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    if (response.StatusCode != HttpStatusCode.OK || response.ContentLength > 100 * 1024 * 1024) throw new IOException("官方安装包响应异常。");
                    byte[] buffer = new byte[64 * 1024];
                    long length = 0;
                    int read;
                    while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        token.ThrowIfCancellationRequested();
                        length += read;
                        if (length > 100 * 1024 * 1024) throw new IOException("下载大小异常，已停止。");
                        output.Write(buffer, 0, read);
                    }
                }
                VerifySmapiZip(partial);
                token.ThrowIfCancellationRequested();
                File.Move(partial, cached);
                return cached;
            }
            catch (WebException ex)
            {
                if (token.IsCancellationRequested) throw new OperationCanceledException(token);
                throw new IOException("无法下载 SMAPI。请检查网络，或将官方 " + SmapiZipName + " 放到配置器旁边后重试。游戏文件尚未修改。", ex);
            }
            finally { if (File.Exists(partial)) File.Delete(partial); }
        }

        private static HttpWebRequest CreateOfficialRequest(Uri uri)
        {
            if (uri.Scheme != "https" || (uri.Host != "github.com" && uri.Host != "release-assets.githubusercontent.com" && uri.Host != "objects.githubusercontent.com"))
                throw new IOException("官方安装包跳转到未允许的地址，下载已停止。");
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AllowAutoRedirect = false;
            request.Timeout = 20000;
            request.ReadWriteTimeout = 20000;
            request.UserAgent = "FarmAssistantManager/1.0";
            return request;
        }

        private static void VerifySmapiZip(string zip)
        {
            EnsureSafePath(zip);
            if (new FileInfo(zip).Length != 41889142 || HashFile(zip) != SmapiHash) throw new InvalidOperationException("SMAPI 安装包校验失败，请换回官方原始的 4.5.2 ZIP。未安装任何依赖。");
        }

        private Dictionary<string, byte[]> ReadSmapiPayload(string zip, string game)
        {
            Dictionary<string, byte[]> files = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
            using (ZipArchive outer = ZipFile.OpenRead(zip))
            {
                ZipArchiveEntry dat = outer.GetEntry("SMAPI 4.5.2 installer/internal/windows/install.dat");
                if (dat == null || dat.Length > 60 * 1024 * 1024) throw new IOException("官方 SMAPI 包缺少 Windows 文件载荷。");
                using (MemoryStream memory = new MemoryStream())
                {
                    using (Stream source = dat.Open()) source.CopyTo(memory);
                    memory.Position = 0;
                    using (ZipArchive inner = new ZipArchive(memory, ZipArchiveMode.Read))
                    {
                        long total = 0;
                        foreach (ZipArchiveEntry entry in inner.Entries)
                        {
                            if (entry.FullName.EndsWith("/", StringComparison.Ordinal)) continue;
                            string relative = entry.FullName.Replace('/', Path.DirectorySeparatorChar);
                            SafeChild(game, relative);
                            // The bundled optional mods are not needed by our core and belong to their own authors.
                            if (relative.StartsWith("Mods\\", StringComparison.OrdinalIgnoreCase)) continue;
                            if (relative != "steam_appid.txt" && !relative.StartsWith("StardewModdingAPI", StringComparison.Ordinal) && !relative.StartsWith("smapi-internal\\", StringComparison.Ordinal)) throw new IOException("SMAPI 文件载荷包含未识别的入口。");
                            if (entry.Length > 32 * 1024 * 1024 || (total += entry.Length) > 100 * 1024 * 1024) throw new IOException("SMAPI 文件载荷大小异常。");
                            string target = SafeChild(game, relative);
                            if (File.Exists(target))
                            {
                                if (relative == "steam_appid.txt") continue; // Preserve an existing Steam identity setting.
                                throw new IOException("SMAPI 待安装文件已有同名文件，请先用官方安装器修复现有 SMAPI。未覆盖：" + relative);
                            }
                            using (Stream input = entry.Open())
                            using (MemoryStream output = new MemoryStream()) { input.CopyTo(output); files.Add(relative, output.ToArray()); }
                        }
                    }
                }
            }
            foreach (string required in new[] { "StardewModdingAPI.exe", "StardewModdingAPI.dll", "StardewModdingAPI.runtimeconfig.json", "smapi-internal\\SMAPI.Toolkit.dll" })
                if (!files.ContainsKey(required)) throw new IOException("SMAPI 官方载荷文件不完整。");
            string deps = SafeChild(game, "StardewModdingAPI.deps.json");
            if (File.Exists(deps)) throw new IOException("已有 SMAPI 依赖文件，请先用官方安装器修复。未覆盖该文件。");
            files.Add("StardewModdingAPI.deps.json", File.ReadAllBytes(Path.Combine(game, "Stardew Valley.deps.json")));
            return files;
        }

        private void SavePreferences(string game, byte[] config, Action<string> progress)
        {
            try { SaveProtected(ConfigName(game), Encoding.UTF8.GetString(config)); SaveProtected("last-game.bin", game); }
            catch (Exception) { progress("安装已完成；可选的本机设置记忆写入失败，游戏内配置仍然有效。"); }
        }

        private void SaveProtected(string name, string text)
        {
            string path = SafeChild(stateRoot, "Settings/" + name);
            EnsureDirectory(Path.GetDirectoryName(path));
            EnsureSafePath(path);
            byte[] data = ProtectedData.Protect(Encoding.UTF8.GetBytes(text), Encoding.UTF8.GetBytes(ModId), DataProtectionScope.CurrentUser);
            using (FileTransaction tx = new FileTransaction()) { tx.Write(path, data); tx.Commit(); }
        }

        private string LoadProtected(string name)
        {
            string path = SafeChild(stateRoot, "Settings/" + name);
            EnsureSafePath(path);
            if (!File.Exists(path)) return null;
            try { return Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(path), Encoding.UTF8.GetBytes(ModId), DataProtectionScope.CurrentUser)); }
            catch (CryptographicException ex) { throw new IOException("本机保留的配置无法解密，请恢复配置文件或使用原来的 Windows 账户。未覆盖现有设置。", ex); }
        }

        private static string ConfigName(string game) { return Hash(Encoding.UTF8.GetBytes(game.ToUpperInvariant())) + ".bin"; }
        private static string OwnershipName(string game) { return ConfigName(game) + ".uninstalled-owner.bin"; }
        private static string ModDirectory(string game) { return SafeChild(game, "Mods/StardewFarmAssistant"); }
        private static Version AssemblyVersion(string path) { EnsureSafePath(path); return AssemblyName.GetAssemblyName(path).Version; }

        private static bool IsCompatibleSmapi(string game)
        {
            try
            {
                foreach (string relative in new[] { "StardewModdingAPI.exe", "StardewModdingAPI.dll", "StardewModdingAPI.runtimeconfig.json", "StardewModdingAPI.deps.json", "smapi-internal/SMAPI.Toolkit.dll" })
                    if (!File.Exists(SafeChild(game, relative))) return false;
                return AssemblyVersion(Path.Combine(game, "StardewModdingAPI.dll")) >= new Version(4, 5, 2, 0) && AssemblyVersion(SafeChild(game, "smapi-internal/SMAPI.Toolkit.dll")) >= new Version(4, 5, 2, 0);
            }
            catch { return false; }
        }

        private static void RequireGame(string game)
        {
            EnsureSafePath(game);
            if (!Directory.Exists(game)) throw new InvalidOperationException("游戏文件夹不存在，请浏览选择包含 Stardew Valley.exe 的目录。");
            foreach (string file in new[] { "Stardew Valley.exe", "Stardew Valley.dll", "Stardew Valley.runtimeconfig.json", "Stardew Valley.deps.json" })
                if (!File.Exists(SafeChild(game, file))) throw new InvalidOperationException("这不是完整的 Windows 星露谷游戏目录：缺少 " + file + "。");
            if (AssemblyVersion(Path.Combine(game, "Stardew Valley.dll")) < new Version(1, 6, 14, 0)) throw new InvalidOperationException("此工具需要星露谷物语 1.6.14 或更高版本。");
        }

        private bool IsOurMod(string mod)
        {
            string manifest = SafeChild(mod, "manifest.json");
            if (!File.Exists(manifest)) return false;
            return Value(ReadJson(manifest), "UniqueID") == ModId;
        }

        private void RequireOwnedOrEmpty(string game, string mod)
        {
            EnsureSafePath(mod);
            if (!Directory.Exists(mod) || IsEmptyDirectory(mod) || IsOurMod(mod)) return;
            // Only a previously verified uninstall can leave a known extra-file remainder.
            // A foreign manifest or any new collision with our payload remains protected.
            if (!File.Exists(SafeChild(mod, "manifest.json")) &&
                !OwnedFiles.Any(n => File.Exists(SafeChild(mod, n)) || Directory.Exists(SafeChild(mod, n))) &&
                LoadProtected(OwnershipName(game)) == ModId) return;
            throw new InvalidOperationException("同名模组目录已有未知内容，未覆盖。请保留它并检查目录。");
        }

        private Dictionary<string, object> ReadJson(string file)
        {
            EnsureSafePath(file);
            if (new FileInfo(file).Length > 1024 * 1024) throw new IOException("配置或清单过大，未修改文件。");
            return ParseJson(File.ReadAllText(file, Encoding.UTF8));
        }
        private Dictionary<string, object> ParseJson(string text)
        {
            try
            {
                Dictionary<string, object> result = json.Deserialize<Dictionary<string, object>>(text.TrimStart('\uFEFF'));
                if (result == null) throw new FormatException();
                return result;
            }
            catch (Exception ex) { throw new IOException("配置或模组清单不是有效的 JSON 对象，未覆盖该文件。请保留原文件并修正格式后重试。", ex); }
        }
        private static string Value(Dictionary<string, object> data, string key) { object value; return data.TryGetValue(key, out value) ? Convert.ToString(value) : ""; }
        private static bool IsEmptyDirectory(string path) { return !Directory.EnumerateFileSystemEntries(path).Any(); }
        private static void RemoveEmptyDirectory(string path) { EnsureSafePath(path); if (Directory.Exists(path) && IsEmptyDirectory(path)) Directory.Delete(path, false); }

        private static void RequireNotRunning()
        {
            foreach (Process process in Process.GetProcesses())
            {
                using (process)
                    if (process.ProcessName.Equals("StardewModdingAPI", StringComparison.OrdinalIgnoreCase) || process.ProcessName.Equals("Stardew Valley", StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("游戏正在运行。请先正常退出游戏，再安装、配置或卸载；当前游戏不会被强制关闭。");
            }
        }

        private static void AddSteam(HashSet<string> roots, RegistryKey parent, string subkey, string name)
        {
            try { using (RegistryKey key = parent.OpenSubKey(subkey)) { if (key != null) { string value = key.GetValue(name) as string; if (!String.IsNullOrWhiteSpace(value)) roots.Add(value); } } } catch { }
        }
        private static string Canonical(string path)
        {
            if (String.IsNullOrWhiteSpace(path)) throw new InvalidOperationException("请选择游戏文件夹。");
            string full = Path.GetFullPath(path.Trim().Trim('"'));
            string root = Path.GetPathRoot(full);
            return full.Length == root.Length ? root : full.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        }
        private static string SafeChild(string root, string relative)
        {
            if (Path.IsPathRooted(relative) || relative.Contains(":")) throw new IOException("检测到不安全的文件路径。");
            string canonicalRoot = Canonical(root);
            string result = Path.GetFullPath(Path.Combine(canonicalRoot, relative.Replace('/', Path.DirectorySeparatorChar)));
            if (!result.StartsWith(canonicalRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new IOException("文件路径越出了指定目录。");
            EnsureSafePath(result);
            return result;
        }
        private static void EnsureSafePath(string path)
        {
            string current = Path.GetFullPath(path);
            while (!String.IsNullOrEmpty(current))
            {
                if ((File.Exists(current) || Directory.Exists(current)) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0) throw new IOException("目录或文件包含链接或重解析点，已停止以防误写其他位置。");
                DirectoryInfo parent = Directory.GetParent(current);
                current = parent == null ? null : parent.FullName;
            }
        }
        private static void EnsureDirectory(string path) { EnsureSafePath(path); Directory.CreateDirectory(path); }
        private static void PreflightWritable(string path)
        {
            EnsureSafePath(path);
            if (!File.Exists(path))
            {
                if (Directory.Exists(path)) throw new IOException("待安装文件位置已有目录，未覆盖：" + Path.GetFileName(path));
                return;
            }
            if ((File.GetAttributes(path) & FileAttributes.ReadOnly) != 0) throw new IOException("文件是只读的，请先解除当前模组文件的只读属性：" + Path.GetFileName(path));
            using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
        }
        private static string Hash(byte[] data) { using (SHA256 sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant(); }
        private static string HashFile(string path) { using (SHA256 sha = SHA256.Create()) using (Stream stream = File.OpenRead(path)) return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant(); }

        private sealed class GameLock : IDisposable
        {
            private readonly Mutex mutex;
            private bool acquired;
            public GameLock(string path)
            {
                mutex = new Mutex(false, "Local\\FarmAssistant-" + Hash(Encoding.UTF8.GetBytes(path.ToUpperInvariant())));
                try { acquired = mutex.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) { mutex.Dispose(); throw new IOException("另一个配置器正在操作此游戏，请等它完成后再试。"); }
            }
            public void Dispose() { if (acquired) { mutex.ReleaseMutex(); acquired = false; } mutex.Dispose(); }
        }

        // Reversible, finite file operations. Never recursively remove any user's directory.
        private sealed class FileTransaction : IDisposable
        {
            private readonly List<KeyValuePair<string, byte[]>> before = new List<KeyValuePair<string, byte[]>>();
            private readonly List<string> createdDirectories = new List<string>();
            private bool committed;
            public void Write(string path, byte[] bytes)
            {
                EnsureSafePath(path);
                string directory = Path.GetDirectoryName(path);
                string cursor = directory;
                while (!Directory.Exists(cursor)) { createdDirectories.Add(cursor); cursor = Path.GetDirectoryName(cursor); }
                EnsureDirectory(directory);
                byte[] original = File.Exists(path) ? File.ReadAllBytes(path) : null;
                string temp = Path.Combine(directory, ".farm-assistant-" + Guid.NewGuid().ToString("N") + ".tmp");
                try
                {
                    File.WriteAllBytes(temp, bytes);
                    if (original == null) File.Move(temp, path);
                    else File.Replace(temp, path, null);
                    before.Add(new KeyValuePair<string, byte[]>(path, original));
                }
                finally { if (File.Exists(temp)) File.Delete(temp); }
            }
            public void Delete(string path)
            {
                EnsureSafePath(path);
                if (!File.Exists(path)) return;
                byte[] original = File.ReadAllBytes(path);
                File.Delete(path);
                before.Add(new KeyValuePair<string, byte[]>(path, original));
            }
            public void Commit() { committed = true; }
            public void Dispose()
            {
                if (committed) return;
                List<string> failed = new List<string>();
                for (int i = before.Count - 1; i >= 0; i--)
                {
                    try
                    {
                        EnsureSafePath(before[i].Key);
                        if (before[i].Value == null) { if (File.Exists(before[i].Key)) File.Delete(before[i].Key); }
                        else File.WriteAllBytes(before[i].Key, before[i].Value);
                    }
                    catch { failed.Add(Path.GetFileName(before[i].Key)); }
                }
                foreach (string directory in createdDirectories.Distinct().OrderByDescending(p => p.Length))
                    try { RemoveEmptyDirectory(directory); } catch { }
                if (failed.Count > 0) throw new IOException("操作中断且部分文件无法恢复：" + String.Join("、", failed) + "。请正常关闭游戏后重新安装完整玩家包。");
            }
        }
    }
}
