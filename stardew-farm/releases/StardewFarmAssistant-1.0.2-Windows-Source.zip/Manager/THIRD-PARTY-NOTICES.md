# 第三方来源与许可说明

适用于农场助手配置器 **1.0.0** 与农场模组 **1.0.2**。

## 本项目

配置器、农场助手原创代码、文档及原创农田图标由 LocalTools 提供，适用随包的 **MIT License**。本项目不是 ConcernedApe、Steam 或 SMAPI 的官方产品。MIT 许可不改变第三方软件、游戏资产及系统组件各自的许可。

玩家包不包含《Stardew Valley》游戏程序、游戏资源、个人存档或 SMAPI 完整安装包。未再分发字体文件；界面使用系统字体。

## SMAPI

SMAPI 是 Pathoschild 及其贡献者开发的《Stardew Valley》模组加载器；其项目许可为 **GNU Lesser General Public License v3.0（LGPL-3.0）**。安装包内第三方组件继续适用各自上游许可。配置器使用原版发布文件，不把 SMAPI 重新标为本项目的 MIT 软件。[SMAPI 4.5.2 许可全文](https://github.com/Pathoschild/SMAPI/blob/4.5.2/LICENSE.txt)

- [SMAPI 官方网站](https://smapi.io/)
- [SMAPI 4.5.2 官方发布页](https://github.com/Pathoschild/SMAPI/releases/tag/4.5.2)
- [SMAPI 4.5.2 对应源码](https://github.com/Pathoschild/SMAPI/tree/4.5.2)
- [SMAPI 官方源码仓库](https://github.com/Pathoschild/SMAPI)

仅在选中的游戏目录缺少 SMAPI 且玩家启用自动配置时，配置器从官方发布地址取得以下文件；玩家也可自行下载同一文件放在配置器旁供离线安装：

| 项目 | 固定值 |
|---|---|
| 版本 | 4.5.2 |
| 文件名 | `SMAPI-4.5.2-installer.zip` |
| 大小 | 41,889,142 字节 |
| SHA-256 | `dd01ddca7b566bfe0d3b3d2d03833496abc56c53da976241f2ab443f5484acc4` |
| 来源 | [GitHub 官方下载文件](https://github.com/Pathoschild/SMAPI/releases/download/4.5.2/SMAPI-4.5.2-installer.zip) |

配置器按照官方安装包 README 中的 Windows 手动安装流程使用 `internal/windows/install.dat` 的原版加载器文件，并从原版游戏目录的 `Stardew Valley.deps.json` 生成对应的 `StardewModdingAPI.deps.json`。本配置器跳过包内 `Mods` 下的可选模组，保留已有模组和共享依赖；不会运行会清理用户 SMAPI 日志目录的完整官方安装器。

要替换或更新共享 SMAPI，请按官方发布页和玩家指南进行。农场助手的卸载按钮不卸载 SMAPI。

## Stardew Valley 与 Windows

《Stardew Valley》及其名称、图像、资源和游戏程序属于其相应权利人；玩家需自行取得游戏。本项目仅在玩家选择的本地游戏目录中安装模组，并调用该目录的模组加载器。

.NET Framework、Windows Forms 和系统字体属于 Windows/.NET 系统环境。配置器要求 **Windows 10/11 x64、.NET Framework 4.8**，玩家包不包含这些系统组件的安装程序。

## 分发与网络边界

本次为本地玩家包，尚未上传公共模组站点，也没有公开签名更新源或云端反馈接口。依赖下载使用官方 HTTPS 来源并核对固定散列；下载过程中本配置器不上传个人存档、日志或配置。游戏、SMAPI 及其他已安装模组自身的网络行为由各自软件控制。
