using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

[assembly: AssemblyTitle("Stardew Farm Assistant Manager")]
[assembly: AssemblyDescription("One-click configuration for Stardew Farm Assistant")]
[assembly: AssemblyCompany("LocalTools")]
[assembly: AssemblyProduct("Stardew Farm Assistant Manager")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyCopyright("Copyright 2026 LocalTools. MIT License.")]

namespace FarmAssistantManager
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                string root = AppDomain.CurrentDomain.BaseDirectory;
                ManagerBackend backend = new ManagerBackend(root);
                using (ManagerForm form = new ManagerForm(backend))
                {
                    form.Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                    Application.Run(form);
                }
                return 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("配置器未能启动：" + ex.Message + "\r\n请将完整玩家包解压到可写目录，确认 Windows 已安装 .NET Framework 4.8 后重试。", "农场助手配置器", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
    }
}
