using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarmAssistantManager
{
    /// <summary>A small, native Windows front door for the farm assistant.</summary>
    public sealed class ManagerForm : Form
    {
        private static readonly Color Green = Color.FromArgb(37, 101, 65);
        private static readonly Color Ink = Color.FromArgb(31, 46, 36);
        private static readonly Color Muted = Color.FromArgb(91, 109, 98);
        private static readonly Color Background = Color.FromArgb(243, 246, 240);
        private static readonly Color Border = Color.FromArgb(218, 227, 215);
        private static readonly Color Error = Color.FromArgb(153, 54, 42);

        private readonly ManagerBackend backend;
        private readonly TextBox gamePath;
        private readonly ComboBox preset;
        private readonly NumericUpDown speed;
        private readonly CheckBox autoDependency;
        private readonly Label modeDescription;
        private readonly Label statusTitle;
        private readonly Label statusDetail;
        private readonly Label gameBadge;
        private readonly Label smapiBadge;
        private readonly Label modBadge;
        private readonly Button browse;
        private readonly Button detect;
        private readonly Button install;
        private readonly Button launch;
        private readonly Button cancel;
        private readonly LinkLabel uninstall;
        private readonly LinkLabel details;
        private readonly TextBox operationLog;
        private readonly ProgressBar activity;
        private readonly System.Windows.Forms.Timer pathDelay;
        private readonly ToolTip tips;
        private readonly Panel detailsHost;
        private Detection lastDetection;
        private CancellationTokenSource operationCancellation;
        private bool busy;
        private bool scanning;
        private bool supportsCancellation;
        private bool closeRequested;
        private bool initialDiscovery = true;
        private bool detailsExpanded;
        private bool previewing;
        private int inspectionRevision;
        private string inspectedInput = String.Empty;

        public ManagerForm(ManagerBackend backend)
        {
            if (backend == null) throw new ArgumentNullException("backend");
            this.backend = backend;
            Text = "星露谷自动农场 · 一键配置";
            Name = "FarmAssistantManager";
            AccessibleName = "星露谷自动农场配置器";
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(840, 690);
            MinimumSize = new Size(740, 650);
            BackColor = Background;
            ForeColor = Ink;
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            KeyPreview = true;
            DoubleBuffered = true;

            tips = new ToolTip();
            tips.AutoPopDelay = 15000;
            tips.InitialDelay = 450;
            tips.ReshowDelay = 100;
            pathDelay = new System.Windows.Forms.Timer();
            pathDelay.Interval = 400;

            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.AutoScroll = true;
            root.AutoScrollMinSize = new Size(0, 645);
            root.Padding = new Padding(24, 16, 24, 16);
            root.ColumnCount = 1;
            root.RowCount = 7;
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(root);

            TableLayoutPanel header = new TableLayoutPanel();
            header.AutoSize = true;
            header.Dock = DockStyle.Fill;
            header.Margin = new Padding(0, 0, 0, 12);
            header.ColumnCount = 2;
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 64F));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            FarmMark mark = new FarmMark();
            mark.Size = new Size(52, 52);
            mark.Margin = new Padding(0, 2, 12, 0);
            header.Controls.Add(mark, 0, 0);
            TableLayoutPanel headings = new TableLayoutPanel();
            headings.AutoSize = true;
            headings.Dock = DockStyle.Fill;
            headings.ColumnCount = 1;
            headings.Margin = new Padding(0);
            Label heading = MakeLabel("星露谷自动农场", 21F, true);
            heading.Margin = new Padding(0, 0, 0, 3);
            headings.Controls.Add(heading);
            Label subtitle = MakeLabel("自动种田 · 规整开荒 · 自适应加速", 10F, false);
            subtitle.ForeColor = Muted;
            subtitle.Margin = new Padding(0);
            headings.Controls.Add(subtitle);
            header.Controls.Add(headings, 1, 0);
            root.Controls.Add(header, 0, 0);

            CardPanel pathCard = new CardPanel();
            TableLayoutPanel pathLayout = CardContents(pathCard);
            pathLayout.RowCount = 3;
            pathLayout.Controls.Add(SectionLabel("游戏位置"), 0, 0);
            TableLayoutPanel pathRow = new TableLayoutPanel();
            pathRow.AutoSize = true;
            pathRow.Dock = DockStyle.Fill;
            pathRow.ColumnCount = 3;
            pathRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            pathRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            pathRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            pathRow.Margin = new Padding(0, 0, 0, 7);
            gamePath = new TextBox();
            gamePath.Name = "GamePath";
            gamePath.AccessibleName = "星露谷游戏文件夹";
            gamePath.Dock = DockStyle.Fill;
            gamePath.Margin = new Padding(0, 3, 8, 0);
            gamePath.TabIndex = 0;
            browse = MakeButton("浏览…(&B)", false);
            browse.Name = "BrowseGame";
            browse.TabIndex = 1;
            browse.Margin = new Padding(0, 0, 8, 0);
            detect = MakeButton("自动检测(&D)", false);
            detect.Name = "DetectGame";
            detect.TabIndex = 2;
            detect.Margin = new Padding(0);
            pathRow.Controls.Add(gamePath, 0, 0);
            pathRow.Controls.Add(browse, 1, 0);
            pathRow.Controls.Add(detect, 2, 0);
            pathLayout.Controls.Add(pathRow, 0, 1);
            FlowLayoutPanel badges = new FlowLayoutPanel();
            badges.AutoSize = true;
            badges.Dock = DockStyle.Fill;
            badges.Margin = new Padding(0);
            badges.WrapContents = true;
            gameBadge = Badge("游戏：待检测");
            smapiBadge = Badge("SMAPI：待检测");
            modBadge = Badge("助手：待检测");
            badges.Controls.Add(gameBadge);
            badges.Controls.Add(smapiBadge);
            badges.Controls.Add(modBadge);
            pathLayout.Controls.Add(badges, 0, 2);
            root.Controls.Add(pathCard, 0, 1);
            tips.SetToolTip(gamePath, "选择 Stardew Valley.exe 所在文件夹，也可以直接粘贴目录。F5 重新检测。");

            CardPanel configurationCard = new CardPanel();
            TableLayoutPanel configLayout = CardContents(configurationCard);
            configLayout.Controls.Add(SectionLabel("玩法与加速"), 0, 0);
            TableLayoutPanel options = new TableLayoutPanel();
            options.AutoSize = true;
            options.Dock = DockStyle.Fill;
            options.ColumnCount = 2;
            options.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66F));
            options.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34F));
            options.Margin = new Padding(0, 0, 0, 12);
            TableLayoutPanel modeColumn = new TableLayoutPanel();
            modeColumn.AutoSize = true;
            modeColumn.Dock = DockStyle.Fill;
            modeColumn.ColumnCount = 1;
            modeColumn.Margin = new Padding(0, 0, 22, 0);
            modeColumn.Controls.Add(FieldLabel("玩法模式"));
            preset = new ComboBox();
            preset.Name = "Preset";
            preset.AccessibleName = "玩法模式";
            preset.DropDownStyle = ComboBoxStyle.DropDownList;
            preset.Dock = DockStyle.Top;
            preset.Margin = new Padding(0, 1, 0, 5);
            preset.Items.Add(new PresetItem("development", "开荒种田（推荐）", "优先照料作物，闲暇时沿农田边界规整开荒。"));
            preset.Items.Add(new PresetItem("rush", "收益速进", "减少额外开荒，把体力与资金用于种植、出货和再投资。"));
            preset.Items.Add(new PresetItem("showcase", "观赏演示", "保留更清楚的工具动作，兼顾观赏与自动种田。"));
            preset.SelectedIndex = 0;
            preset.TabIndex = 3;
            modeColumn.Controls.Add(preset);
            modeDescription = MakeLabel(String.Empty, 9F, false);
            modeDescription.ForeColor = Muted;
            modeDescription.Margin = new Padding(0);
            modeDescription.MaximumSize = new Size(440, 0);
            modeColumn.Controls.Add(modeDescription);
            options.Controls.Add(modeColumn, 0, 0);
            TableLayoutPanel speedColumn = new TableLayoutPanel();
            speedColumn.AutoSize = true;
            speedColumn.Dock = DockStyle.Fill;
            speedColumn.ColumnCount = 1;
            speedColumn.Margin = new Padding(0);
            speedColumn.Controls.Add(FieldLabel("加速上限"));
            speed = new NumericUpDown();
            speed.Name = "SpeedCeiling";
            speed.AccessibleName = "自适应加速上限，1 至 200 档";
            speed.Minimum = 1;
            speed.Maximum = 200;
            speed.Value = 200;
            speed.Increment = 1;
            speed.Dock = DockStyle.Top;
            speed.Margin = new Padding(0, 1, 0, 5);
            speed.TabIndex = 4;
            speedColumn.Controls.Add(speed);
            Label speedHint = MakeLabel("按电脑负载自动调整\n目标档位不等于实际倍速", 9F, false);
            speedHint.ForeColor = Muted;
            speedHint.Margin = new Padding(0);
            speedColumn.Controls.Add(speedHint);
            options.Controls.Add(speedColumn, 1, 0);
            configLayout.Controls.Add(options, 0, 1);
            autoDependency = new CheckBox();
            autoDependency.Name = "AutoSmapi";
            autoDependency.Text = "缺少 SMAPI 时，自动配置官方组件";
            autoDependency.AccessibleDescription = "缺少运行组件时联网下载官方 SMAPI；已安装时保留现有组件。";
            autoDependency.AutoSize = true;
            autoDependency.Checked = true;
            autoDependency.Margin = new Padding(0);
            autoDependency.TabIndex = 5;
            tips.SetToolTip(autoDependency, "SMAPI 是社区模组的运行组件。缺少时需要联网；已安装时不会再次配置。");
            configLayout.Controls.Add(autoDependency, 0, 2);
            root.Controls.Add(configurationCard, 0, 2);

            TableLayoutPanel status = new TableLayoutPanel();
            status.Dock = DockStyle.Fill;
            status.AutoSize = true;
            status.ColumnCount = 1;
            status.Margin = new Padding(0, 0, 0, 8);
            statusTitle = MakeLabel("正在查找游戏…", 11F, true);
            statusTitle.Name = "StatusTitle";
            statusTitle.Margin = new Padding(0, 0, 0, 3);
            statusDetail = MakeLabel("也可以使用“浏览”选择游戏文件夹。", 9F, false);
            statusDetail.Name = "StatusDetail";
            statusDetail.ForeColor = Muted;
            statusDetail.Margin = new Padding(0);
            statusDetail.MaximumSize = new Size(780, 0);
            status.Controls.Add(statusTitle, 0, 0);
            status.Controls.Add(statusDetail, 0, 1);
            root.Controls.Add(status, 0, 3);

            FlowLayoutPanel actions = new FlowLayoutPanel();
            actions.AutoSize = true;
            actions.Dock = DockStyle.Fill;
            actions.WrapContents = true;
            actions.Margin = new Padding(0, 0, 0, 4);
            install = MakeButton("一键安装并配置(&I)", true);
            install.Name = "InstallConfigure";
            install.MinimumSize = new Size(244, 44);
            install.TabIndex = 6;
            install.Margin = new Padding(0, 0, 10, 0);
            launch = MakeButton("启动游戏(&L)", false);
            launch.Name = "LaunchGame";
            launch.MinimumSize = new Size(146, 44);
            launch.TabIndex = 7;
            launch.Margin = new Padding(0, 0, 10, 0);
            cancel = MakeButton("取消操作", false);
            cancel.Name = "CancelOperation";
            cancel.MinimumSize = new Size(110, 44);
            cancel.TabIndex = 8;
            cancel.Margin = new Padding(0);
            cancel.Visible = false;
            actions.Controls.Add(install);
            actions.Controls.Add(launch);
            actions.Controls.Add(cancel);
            root.Controls.Add(actions, 0, 4);
            AcceptButton = install;

            TableLayoutPanel operation = new TableLayoutPanel();
            operation.Dock = DockStyle.Fill;
            operation.ColumnCount = 1;
            operation.RowCount = 3;
            operation.RowStyles.Add(new RowStyle(SizeType.Absolute, 5F));
            operation.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            operation.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            operation.Margin = new Padding(0, 0, 0, 10);
            activity = new ProgressBar();
            activity.Dock = DockStyle.Fill;
            activity.MarqueeAnimationSpeed = 24;
            activity.Style = ProgressBarStyle.Marquee;
            activity.Margin = new Padding(0);
            activity.Visible = false;
            operation.Controls.Add(activity, 0, 0);
            details = new LinkLabel();
            details.Name = "ToggleDetails";
            details.Text = "查看操作记录";
            details.LinkColor = Muted;
            details.ActiveLinkColor = Green;
            details.AutoSize = true;
            details.Margin = new Padding(0, 7, 0, 5);
            details.TabIndex = 9;
            operation.Controls.Add(details, 0, 1);
            detailsHost = new Panel();
            detailsHost.Dock = DockStyle.Fill;
            detailsHost.Margin = new Padding(0);
            detailsHost.Visible = false;
            operationLog = new TextBox();
            operationLog.Name = "OperationLog";
            operationLog.AccessibleName = "操作记录";
            operationLog.Multiline = true;
            operationLog.ReadOnly = true;
            operationLog.ScrollBars = ScrollBars.Vertical;
            operationLog.BackColor = Color.White;
            operationLog.BorderStyle = BorderStyle.FixedSingle;
            operationLog.Dock = DockStyle.Fill;
            operationLog.Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            operationLog.TabIndex = 10;
            detailsHost.Controls.Add(operationLog);
            operation.Controls.Add(detailsHost, 0, 2);
            root.Controls.Add(operation, 0, 5);

            TableLayoutPanel footer = new TableLayoutPanel();
            footer.Dock = DockStyle.Fill;
            footer.AutoSize = true;
            footer.ColumnCount = 2;
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            footer.Margin = new Padding(0);
            uninstall = new LinkLabel();
            uninstall.Name = "UninstallAssistant";
            uninstall.Text = "卸载本助手（保留存档）(&U)";
            uninstall.LinkColor = Error;
            uninstall.ActiveLinkColor = Error;
            uninstall.AutoSize = true;
            uninstall.Margin = new Padding(0, 2, 0, 0);
            uninstall.TabIndex = 11;
            tips.SetToolTip(uninstall, "只卸载自动农场助手；保留存档、其他模组和共用 SMAPI。游戏运行时需先正常退出。");
            footer.Controls.Add(uninstall, 0, 0);
            Label keys = MakeLabel("游戏内：F8 开始 / 暂停 · F9 设置", 9F, false);
            keys.ForeColor = Muted;
            keys.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            keys.Margin = new Padding(0, 2, 0, 0);
            footer.Controls.Add(keys, 1, 0);
            root.Controls.Add(footer, 0, 6);

            preset.SelectedIndexChanged += delegate { UpdateModeDescription(); };
            autoDependency.CheckedChanged += delegate
            {
                UpdateButtons();
                if (!busy && !scanning && lastDetection != null) ShowDetection(lastDetection);
            };
            gamePath.TextChanged += delegate
            {
                if (busy) return;
                initialDiscovery = false;
                inspectionRevision++;
                lastDetection = null;
                inspectedInput = String.Empty;
                UpdateButtons();
                pathDelay.Stop();
                pathDelay.Start();
            };
            pathDelay.Tick += async delegate
            {
                pathDelay.Stop();
                await InspectCurrentAsync(true);
            };
            browse.Click += async delegate
            {
                using (FolderBrowserDialog dialog = new FolderBrowserDialog())
                {
                    dialog.Description = "选择 Stardew Valley.exe 所在的游戏文件夹";
                    dialog.ShowNewFolderButton = false;
                    if (Directory.Exists(gamePath.Text)) dialog.SelectedPath = gamePath.Text;
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        gamePath.Text = dialog.SelectedPath;
                        pathDelay.Stop();
                        await InspectCurrentAsync(true);
                    }
                }
            };
            detect.Click += async delegate { await DiscoverAsync(); };
            install.Click += async delegate { await InstallAsync(); };
            launch.Click += async delegate { await LaunchAsync(); };
            uninstall.LinkClicked += async delegate { await UninstallAsync(); };
            cancel.Click += delegate { RequestCancel(); };
            details.LinkClicked += delegate { SetDetailsExpanded(!detailsExpanded); };
            Shown += async delegate
            {
                if (previewing) return;
                Rectangle available = Screen.FromControl(this).WorkingArea;
                if (Height > available.Height || Width > available.Width)
                {
                    MinimumSize = new Size(Math.Min(MinimumSize.Width, available.Width), Math.Min(MinimumSize.Height, available.Height));
                    Size = new Size(Math.Min(Width, available.Width), Math.Min(Height, available.Height));
                    Location = new Point(available.Left + (available.Width - Width) / 2, available.Top + (available.Height - Height) / 2);
                }
                if (initialDiscovery) await DiscoverAsync();
                else await InspectCurrentAsync(true);
            };
            Resize += delegate
            {
                modeDescription.MaximumSize = new Size(Math.Max(240, modeColumn.ClientSize.Width), 0);
                statusDetail.MaximumSize = new Size(Math.Max(500, root.ClientSize.Width - root.Padding.Horizontal), 0);
            };
            UpdateModeDescription();
            UpdateButtons();
        }

        /// <summary>Optional preferred directory from the launcher; inspection occurs when shown.</summary>
        public void SetInitialGamePath(string path)
        {
            initialDiscovery = false;
            gamePath.Text = path ?? String.Empty;
            pathDelay.Stop();
        }

        /// <summary>Render only this form, without any OS screen capture or installation action.</summary>
        public void SavePreview(string path, int width, int height)
        {
            if (String.IsNullOrWhiteSpace(path)) throw new ArgumentException("预览文件路径为空。", "path");
            using (Bitmap image = RenderPreview(width, height)) image.Save(path, ImageFormat.Png);
        }

        /// <summary>Return a caller-owned bitmap of this form; no screen capture or file mutation.</summary>
        public Bitmap RenderPreview(int width, int height)
        {
            if (InvokeRequired) throw new InvalidOperationException("请在窗口 UI 线程绘制预览。");
            pathDelay.Stop();
            string currentPath = gamePath.Text.Trim();
            if (!busy && !String.IsNullOrWhiteSpace(currentPath) && inspectedInput != currentPath)
            {
                lastDetection = backend.Inspect(currentPath);
                inspectedInput = currentPath;
                UpdateBadges(lastDetection);
                ShowDetection(lastDetection);
                UpdateButtons();
            }
            ClientSize = new Size(Math.Max(720, width), Math.Max(610, height));
            bool wasVisible = Visible;
            bool taskbar = ShowInTaskbar;
            double opacity = Opacity;
            previewing = true;
            try
            {
                if (!wasVisible)
                {
                    ShowInTaskbar = false;
                    Opacity = 0;
                    Show();
                }
                PerformLayout();
                Bitmap image = new Bitmap(Width, Height);
                DrawToBitmap(image, new Rectangle(Point.Empty, Size));
                return image;
            }
            finally
            {
                if (!wasVisible)
                {
                    Hide();
                    Opacity = opacity;
                    ShowInTaskbar = taskbar;
                }
                previewing = false;
            }
        }

        protected override bool ShowWithoutActivation
        {
            get { return previewing || base.ShowWithoutActivation; }
        }

        private async Task DiscoverAsync()
        {
            if (busy || scanning) return;
            scanning = true;
            int revision = ++inspectionRevision;
            pathDelay.Stop();
            UpdateButtons();
            SetStatus("正在检测游戏位置…", "正在读取本机的游戏安装目录。", false);
            try
            {
                List<string> found = await Task.Run(delegate { return backend.FindGamePaths(); });
                if (IsDisposed || Disposing || revision != inspectionRevision) return;
                if (found == null || found.Count == 0)
                {
                    SetStatus("没有自动找到游戏", "点击“浏览”，选择 Stardew Valley.exe 所在文件夹。", false);
                    if (!String.IsNullOrWhiteSpace(gamePath.Text)) await InspectCurrentAsync(true);
                    return;
                }
                string preferred = found[0];
                foreach (string candidate in found)
                {
                    if (String.Equals(candidate, gamePath.Text, StringComparison.OrdinalIgnoreCase))
                    {
                        preferred = candidate;
                        break;
                    }
                }
                gamePath.Text = preferred;
                pathDelay.Stop();
                await InspectCurrentAsync(true);
                if (found.Count > 1) AppendLog("发现 " + found.Count + " 个游戏目录；当前使用 " + preferred);
            }
            catch (Exception ex)
            {
                if (!IsDisposed && !Disposing) ShowFailure("自动检测未完成", ex);
            }
            finally
            {
                scanning = false;
                if (!IsDisposed && !Disposing) UpdateButtons();
            }
        }

        private async Task<Detection> InspectCurrentAsync(bool showStatus)
        {
            string input = gamePath.Text.Trim();
            int revision = ++inspectionRevision;
            if (String.IsNullOrWhiteSpace(input))
            {
                lastDetection = null;
                inspectedInput = input;
                UpdateBadges(null);
                if (showStatus) SetStatus("选择游戏文件夹", "自动检测，或使用“浏览”选择游戏所在位置。", false);
                UpdateButtons();
                return null;
            }
            try
            {
                Detection result = await Task.Run(delegate { return backend.Inspect(input); });
                if (IsDisposed || Disposing || revision != inspectionRevision || input != gamePath.Text.Trim()) return null;
                lastDetection = result;
                inspectedInput = input;
                UpdateBadges(result);
                if (showStatus) ShowDetection(result);
                UpdateButtons();
                return result;
            }
            catch (Exception ex)
            {
                if (!IsDisposed && !Disposing && revision == inspectionRevision)
                {
                    lastDetection = null;
                    inspectedInput = input;
                    UpdateBadges(null);
                    ShowFailure("无法检查这个目录", ex);
                    UpdateButtons();
                }
                return null;
            }
        }

        private async Task InstallAsync()
        {
            if (busy || scanning) return;
            string input = gamePath.Text.Trim();
            PresetItem selected = preset.SelectedItem as PresetItem;
            string selectedPreset = selected == null ? "development" : selected.Id;
            int ceiling = Decimal.ToInt32(speed.Value);
            bool dependency = autoDependency.Checked;
            BeginOperation("正在安装并配置…", true);
            try
            {
                bool returnedSuccessfully = false;
                try
                {
                    CancellationToken token = operationCancellation.Token;
                    await Task.Run(delegate { backend.Install(input, selectedPreset, ceiling, dependency, ReportProgress, token); });
                    returnedSuccessfully = true;
                }
                catch (OperationCanceledException)
                {
                    SetStatus("操作已取消", "已等待后台退出；可重新检测后再试。", false);
                    AppendLog("操作取消，检查当前安装状态。");
                }
                catch (Exception ex) { ShowFailure("安装配置未完成", ex); }
                Detection actual = await InspectCurrentAsync(false);
                if (returnedSuccessfully && actual != null && actual.GameFound && actual.SmapiFound && actual.ModInstalled)
                {
                    SetStatus("配置完成，可以启动游戏", "读回已安装助手 " + VersionText(actual) + "。进入存档后按 F8 开始自动种田。", false);
                    AppendLog("安装后检查：游戏、SMAPI 与自动农场助手均已就绪。");
                }
                else if (returnedSuccessfully)
                {
                    SetStatus("安装后的检查未通过", "请查看操作记录并重新检测；当前目录与玩法设置已保留。", true);
                    AppendLog("安装返回后未读到完整可用状态，未将其标记为成功。");
                    SetDetailsExpanded(true);
                }
            }
            finally { EndOperation(); }
        }

        private async Task UninstallAsync()
        {
            if (busy || scanning) return;
            string input = gamePath.Text.Trim();
            BeginOperation("正在卸载本助手…", false);
            try
            {
                bool returnedSuccessfully = false;
                try
                {
                    await Task.Run(delegate { backend.Uninstall(input, ReportProgress); });
                    returnedSuccessfully = true;
                }
                catch (Exception ex) { ShowFailure("卸载未完成", ex); }
                Detection actual = await InspectCurrentAsync(false);
                if (returnedSuccessfully && actual != null && !actual.ModInstalled)
                {
                    SetStatus("自动农场助手已卸载", "存档、其他模组和共用 SMAPI 保留。需要时可再次一键安装。", false);
                    AppendLog("卸载后检查：当前游戏目录中已无自动农场助手。");
                }
                else if (returnedSuccessfully)
                {
                    SetStatus("卸载后的检查未通过", "请查看操作记录并重新检测。", true);
                    AppendLog("卸载返回后未确认助手已移除，未将其标记为成功。");
                    SetDetailsExpanded(true);
                }
            }
            finally { EndOperation(); }
        }

        private async Task LaunchAsync()
        {
            if (busy || scanning) return;
            string input = gamePath.Text.Trim();
            BeginOperation("正在启动游戏…", false);
            try
            {
                await Task.Run(delegate { backend.Launch(input); });
                SetStatus("已发送游戏启动请求", "正在打开游戏窗口。进入存档后 F8 开始 / 暂停，F9 设置。", false);
                AppendLog("已调用模组游戏启动入口；游戏实际运行状态由游戏窗口确认。");
            }
            catch (Exception ex) { ShowFailure("游戏未能启动", ex); }
            finally { EndOperation(); }
        }

        private void BeginOperation(string text, bool cancellable)
        {
            busy = true;
            supportsCancellation = cancellable;
            pathDelay.Stop();
            inspectionRevision++;
            operationCancellation = new CancellationTokenSource();
            activity.Visible = true;
            cancel.Visible = cancellable;
            cancel.Enabled = cancellable;
            cancel.Text = "取消操作";
            SetStatus(text, "操作过程中可以查看记录；请等待当前步骤完成。", false);
            AppendLog(text);
            UpdateButtons();
        }

        private void EndOperation()
        {
            busy = false;
            supportsCancellation = false;
            if (operationCancellation != null)
            {
                operationCancellation.Dispose();
                operationCancellation = null;
            }
            if (IsDisposed || Disposing) return;
            activity.Visible = false;
            cancel.Visible = false;
            UpdateButtons();
            if (closeRequested) Close();
        }

        private void RequestCancel()
        {
            if (!busy || !supportsCancellation || operationCancellation == null) return;
            operationCancellation.Cancel();
            cancel.Enabled = false;
            cancel.Text = "正在取消…";
            SetStatus("正在等待安全取消…", "后台将在可取消的步骤退出，退出后可以重试。", false);
        }

        private void ReportProgress(string text)
        {
            if (IsDisposed || Disposing || !IsHandleCreated) return;
            try
            {
                BeginInvoke((Action)delegate
                {
                    if (IsDisposed || Disposing) return;
                    AppendLog(text);
                    if (!closeRequested && busy)
                        SetStatus("正在处理…", ShortMessage(text, 230), false);
                });
            }
            catch (InvalidOperationException) { }
        }

        private void UpdateModeDescription()
        {
            PresetItem item = preset.SelectedItem as PresetItem;
            modeDescription.Text = item == null ? String.Empty : item.Description;
        }

        private void UpdateButtons()
        {
            bool idle = !busy && !scanning && !closeRequested;
            bool current = lastDetection != null && inspectedInput == gamePath.Text.Trim();
            bool gameReady = current && lastDetection.GameFound;
            bool smapiReady = gameReady && lastDetection.SmapiFound;
            bool modReady = current && lastDetection.ModInstalled;
            gamePath.Enabled = !busy && !closeRequested;
            browse.Enabled = idle;
            detect.Enabled = idle;
            preset.Enabled = idle;
            speed.Enabled = idle;
            autoDependency.Enabled = idle;
            install.Enabled = idle && gameReady && (smapiReady || autoDependency.Checked);
            launch.Enabled = idle && smapiReady && modReady;
            uninstall.Enabled = idle && modReady;
            install.Text = modReady ? "一键应用配置 / 更新(&I)" : "一键安装并配置(&I)";
            detect.Text = scanning ? "正在检测…" : "自动检测(&D)";
        }

        private void UpdateBadges(Detection result)
        {
            SetBadge(gameBadge, "游戏：" + (result != null && result.GameFound ? "已找到" : result != null && result.ModInstalled ? "文件不完整" : "未找到"), result != null && result.GameFound);
            SetBadge(smapiBadge, "SMAPI：" + (result != null && result.SmapiFound ? "已就绪" : "未配置"), result != null && result.SmapiFound);
            SetBadge(modBadge, "助手：" + (result != null && result.ModInstalled ? VersionText(result) : "未安装"), result != null && result.ModInstalled);
        }

        private void ShowDetection(Detection result)
        {
            if (result != null && result.ModInstalled && !result.GameFound)
            {
                SetStatus("游戏文件不完整，助手仍可卸载", "暂时不能安装或启动。可先卸载本助手，再修复游戏文件；存档和其他模组保留。", true);
                if (!String.IsNullOrWhiteSpace(result.Status)) AppendLog(result.Status);
                return;
            }
            if (result == null || !result.GameFound)
            {
                SetStatus("这个目录中没有找到游戏", "选择 Stardew Valley.exe 所在文件夹，或点击“自动检测”。", true);
                return;
            }
            if (result.ModInstalled && result.SmapiFound)
                SetStatus("助手已安装，可以启动游戏", "也可以更改玩法后点击“一键应用配置 / 更新”。", false);
            else if (!result.SmapiFound)
                SetStatus("游戏已找到，缺少 SMAPI", autoDependency.Checked ? "一键安装时将联网配置官方组件，再安装自动农场助手。" : "勾选自动配置 SMAPI，或安装运行组件后重新检测。", false);
            else
                SetStatus("游戏已找到，可以一键安装", "选择玩法和加速上限，然后点击“一键安装并配置”。", false);
            if (!String.IsNullOrWhiteSpace(result.Status)) AppendLog(result.Status);
        }

        private void SetStatus(string title, string detail, bool error)
        {
            statusTitle.Text = title;
            statusTitle.ForeColor = error ? Error : Ink;
            statusDetail.Text = detail ?? String.Empty;
            statusDetail.ForeColor = error ? Error : Muted;
        }

        private void ShowFailure(string title, Exception error)
        {
            string message = ShortMessage(error == null ? "未能完成当前操作。" : error.Message, 320);
            SetStatus(title, message + " 目录和设置已保留，可处理原因后重试。", true);
            AppendLog(title + "：" + message);
            SetDetailsExpanded(true);
        }

        private void AppendLog(string text)
        {
            if (String.IsNullOrWhiteSpace(text)) return;
            if (operationLog.TextLength > 24000) operationLog.Text = operationLog.Text.Substring(operationLog.TextLength - 18000);
            operationLog.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + text.Trim() + Environment.NewLine);
            operationLog.SelectionStart = operationLog.TextLength;
            operationLog.ScrollToCaret();
        }

        private void SetDetailsExpanded(bool expanded)
        {
            detailsExpanded = expanded;
            detailsHost.Visible = expanded;
            details.Text = expanded ? "收起操作记录" : "查看操作记录";
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (busy)
            {
                e.Cancel = true;
                closeRequested = true;
                if (supportsCancellation) RequestCancel();
                SetStatus("正在等待当前操作结束…", "完成当前文件步骤后将关闭窗口，请稍候。", false);
                UpdateButtons();
            }
            else
            {
                inspectionRevision++;
                pathDelay.Stop();
            }
            base.OnFormClosing(e);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.F5 && !busy && !scanning)
            {
                detect.PerformClick();
                return true;
            }
            if (keyData == Keys.Escape && busy && supportsCancellation)
            {
                RequestCancel();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                pathDelay.Dispose();
                tips.Dispose();
                if (operationCancellation != null) operationCancellation.Dispose();
            }
            base.Dispose(disposing);
        }

        private static string VersionText(Detection result)
        {
            return String.IsNullOrWhiteSpace(result.Version) ? "已安装" : "v" + result.Version.TrimStart('v', 'V');
        }

        private static string ShortMessage(string value, int limit)
        {
            string message = (value ?? String.Empty).Trim().Replace("\r", " ").Replace("\n", " ");
            return message.Length <= limit ? message : message.Substring(0, limit - 1) + "…";
        }

        private static TableLayoutPanel CardContents(CardPanel card)
        {
            card.AutoSize = true;
            card.Dock = DockStyle.Fill;
            card.Padding = new Padding(16, 12, 16, 13);
            card.Margin = new Padding(0, 0, 0, 10);
            TableLayoutPanel table = new TableLayoutPanel();
            table.ColumnCount = 1;
            table.AutoSize = true;
            table.Dock = DockStyle.Fill;
            table.Margin = new Padding(0);
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            card.Controls.Add(table);
            return table;
        }

        private static Label MakeLabel(string text, float size, bool bold)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.Font = new Font("Microsoft YaHei UI", size, bold ? FontStyle.Bold : FontStyle.Regular, GraphicsUnit.Point);
            label.ForeColor = Ink;
            label.UseMnemonic = false;
            return label;
        }

        private static Label SectionLabel(string text)
        {
            Label label = MakeLabel(text, 11F, true);
            label.Margin = new Padding(0, 0, 0, 10);
            return label;
        }

        private static Label FieldLabel(string text)
        {
            Label label = MakeLabel(text, 9F, false);
            label.ForeColor = Muted;
            label.Margin = new Padding(0, 0, 0, 3);
            return label;
        }

        private static Label Badge(string text)
        {
            Label badge = MakeLabel(text, 9F, false);
            badge.Margin = new Padding(0, 0, 16, 0);
            badge.ForeColor = Muted;
            return badge;
        }

        private static void SetBadge(Label label, string text, bool ready)
        {
            label.Text = text;
            label.ForeColor = ready ? Green : Muted;
        }

        private static Button MakeButton(string text, bool primary)
        {
            Button button = new Button();
            button.Text = text;
            button.AutoSize = true;
            button.MinimumSize = new Size(88, 34);
            button.Padding = new Padding(10, 2, 10, 2);
            button.Cursor = Cursors.Hand;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = primary ? 0 : 1;
            button.FlatAppearance.BorderColor = Border;
            button.BackColor = primary ? Green : Color.White;
            button.ForeColor = primary ? Color.White : Ink;
            button.UseVisualStyleBackColor = false;
            return button;
        }

        private sealed class PresetItem
        {
            internal readonly string Id;
            internal readonly string Label;
            internal readonly string Description;
            internal PresetItem(string id, string label, string description)
            {
                Id = id;
                Label = label;
                Description = description;
            }
            public override string ToString() { return Label; }
        }

        private sealed class CardPanel : Panel
        {
            internal CardPanel()
            {
                BackColor = Color.White;
                DoubleBuffered = true;
            }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                using (Pen pen = new Pen(Border))
                    e.Graphics.DrawRectangle(pen, 0, 0, Math.Max(0, Width - 1), Math.Max(0, Height - 1));
            }
        }

        private sealed class FarmMark : Control
        {
            internal FarmMark()
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
                AccessibleName = "农田幼苗标志";
                TabStop = false;
            }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                float scale = Math.Min(Width, Height) / 52F;
                e.Graphics.ScaleTransform(scale, scale);
                using (Brush ground = new SolidBrush(Green)) e.Graphics.FillRectangle(ground, 0, 0, 52, 52);
                using (Pen stem = new Pen(Color.White, 2.5F))
                {
                    stem.StartCap = LineCap.Round;
                    stem.EndCap = LineCap.Round;
                    e.Graphics.DrawLine(stem, 26, 36, 26, 22);
                    e.Graphics.DrawLine(stem, 12, 40, 40, 40);
                }
                using (GraphicsPath leaf = new GraphicsPath())
                using (Brush white = new SolidBrush(Color.White))
                {
                    leaf.AddBezier(26, 26, 13, 25, 13, 15, 13, 15);
                    leaf.AddBezier(13, 15, 26, 15, 28, 22, 26, 26);
                    leaf.CloseFigure();
                    e.Graphics.FillPath(white, leaf);
                    leaf.Reset();
                    leaf.AddBezier(26, 21, 27, 12, 38, 12, 39, 12);
                    leaf.AddBezier(39, 12, 39, 24, 30, 25, 26, 21);
                    leaf.CloseFigure();
                    e.Graphics.FillPath(white, leaf);
                }
            }
        }
    }
}
