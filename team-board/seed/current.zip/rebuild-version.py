from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
out = root / 'website' / 'seed' / 'current.zip'
out.parent.mkdir(parents=True, exist_ok=True)
paths = [root / 'README.md', root / 'schema.sql', root / 'rebuild-version.py',
         root / 'LICENSE-cloudbase-sdk.txt', root / 'LICENSE-third-party.txt']
paths += [p for p in (root / 'website').rglob('*') if p.is_file() and p != out]
with ZipFile(out, 'w', ZIP_DEFLATED) as z:
    for p in paths:
        z.write(p, p.relative_to(root).as_posix())
print('Prepared:', out)
