const fs=require('fs'),path=require('path');
const terser=require(process.env.YUJI_TERSER_PATH||'terser');
(async()=>{const root=process.argv[2];for(const p of fs.readdirSync(root)){if(!p.endsWith('.js'))continue;const name=path.join(root,p),code=fs.readFileSync(name,'utf8'),result=await terser.minify(code,{compress:true,mangle:{toplevel:false},format:{comments:false},sourceMap:false});if(result.error)throw result.error;fs.writeFileSync(name,result.code);}})().catch(e=>{console.error(e.message);process.exit(1)});
