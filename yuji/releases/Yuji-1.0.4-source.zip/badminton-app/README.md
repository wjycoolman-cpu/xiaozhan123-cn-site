# 羽记 1.0.4 源码

Android 包名 cn.local.yuji；versionName 1.0.4；versionCode 5。基于已正式本机交付的 1.0.3/code4，保留相机计分、赛事同步及原有计分功能，新增网站反馈入口。网站旧 1.0.1 不是本次源码基线。

## 反馈

在首页右上菜单选择“意见反馈”，填写后点“打开网站反馈页”。应用保留草稿，只把这段文字交给浏览器预填，由你在网站确认发送。“保存到本地”和“分享本地反馈”仍是本机或系统分享功能，没有自动提交；没有附带比赛、照片或视频。

## 构建

准备 Windows Python 3、JDK17、Android SDK platform android-35 与 build-tools35.0.0、Node.js。先执行 npm install --ignore-scripts（package.json 固定 Terser5.44.0）或设置 YUJI_TERSER_PATH 指向同版 Terser；构建本身不会联网下载。

python build.py --variant release --sdk <AndroidSDK> --jdk <JDK17> --signing <原签名目录>

输出 build/release/Yuji-1.0.4-release.apk。保留签名是兼容覆盖升级的条件；签名目录由原签名持有者在源码外维护，源码包不含任何密钥、密码或 DPAPI 文件。其他机器自行生成签名的 APK 无法覆盖原签名安装。本次反馈更新保留包名、权限和数据结构。

源码仅包含 app 源代码/静态资源、构建脚本及固定依赖说明，没有 build、node_modules、用户反馈或测试缓存。app/src/main/assets/vision 保留当前模型及许可证；APK 内的 assets 和 Java 类仍由原构建流程压缩并生成完整性校验。
