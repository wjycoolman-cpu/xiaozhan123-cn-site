(function(){'use strict';
const product=document.currentScript.dataset.product,key='website-feedback-draft/v1:'+product;
const id=product==='resume-studio'?'feedback-input':'feedbackText';
let activeInput,notice;
function remember(input){try{localStorage.setItem(key,input.value)}catch{}}
window.onNativeFeedbackOpen=function(opened){if(notice)notice.textContent=opened?'反馈网页已打开，文字仅预填，尚未发送；请在网页确认。原草稿留在本机。':'未能打开浏览器，内容仍在本机，尚未发送。可保存或导出后再试。';};
function connect(){const input=document.getElementById(id);if(!input||input.dataset.websiteFeedbackReady)return;input.dataset.websiteFeedbackReady='true';activeInput=input;
try{const saved=localStorage.getItem(key);if(!input.value&&saved)input.value=saved;}catch{}
input.addEventListener('input',()=>remember(input));
const host=input.closest('form')||(input.closest('label')?input.closest('label').parentElement:input.parentElement);
const button=document.createElement('button');button.type='button';button.textContent='打开网站反馈页';button.className=product==='resume-studio'?'btn':'primary';
notice=document.createElement('p');notice.className=product==='resume-studio'?'hint':'muted';notice.setAttribute('role','status');notice.textContent='网页会预填这段文字，确认后才发送。原草稿保留在本机。';
button.addEventListener('click',()=>{remember(input);try{if(!window.Native||typeof Native.openFeedback!=='function'){notice.textContent='此环境暂时无法打开反馈网页，内容保留在本机，尚未发送。';return;}notice.textContent='正在打开反馈网页，尚未发送…';if(Native.openFeedback(input.value)!==true)notice.textContent='暂时无法打开反馈网页，请检查内容长度和字符；原草稿保留，尚未发送。';}catch{notice.textContent='未能打开浏览器，原草稿保留，尚未发送。';}});
host.append(button,notice);
}
new MutationObserver(connect).observe(document.body,{childList:true,subtree:true});connect();
})();