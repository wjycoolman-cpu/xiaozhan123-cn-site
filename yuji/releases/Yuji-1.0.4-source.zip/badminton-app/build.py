"""Offline Android build with SDK tools and JDK 17; no Gradle or downloads.

Example: python build.py --variant both
Signing key stays outside the project in ../signing. Its password is protected
with Windows DPAPI for the current Windows user and is never printed.
"""
from __future__ import annotations
import argparse
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import secrets
import subprocess
import zipfile
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
SIGNER_SHA256 = "4599be5e5b584a296734a1a31c6b671d87993bde17cc456e540eca6a0b99bee5"

def integrity_source(assets, destination):
    files = {p.relative_to(assets).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in assets.rglob('*') if p.is_file()}
    entries = ',\n'.join('{'+json.dumps(name)+','+json.dumps(digest)+'}' for name,digest in sorted(files.items()))
    source = '''package cn.local.yuji;
import android.content.Context;import android.content.pm.*;import java.io.*;import java.security.*;
final class BuildIntegrity {
 static final String SIGNER="SIGNER_VALUE";
 static final String[][] ASSETS={ASSET_VALUES};
 static String digest(byte[] bytes)throws Exception{byte[] d=MessageDigest.getInstance("SHA-256").digest(bytes);StringBuilder s=new StringBuilder();for(byte b:d)s.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return s.toString();}
 static boolean allow(Context c){try{PackageInfo p=c.getPackageManager().getPackageInfo(c.getPackageName(),android.os.Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);android.content.pm.Signature[] sigs=android.os.Build.VERSION.SDK_INT>=28?p.signingInfo.getApkContentsSigners():p.signatures;if(sigs.length!=1||!SIGNER.equals(digest(sigs[0].toByteArray())))return false;return verify(c,false);}catch(Exception e){return false;}}
 static boolean verify(Context c,boolean vision){try{for(String[] entry:ASSETS){if(entry[0].startsWith("vision/")!=vision)continue;MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=c.getAssets().open(entry[0])){byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))>0)md.update(buffer,0,n);}StringBuilder hex=new StringBuilder();for(byte b:md.digest())hex.append(String.format(java.util.Locale.ROOT,"%02x",b&255));if(!entry[1].equals(hex.toString()))return false;}return true;}catch(Exception e){return false;}}
}
'''.replace('SIGNER_VALUE',SIGNER_SHA256).replace('ASSET_VALUES',entries)
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(source,encoding='utf-8')

class Blob(ctypes.Structure):
    _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]

def dpapi(value: bytes, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise RuntimeError("This local signing profile uses Windows DPAPI")
    buffer = (ctypes.c_ubyte * len(value)).from_buffer_copy(value)
    source = Blob(len(value), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    output = Blob()
    crypto = ctypes.windll.crypt32
    if decrypt:
        success = crypto.CryptUnprotectData(ctypes.byref(source), None, None, None,
                                            None, 1, ctypes.byref(output))
    else:
        success = crypto.CryptProtectData(ctypes.byref(source), "Yuji Badminton local signing",
                                          None, None, None, 1, ctypes.byref(output))
    if not success:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.data, output.size)
    finally:
        ctypes.windll.kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        ctypes.windll.kernel32.LocalFree(output.data)

def run(executable: Path, *args: str | Path, env=None):
    try:
        subprocess.run([str(executable), *(str(a) for a in args)], check=True, env=env)
    except subprocess.CalledProcessError as error:
        raise RuntimeError('build_tool_failed: ' + Path(executable).name + ' exit=' + str(error.returncode)) from None

def build(args):
    sdk = Path(args.sdk)
    jdk = Path(args.jdk)
    tools = sdk / "build-tools/35.0.0"
    platform = sdk / "platforms/android-35/android.jar"
    java, javac, jar, keytool = [jdk / f"bin/{name}.exe" for name in ("java", "javac", "jar", "keytool")]
    aapt, align = tools / "aapt2.exe", tools / "zipalign.exe"
    for required in (platform, java, javac, jar, aapt, align):
        if not required.is_file():
            raise FileNotFoundError(f"Required build tool missing: {required}")
    env = dict(os.environ)
    signing = Path(args.signing).resolve() if args.signing else ROOT.parent / "signing"
    key = signing / "yuji.p12"
    protected = signing / "yuji.dpapi.bin"
    if not args.compile_only:
        signing.mkdir(parents=True, exist_ok=True)
        if protected.is_file():
            password = dpapi(protected.read_bytes(), decrypt=True).decode("utf-8")
        elif key.is_file():
            raise RuntimeError("Existing signing key is missing its password. Recover it; do not replace the key.")
        else:
            password = secrets.token_urlsafe(32)
            protected.write_bytes(dpapi(password.encode("utf-8")))
        env["RESUME_SIGNING_PASS"] = password
        if not key.is_file():
            run(keytool, "-genkeypair", "-keystore", key, "-storetype", "PKCS12",
                "-alias", "yuji", "-keyalg", "RSA", "-keysize", "3072", "-validity", "10000",
                "-dname", "CN=Offline Yuji Badminton, OU=Local Apps, O=Personal, C=CN",
                "-storepass:env", "RESUME_SIGNING_PASS", "-keypass:env", "RESUME_SIGNING_PASS",
                "-noprompt", env=env)
    variants = ["debug", "release"] if args.variant == "both" else [args.variant]
    for variant in variants:
        out = ROOT / "build" / variant
        generated, classes, dex = [out / name for name in ("generated", "classes", "dex")]
        for directory in (out, generated, classes, dex):
            directory.mkdir(parents=True, exist_ok=True)
        # Remove stale class/dex files from previous unshrunk builds.
        for directory in (classes, dex):
            for file in directory.rglob('*'):
                if file.is_file(): file.unlink()
        assets = out / 'packaged-assets'
        shutil.copytree(ROOT / 'app/src/main/assets', assets, dirs_exist_ok=True)
        if variant == 'release':
            run(Path(shutil.which('node')), ROOT / 'build-minify.cjs', assets)
        integrity_source(assets, generated / 'cn/local/yuji/BuildIntegrity.java')
        manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        if variant == "debug":
            manifest = manifest.replace('android:debuggable="false"', 'android:debuggable="true"')
        manifest_path = out / "AndroidManifest.xml"
        manifest_path.write_text(manifest, encoding="utf-8")
        compiled = out / "resources.zip"
        run(aapt, "compile", "--dir", ROOT / "app/src/main/res", "-o", compiled)
        unsigned = out / "unsigned.apk"
        link = ["link", "-o", unsigned, "-I", platform, "--manifest", manifest_path,
                "-R", compiled, "--java", generated, "--min-sdk-version", "26",
                "--target-sdk-version", "35", "--auto-add-overlay"]
        if (ROOT / "app/src/main/assets").is_dir():
            link += ["-A", assets]
        run(aapt, *link)
        sources = sorted((ROOT / "app/src/main/java").rglob("*.java")) + sorted(generated.rglob("*.java"))
        run(javac, "--release", "8", "-encoding", "UTF-8", "-classpath", platform,
            "-d", classes, "-g" if variant == "debug" else "-g:none", *sources)
        if args.compile_only:
            print(f"Java compilation passed: {variant}", flush=True)
            continue
        classes_jar = out / "classes.jar"
        run(jar, "cf", classes_jar, "-C", classes, ".")
        if variant == 'release':
            run(java, '-cp', tools / 'lib/d8.jar', 'com.android.tools.r8.R8', '--release', '--min-api', '26',
                '--lib', platform, '--pg-conf', ROOT / 'proguard-rules.pro', '--pg-map-output', out / 'mapping.txt',
                '--output', dex, classes_jar)
        else:
            run(java, "-cp", tools / "lib/d8.jar", "com.android.tools.r8.D8", "--min-api", "26",
                "--lib", platform, "--output", dex, classes_jar)
        # Rebuild the central directory instead of appending through zipfile:
        # aapt2 uses ZIP header flags that zipfile otherwise normalizes only in
        # the central header, causing Android zipalign header-mismatch warnings.
        normalized = out / "normalized.apk"
        with zipfile.ZipFile(unsigned, "r") as source, zipfile.ZipFile(normalized, "w") as archive:
            for entry in source.infolist():
                info = zipfile.ZipInfo(entry.filename, entry.date_time)
                info.compress_type = zipfile.ZIP_STORED if entry.filename == "resources.arsc" else entry.compress_type
                info.external_attr = entry.external_attr
                archive.writestr(info, source.read(entry.filename))
            for file in sorted(dex.glob("*.dex")):
                archive.write(file, file.name, compress_type=zipfile.ZIP_DEFLATED)
        normalized.replace(unsigned)
        aligned = out / "aligned.apk"
        run(align, "-f", "-p", "4", unsigned, aligned)
        final = out / f"Yuji-1.0.4-{variant}.apk"
        run(java, "-jar", tools / "lib/apksigner.jar", "sign", "--ks", key, "--ks-key-alias", "yuji",
            "--ks-pass", "env:RESUME_SIGNING_PASS", "--key-pass", "env:RESUME_SIGNING_PASS",
            "--out", final, aligned, env=env)
        run(java, "-jar", tools / "lib/apksigner.jar", "verify", "--verbose", final)
        run(align, "-c", "-p", "4", final)
        print(f"Built: {final}", flush=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=["debug", "release", "both"], default="both")
    parser.add_argument("--sdk", default=r"D:\Android\Sdk")
    parser.add_argument("--jdk", default=r"D:\Unity\Editor\6000.3.20f1-x86_64\Editor\Data\PlaybackEngines\AndroidPlayer\OpenJDK")
    parser.add_argument("--signing", default="")
    parser.add_argument("--compile-only", action="store_true")
    build(parser.parse_args())
