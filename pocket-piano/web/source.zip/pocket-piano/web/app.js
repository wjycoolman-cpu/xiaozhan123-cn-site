import {createKeyboardAdapter} from './keyboard-layout.js';
import {StaffPractice} from './staff-practice.js';
import * as formal from './native-synth.js';
import{PianoAudio}from'../demo/audio.js';import{SongLibrary}from'./library.js';
const $=s=>document.querySelector(s),audio=new PianoAudio(message=>status(message)),library=new SongLibrary(),keyboard=$('#keyboard'),roll=$('#roll'),ctx=roll.getContext('2d');
const codes=['KeyZ','KeyS','KeyX','KeyD','KeyC','KeyV','KeyG','KeyB','KeyH','KeyN','KeyJ','KeyM','KeyQ','Digit2','KeyW','Digit3','KeyE','KeyR','Digit5','KeyT','Digit6','KeyY','Digit7','KeyU','KeyI','Digit9','KeyO','Digit0','KeyP','BracketLeft','Equal','BracketRight','KeyA','KeyF','KeyK','KeyL','Semicolon'];
const printed=['Z','S','X','D','C','V','G','B','H','N','J','M','Q','2','W','3','E','R','5','T','6','Y','7','U','I','9','O','0','P','[','=',']','A','F','K','L',';'];
const blacks=new Set([1,3,6,8,10]),names=['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
let keyboardAdapter=null,staffPractice=null,sessionReady=false,initialRestore=true,notation='staff',lastStaffAt=0,staffSongId='',pedalHeld=false;
let keyboardDrag=false,dragStart=null,loopState={enabled:false,a:0,b:0};let song=null,base=innerWidth<600?48:36,keyCount=innerWidth<600?8:33,keyElements=new Map(),keyRects=new Map(),pointers=new Map(),downs=new Map(),playing=false,mode='free',position=0,origin=0,speed=1,nextIndex=0,groups=[],groupIndex=0,matched=new Set(),playEpoch=0,recording=false,recordStart=0,recordNotes=[],recordOwners=new Map(),results=[],pageSize=30,nativePage=0,selectionEpoch=0,followLightUntil=0,endPrefix=[],lastDrawSignature='';
const time=ms=>`${Math.floor(ms/60000)}:${String(Math.floor(ms/1000)%60).padStart(2,'0')}`;let statusTimer=0;function status(s){clearTimeout(statusTimer);$('#status').textContent=s||'';if(/音色已切换|音域已调整|曲谱已就绪|已回到开头/.test(s||''))statusTimer=setTimeout(()=>{if($('#status').textContent===s)$('#status').textContent='';},1800);}
function duration(){return song?Math.max(1,song.durationMs||song.notes.reduce((m,n)=>Math.max(m,n.start+n.duration),0)):1;}
function mapPitch(p){let x=p;const last=Math.max(...keyElements.keys());while(x<base)x+=12;while(x>last)x-=12;return keyElements.has(x)?x:null;}
function configureKeys(){releasePhysical();keyboard.replaceChildren();keyElements.clear();keyRects.clear();let whites=[],all=[],p=base;while(whites.length<keyCount&&p<=108){all.push(p);if(!blacks.has(p%12))whites.push(p);p++;}const width=100/whites.length;for(const pitch of all){const black=blacks.has(pitch%12),index=black?whites.filter(x=>x<pitch).length:whites.indexOf(pitch),left=black?index*width-width*.31:index*width;const b=document.createElement('button');b.className='key '+(black?'black':'white');b.style.left=left+'%';b.style.width=width*(black?.62:1)+'%';b.dataset.pitch=pitch;b.setAttribute('aria-label',names[pitch%12]+(Math.floor(pitch/12)-1));const label=document.createElement('span');label.className='label';const code=document.createElement('span');code.className='computer';code.textContent=names[pitch%12]+(Math.floor(pitch/12)-1);const note=document.createElement('span');note.className='name';note.textContent=keyboardAdapter?.labelForPitch(pitch)||printed[pitch-base]||'';label.append(code,note);b.append(label);keyboard.append(b);keyElements.set(pitch,b);}updateRects();}
function updateRects(){const area=keyboard.getBoundingClientRect();for(const[p,b]of keyElements){const r=b.getBoundingClientRect();keyRects.set(p,{left:r.left-area.left,width:r.width,black:blacks.has(p%12)});}}
function makeGroups(){nativePlaybackKeyboard();groups=[];endPrefix=[];if(!song)return;let end=0;for(const n of song.notes){end=Math.max(end,n.start+n.duration);endPrefix.push(end);}formal.loadSong(JSON.stringify(song));groups=JSON.parse(formal.guideGroups(mode==='follow'&&$('#simple').checked));groupIndex=groups.findIndex(g=>g.start>=position);if(groupIndex<0)groupIndex=groups.length;formal.guideSeek(groupIndex);matched.clear();}
function expected(){const g=groups[groupIndex];if(!g)return[];const remaining=new Set(formal.guideExpected().split(',').filter(Boolean).map(Number));return g.notes.filter(n=>remaining.has(n.pitch));}
function rangeFrom(ms){let lo=0,hi=endPrefix.length;while(lo<hi){const mid=(lo+hi)>>>1;if(endPrefix[mid]<ms)lo=mid+1;else hi=mid;}return lo;}
function activeNotes(){const found=[];for(let i=rangeFrom(position);i<song.notes.length&&song.notes[i].start<=position;i++){const n=song.notes[i];if(n.start+n.duration>position)found.push(n);}return found;}
function updateLights(){for(const b of keyElements.values())b.classList.remove('current','next','pressed');for(const x of downs.values())keyElements.get(x.mapped)?.classList.add('pressed');const notes=mode==='follow'?expected():(playing||document.body.dataset.exporting)&&mode==='auto'?activeNotes():[];for(const n of notes)keyElements.get(mapPitch(n.pitch))?.classList.add('current');if(playing&&mode==='follow'&&$('#preview').checked){const g=groups[groupIndex+1];if(g)keyElements.get(mapPitch(Math.max(...g.notes.map(n=>n.pitch))))?.classList.add('next');}}
function instruction(){if(!playing)return mode==='free'?'直接点击琴键，或使用电脑键盘弹奏':'准备好后点击开始';if(mode==='auto')return'自动演奏中 · 可随时暂停';if(mode==='follow'){const g=expected();if(!g.length)return'已完成';const p=mapPitch(g[0].pitch),label=keyboardAdapter?.labelForPitch(g[0].pitch)||printed[p-base];return ($('#simple').checked?'轻点亮键一次，自动补足音长':'按住亮键，跟随音符长度松开')+(label?' · 电脑按 '+label:'');}return'自由弹奏';}
async function playNote(id,pitch,velocity=85,start=0,length=0){const voice=await audio.on(id,pitch,velocity,start);if(voice&&length>0)audio.off(id,false,Math.max(audio.context.currentTime,start)+length/1000);}
function noteDown(owner,mapped,forcedPitch=null,velocity=85){if(downs.has(owner)||(mapped===null&&forcedPitch===null))return;const e=expected(),note=playing&&mode==='follow'?e.find(n=>forcedPitch!==null?n.pitch===forcedPitch:mapPitch(n.pitch)===mapped):null,pitch=forcedPitch??note?.pitch??mapped;downs.set(owner,{mapped,pitch});if(recording)recordOwners.set(owner,{pitch,start:Math.round(performance.now()-recordStart),velocity});
 if(playing&&mode==='follow'&&note&&formal.guidePress(note.pitch)){matched.add(note.pitch);if($('#simple').checked){const g=groups[groupIndex];for(const [i,n] of (g.accompaniment||[]).entries())playNote(`accompaniment-${playEpoch}-${groupIndex}-${i}`,n.pitch,85,audio.context.currentTime+Math.max(0,n.start-g.start)/1000/speed,n.duration/speed);for(const n of g.notes)playNote(`follow-${playEpoch}-${groupIndex}-${n.pitch}`,n.pitch,85,0,n.duration/speed);}else playNote(owner,pitch,velocity);if(e.every(n=>matched.has(n.pitch))){position=groups[groupIndex].start;followLightUntil=performance.now()+Math.max(120,note.duration/speed);groupIndex=formal.guideIndex();matched.clear();if(groupIndex>=groups.length){playing=false;position=duration();$('#start').textContent='开始';status('完成了，可以从头再弹一遍');}}}
 else playNote(owner,pitch,velocity);updateLights();}
function noteUp(owner){const value=downs.get(owner);if(!value)return;downs.delete(owner);if(![...downs.values()].some(v=>v.pitch===value.pitch))formal.guideRelease(value.pitch);audio.off(owner);const event=recordOwners.get(owner);if(event){recordOwners.delete(owner);recordNotes.push({...event,duration:Math.max(1,Math.round(performance.now()-recordStart)-event.start)});}updateLights();}
function releasePhysical(){for(const id of [...downs.keys()])noteUp(id);pointers.clear();}
function pause(){playing=false;saveSession();playEpoch++;keyboardAdapter?.releaseAll();releasePhysical();audio.stop();$('#start').textContent='开始';updateLights();}
function restart(){pause();position=0;nextIndex=0;groupIndex=0;matched.clear();makeGroups();saveSession();status('已回到开头，点击开始播放');}
async function start(){if(playing){pause();return;}if(mode==='free'){status('直接按电脑键盘或点击琴键即可弹奏');audio.unlock().catch(e=>status(e.message));return;}if(!song){status('先从曲库选择歌曲');$('#library').click();return;}const epoch=++playEpoch;$('#start').disabled=true;status('正在准备音色…');try{await audio.unlock();await audio.prepare(song.notes.map(n=>n.pitch));if(epoch!==playEpoch)return;if(position>=duration())position=0;nextIndex=song.notes.findIndex(n=>n.start>=position);if(nextIndex<0)nextIndex=song.notes.length;makeGroups();origin=audio.context.currentTime-position/1000/speed;playing=true;$('#start').textContent='暂停';status('');}catch(e){status(e.message);}finally{$('#start').disabled=false;}}
keyboard.addEventListener('pointerdown',e=>{if(keyboardDrag){e.preventDefault();keyboard.setPointerCapture(e.pointerId);dragStart={x:e.clientX,base};return;}const b=e.target.closest('.key');if(!b)return;e.preventDefault();keyboard.setPointerCapture(e.pointerId);const p=Number(b.dataset.pitch);pointers.set(e.pointerId,p);noteDown('pointer-'+e.pointerId,p);});keyboard.addEventListener('pointermove',e=>{if(keyboardDrag&&dragStart){const whites=Array.from({length:88},(_,i)=>21+i).filter(p=>!blacks.has(p%12));const index=whites.indexOf(dragStart.base),delta=Math.round((dragStart.x-e.clientX)/(keyboard.clientWidth/keyCount));window.PianoWeb.setRange(whites[Math.max(0,Math.min(whites.length-keyCount,index+delta))]);return;}if(!pointers.has(e.pointerId))return;const b=document.elementFromPoint(e.clientX,e.clientY)?.closest('.key'),p=b?Number(b.dataset.pitch):null,old=pointers.get(e.pointerId);if(old===p)return;noteUp('pointer-'+e.pointerId);pointers.set(e.pointerId,p);if(p!==null)noteDown('pointer-'+e.pointerId,p);});for(const type of['pointerup','pointercancel','lostpointercapture'])keyboard.addEventListener(type,e=>{dragStart=null;noteUp('pointer-'+e.pointerId);pointers.delete(e.pointerId);});
const editing=target=>target?.matches?.('input,textarea,select,[contenteditable="true"]')||document.querySelector('dialog[open]');
addEventListener('keydown',e=>{if(keyboardAdapter){if(keyboardAdapter.handle(e,true))e.preventDefault();return;}if(document.body.dataset.surface&&document.body.dataset.surface!=='piano')return;if(editing(e.target)||e.ctrlKey||e.metaKey||e.altKey)return;const index=codes.indexOf(e.code);if(index>=0){e.preventDefault();if(!e.repeat&&keyElements.has(base+index))noteDown('key-'+e.code,base+index);}else if(e.code==='Space'){e.preventDefault();if(!e.repeat)start();}else if(e.code==='ArrowLeft'||e.code==='ArrowRight'){e.preventDefault();if(!e.repeat)shift(e.code==='ArrowLeft'?-12:12);}});addEventListener('keyup',e=>{if(keyboardAdapter){if(keyboardAdapter.handle(e,false))e.preventDefault();return;}if(codes.includes(e.code)){if(downs.has('key-'+e.code))e.preventDefault();noteUp('key-'+e.code);}});addEventListener('blur',()=>{setTimeout(()=>{const active=document.activeElement;const localFrame=active?.tagName==='IFRAME'&&active.closest?.('#web-staff-layer');if(localFrame&&!document.hidden)return;keyboardAdapter?.releaseAll();releasePhysical();pause();},0);});document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
function shift(n){base=Math.max(24,Math.min(84,base+n));configureKeys();status('音域已调整，当前音区保持固定');}
$('#lower').onclick=()=>shift(-12);$('#higher').onclick=()=>shift(12);$('#start').onclick=start;$('#restart').onclick=restart;$('#mode').onchange=e=>{pause();mode=e.target.value;makeGroups();status('');};$('#seek').oninput=e=>{pause();position=Number(e.target.value);makeGroups();};$('#tone').onchange=e=>{releasePhysical();audio.stop();audio.tone=e.target.value;status('音色已切换');};$('#volume').oninput=e=>audio.setVolume(Number(e.target.value));$('#sustain').onchange=e=>{audio.sustain=e.target.checked||pedalHeld;};$('#key-count').value=keyCount;$('#key-count').onchange=e=>{keyCount=Number(e.target.value);configureKeys();};$('#speed').oninput=e=>{pause();speed=Number(e.target.value);$('#speed-label').textContent=speed.toFixed(2).replace(/0+$/,'').replace(/\.$/,'')+'×';};$('#simple').onchange=()=>{pause();makeGroups();updateLights();};$('#preview').onchange=updateLights;
for(const b of document.querySelectorAll('[data-close]'))b.onclick=()=>b.closest('dialog').close();function open(id){pause();$(id).showModal();}$('#settings').onclick=()=>open('#settings-dialog');$('#help').onclick=()=>open('#help-dialog');
async function choose(row){const epoch=++selectionEpoch;pause();status('正在加载曲谱…');try{const selected=await library.load(row);if(epoch!==selectionEpoch)return;formal.loadSong(JSON.stringify(selected));formal.guideGroups(mode==='follow'&&$('#simple').checked);song=selected;position=0;nextIndex=0;if(mode==='free'&&!initialRestore)mode='follow';$('#mode').value=mode;makeGroups();$('#song-title').textContent=song.title;$('#library-dialog').close();status(song.storageWarning||'曲谱已就绪，点击开始');if(sessionReady)saveSession();audio.fetchSample(Math.max(...song.notes.slice(0,8).map(n=>n.pitch))).catch(()=>{});}catch(e){if(song)makeGroups();status(e.message);}}
function list(){results=library.search($('#search').value,$('#category').value);$('#songs').replaceChildren();for(const row of results.slice(nativePage*30,(nativePage+1)*30)){const wrap=document.createElement('div');wrap.className='song-row';const b=document.createElement('button'),title=document.createElement('span'),meta=document.createElement('small');title.textContent=row.title;meta.textContent=[row.category,row.author].filter(Boolean).join(' · ');const availability=document.createElement('small');availability.className='availability';availability.textContent=row.notes?'已保存':'需联网读取';b.append(title,meta,availability);b.onclick=()=>choose(row);const fav=document.createElement('button');fav.className='fav';fav.textContent=library.favorites.has(row.id)?'★':'☆';fav.setAttribute('aria-label','收藏 '+row.title);fav.onclick=()=>{library.favorite(row.id);list();};const more=document.createElement('button');more.className='row-more';more.textContent='⋯';more.setAttribute('aria-label','曲目操作 '+row.title);more.onclick=()=>choose(row);wrap.append(b,fav,more);$('#songs').append(wrap);}$('#library-status').textContent=`${results.length.toLocaleString()} 个结果${library.catalog?' · 原有可用曲谱快照，选择后才加载音符':''}`;$('#more').hidden=true;$('#native-page').textContent=(nativePage+1)+' / '+Math.max(1,Math.ceil(results.length/30));$('#native-prev').disabled=nativePage===0;$('#native-next').disabled=(nativePage+1)*30>=results.length;}
$('#library').onclick=async()=>{open('#library-dialog');await library.builtins;list();try{await library.all();for(const category of [...new Set(library.catalog.entries.map(s=>s.category))]){if([...$('#category').options].some(o=>o.value===category))continue;const o=new Option(category,category);$('#category').append(o);}list();}catch(e){$('#library-status').textContent=e.message+'；内置曲目与导入仍可使用';}};$('#search').oninput=()=>{nativePage=0;pageSize=30;list();};$('#category').onchange=()=>{nativePage=0;pageSize=30;list();};$('#more').onclick=()=>{pageSize+=50;list();};$('#import').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{const s=await library.import(file);list();await choose(s);}catch(error){$('#library-status').textContent=error.message;}e.target.value='';};
function download(name,body,type='application/json'){const u=URL.createObjectURL(new Blob([body],{type})),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
$('#record').onclick=async()=>{if(!recording){await audio.unlock();pause();recordNotes=[];recordStart=performance.now();recording=true;$('#record').textContent='■ 停止录制';status('正在录制你的弹奏');}else{releasePhysical();recording=false;$('#record').textContent='● 录制';if(!recordNotes.length){status('还没有录到音符');return;}recordNotes.sort((a,b)=>a.start-b.start||a.pitch-b.pitch);const s={id:'record-'+Date.now(),title:'我的演奏 '+new Date().toLocaleTimeString(),bpm:120,notes:recordNotes,durationMs:recordNotes.reduce((m,n)=>Math.max(m,n.start+n.duration),0),noteCount:recordNotes.length};try{library.save(s);status(s.storageWarning||'已保存在我的曲目，并导出弹奏文件');}catch(_){status('本机存储空间不足，弹奏已导出为文件');}download('我的演奏.json',JSON.stringify(s));}};
function numberedNoteText(n){const pitch=n.pitch%12,degrees={0:'1',2:'2',4:'3',5:'4',7:'5',9:'6',11:'7'},value=degrees[pitch]||'♯'+degrees[(pitch+11)%12],oct=Math.floor(n.pitch/12)-5;return(oct>0?'˙'.repeat(oct):'')+value+(oct<0?'̣'.repeat(-oct):'');}
function scoreText(){if(!song)return'先选择一首歌曲';let text=song.title+'\n\n';for(let i=0;i<groups.length;i++){const g=groups[i];text+=(g.notes.length>1?'['+g.notes.map(numberedNoteText).join(' ')+']':numberedNoteText(g.notes[0]))+' ';if((i+1)%8===0)text+='\n';}return text;}
$('#score').onclick=()=>{$('#score-content').textContent=scoreText();open('#score-dialog');};$('#save-score').onclick=()=>download((song?.title||'曲谱')+'-简谱.txt',scoreText(),'text/plain;charset=utf-8');
function draw(){
 const displayPosition=formal.rollFrame(position,performance.now(),!!document.body.dataset.exporting);
 const w=roll.clientWidth,h=roll.clientHeight,d=Math.min(3,devicePixelRatio||1);
 if(roll.width!==Math.round(w*d)||roll.height!==Math.round(h*d)){roll.width=Math.round(w*d);roll.height=Math.round(h*d);updateRects();}
 const signature=[w,h,d,base,keyCount,song?.id,mode,displayPosition,groupIndex,playing].join('|');
 if(signature!==lastDrawSignature){
  lastDrawSignature=signature;ctx.setTransform(d,0,0,d,0,0);ctx.clearRect(0,0,w,h);
  const material=ctx.createLinearGradient(0,0,0,h);material.addColorStop(0,'#151c21');material.addColorStop(.58,'#1a232a');material.addColorStop(1,'#242e36');ctx.fillStyle=material;ctx.fillRect(0,0,w,h);
  const sx=w/keyboard.clientWidth,whiteRects=[...keyRects.values()].filter(r=>!r.black);
  ctx.strokeStyle='#abcbd514';ctx.lineWidth=.5;
  for(const r of whiteRects){ctx.beginPath();ctx.moveTo(r.left*sx,0);ctx.lineTo(r.left*sx,h);ctx.stroke();}
  const line=mode==='follow'?Math.max(0,h-Math.min(h*.16,44)):h;
  if(mode==='follow'){ctx.strokeStyle='#c8dce63a';ctx.lineWidth=.75;ctx.beginPath();ctx.moveTo(0,line);ctx.lineTo(w,line);ctx.stroke();}
  if(song&&mode!=='free'){
   const scale=Math.max(.015,h/1800);let shown=0;
   for(let i=rangeFrom(displayPosition-200);i<song.notes.length;i++){
    const n=song.notes[i];if(n.start>displayPosition+1800)break;if(n.start+n.duration<displayPosition-200)continue;if(++shown>350)break;
    const r=keyRects.get(mapPitch(n.pitch));if(!r)continue;
    const ordinal=groups.findIndex(g=>g.notes.some(v=>v.pitch===n.pitch&&Math.abs(v.start-n.start)<=45))-groupIndex+1,target=ordinal===1&&mode==='follow';
    const onset=line-(n.start-displayPosition)*scale,len=Math.max(2,n.duration*scale),gap=Math.min(3,Math.max(0,len-2)*.25);
    const top=Math.max(0,onset-len+gap),bottom=Math.min(h,onset-gap*.35);if(bottom<=top)continue;
    const inset=Math.min(4,r.width*.14),x=(r.left+inset)*sx,width=(r.width-inset*2)*sx,height=bottom-top;
    const grad=ctx.createLinearGradient(x,top,x,bottom),colors=target?['#76c9ef','#94ddff','#6dbfe8']:n.start-displayPosition<900?['#3b829f','#327b99','#286a87']:['#32637b','#28566f','#214a62'];
    grad.addColorStop(0,colors[0]);grad.addColorStop(.42,colors[1]);grad.addColorStop(1,colors[2]);ctx.fillStyle=grad;ctx.beginPath();ctx.roundRect(x,top,width,height,Math.min(3,height/2));ctx.fill();
    ctx.strokeStyle=target?'#bde6ff':'#5f7a8a';ctx.lineWidth=target?1.15:.7;ctx.stroke();
    if(height>6){ctx.strokeStyle=target?'#effaff88':'#7db8d347';ctx.lineWidth=.65;ctx.beginPath();ctx.moveTo(x+3,top+1.2);ctx.lineTo(x+width-3,top+1.2);ctx.stroke();}
    if(onset>=0&&onset<=h){ctx.fillStyle=target?'#ddf2ff':'#b9cedb';ctx.fillRect(x+3,bottom-1.5,width-6,1.5);if(ordinal>=1&&ordinal<=6){ctx.fillStyle='#10202c';ctx.fillRect(x+2,onset-4,width-4,5);ctx.fillStyle=target?'#e6f8ff':'#76d1ea';ctx.fillRect(x+3,onset-3,width-6,3);if(onset>19){ctx.fillStyle=target?'#9edfff18':'#11233024';ctx.fillRect(x+3,onset-20,width-6,14);ctx.fillStyle=target?'#09283b':'#f1faff';ctx.textAlign='center';ctx.font='500 12px Roboto,Arial,sans-serif';ctx.fillText(ordinal+' · '+names[n.pitch%12]+(Math.floor(n.pitch/12)-1),x+width/2,onset-8);}}}
   }
  }
  ctx.strokeStyle=mode==='follow'?'#5d788b':'#435867';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,h-1);ctx.lineTo(w,h-1);ctx.stroke();ctx.textAlign='left';
 }
 $('#instruction').textContent=instruction();$('#time').textContent=time(displayPosition);$('#duration').textContent=time(duration());$('#seek').max=duration();$('#seek').value=displayPosition;updateLights();updateWebSurface();requestAnimationFrame(draw);
}

setInterval(()=>{if(!playing||mode!=='auto'||!audio.context)return;position=(audio.context.currentTime-origin)*1000*speed;if(loopState.enabled&&position>=loopState.b){pause();position=loopState.a;makeGroups();start();return;}const cutoff=Math.min(position+100*speed,loopState.enabled?loopState.b:Infinity),epoch=playEpoch;while(nextIndex<song.notes.length&&song.notes[nextIndex].start<=cutoff){const index=nextIndex++,n=song.notes[index],when=origin+n.start/1000/speed;playNote(`auto-${epoch}-${index}`,n.pitch,85,when,n.duration/speed);}if(position>=duration()+250){pause();position=duration();status('播放完成');}},25);
library.builtins.then(restoreWebSession).catch(e=>status(e.message));configureKeys();draw();audio.fetchSample(60).catch(()=>{});library.builtins.catch(e=>status(e.message));addEventListener('resize',updateRects);
window.PianoWeb={setRange(pitch){const whites=Array.from({length:88},(_,i)=>21+i).filter(p=>!blacks.has(p%12));const max=whites[Math.max(0,whites.length-keyCount)];base=Math.min(max,Math.max(21,pitch));while(blacks.has(base%12))base--;configureKeys();},setDrag(enabled){pause();keyboardDrag=enabled;},loop(enabled,a,b){if(enabled===undefined)return{...loopState};if(a<0||b>duration()||b-a<500)throw Error('请设置有效区间，至少间隔 0.5 秒');loopState={enabled,a,b};},async selectSong(id){await library.builtins;const row=library.search('').find(r=>r.id===id);if(!row)throw Error('曲目不存在');await choose(row);},browse(delta){nativePage=Math.max(0,Math.min(Math.max(0,Math.ceil(results.length/30)-1),nativePage+delta));list();},press(owner,pitch,velocity=85){noteDown(owner,mapPitch(pitch),pitch,velocity);},release(owner){noteUp(owner);},pause,view(){return{song,groups,groupIndex,expected:expected(),active:song?(mode==='auto'?activeNotes():[...downs.values()].map(v=>({pitch:v.pitch}))):[],mode,playing,position,speed,held:[...downs.values()].map(v=>v.pitch)};},inspect(){return{song:song?.id||null,mode,playing,position,base,keyCount,keyboardDrag,downOwners:[...downs.keys()],audio:audio.inspect(),groupIndex,groupCount:groups.length,catalogCount:library.catalog?.count||0,cachePacks:library.cache.size,recording,notation,keyboardAdapter:keyboardAdapter?.inspect(),staff:staffPractice?.inspect()};},audio,library};

let offlineSaved=null;
PianoWeb.beginOffline=(overrideSong=null)=>{pause();offlineSaved={position,mode,song};if(overrideSong){song=overrideSong;makeGroups();}mode='auto';document.body.dataset.exporting='true';return {song,speed,preset:Number($('#tone').value),volume:audio.volume,sustain:audio.sustain};};
PianoWeb.offlineFrame=async ms=>{position=ms;makeGroups();updateLights();updateWebSurface();if(notation==='staff'&&staffPractice){await staffPractice.setSong(song);await staffPractice.offlineFrame(ms,PianoWeb.view());}};
PianoWeb.endOffline=()=>{if(offlineSaved){position=offlineSaved.position;mode=offlineSaved.mode;song=offlineSaved.song;makeGroups();offlineSaved=null;}delete document.body.dataset.exporting;updateLights();};

let nativeGraceStep=-1,nativeGraceDue=0;
PianoWeb.practiceOptions={autoHelp:false,adaptive:true,maximum:1800};
setInterval(()=>{
 if(!playing||mode!=='follow'||!$('#simple').checked||recording||document.hidden){nativeGraceStep=-1;return;}
 if(groupIndex>=groups.length)return;
 const now=performance.now(),options=PianoWeb.practiceOptions;
 if(groupIndex!==nativeGraceStep){if(nativeGraceStep>=0)formal.graceObserve(Math.max(0,now-nativeGraceDue),false);nativeGraceStep=groupIndex;nativeGraceDue=now+Math.max(0,groups[groupIndex].start-position)/speed;}
 if(!options.autoHelp||now<nativeGraceDue+formal.graceTimeout(options.adaptive,options.maximum)||keyboardDrag)return;
 const group=groups[groupIndex];
 for(const [i,n] of group.notes.entries())playNote('help-'+playEpoch+'-'+groupIndex+'-'+i,n.pitch,85,0,n.duration/speed);
 for(const [i,n] of (group.accompaniment||[]).entries())playNote('help-accompaniment-'+playEpoch+'-'+groupIndex+'-'+i,n.pitch,85,audio.context.currentTime+Math.max(0,n.start-group.start)/1000/speed,n.duration/speed);
 formal.guideHelp();formal.graceObserve(now-nativeGraceDue,true);position=group.start;groupIndex=formal.guideIndex();matched.clear();nativeGraceStep=-1;
 if(loopState.enabled&&(groupIndex>=groups.length||position>=loopState.b)){position=loopState.a;makeGroups();}
 if(groupIndex>=groups.length){pause();position=duration();status('演奏完成');}
},50);

let manualPlaybackLayout=null;
function nativePlaybackKeyboard(){
 if(mode!=='auto'||(document.body.dataset.surface&&document.body.dataset.surface!=='piano')){if(manualPlaybackLayout){base=manualPlaybackLayout.base;keyCount=manualPlaybackLayout.keyCount;manualPlaybackLayout=null;configureKeys();}return;}
 if(!song?.notes.length)return;
 if(!manualPlaybackLayout)manualPlaybackLayout={base,keyCount};
 const whites=Array.from({length:88},(_,i)=>21+i).filter(p=>!blacks.has(p%12));
 let low=108,high=21;for(const n of song.notes){low=Math.min(low,Math.max(21,Math.min(108,n.pitch)));high=Math.max(high,Math.max(21,Math.min(108,n.pitch)));}
 const floor=p=>{let i=0;while(i+1<whites.length&&whites[i+1]<=p)i++;return i;};
 const lo=floor(low);let hi=floor(high);if(blacks.has(high%12)&&hi<whites.length-1)hi++;
 const count=Math.min(whites.length,Math.max(7,hi-lo+1)),start=Math.max(0,Math.min(whites.length-count,lo-Math.floor((count-(hi-lo+1))/2)));
 if(base!==whites[start]||keyCount!==count){base=whites[start];keyCount=count;configureKeys();}
}
PianoWeb.syncKeyboard=nativePlaybackKeyboard;


// Browser controls adapt the shared formal playback/Guide; source notes remain unchanged.
const SESSION_KEY='piano-web41-session';
function loadSession(){try{return JSON.parse(localStorage.getItem(SESSION_KEY)||'null');}catch(_){return null;}}
function saveSession(){
 if(!sessionReady||initialRestore||!song||document.body.dataset.exporting)return;
 const data={songId:song.id,mode,position,notation,base:manualPlaybackLayout?.base??base,keyCount:manualPlaybackLayout?.keyCount??keyCount,speed,tone:Number($('#tone').value),volume:audio.volume,sustain:$('#sustain').checked,simple:$('#simple').checked};
 try{localStorage.setItem(SESSION_KEY,JSON.stringify(data));}catch(_){}
}
async function restoreWebSession(rows){
 const saved=loadSession(),token=selectionEpoch;let row=rows[0];
 if(saved?.songId){row=[...rows,...library.custom].find(s=>s.id===saved.songId);if(!row){try{await library.all();row=library.search('').find(s=>s.id===saved.songId);}catch(_){}row||=rows[0];}}
 if(token!==selectionEpoch){initialRestore=false;sessionReady=!!song;return;}
 if(saved){mode=['free','auto','follow'].includes(saved.mode)?saved.mode:'free';$('#mode').value=mode;speed=Math.max(.4,Math.min(1.5,saved.speed||1));$('#speed').value=String(speed);$('#speed').dispatchEvent(new Event('input'));base=Math.max(21,Math.min(84,saved.base||base));keyCount=Math.max(7,Math.min(52,saved.keyCount||keyCount));$('#simple').checked=!!saved.simple;$('#sustain').checked=!!saved.sustain;audio.sustain=!!saved.sustain;audio.setVolume(Number.isFinite(saved.volume)?saved.volume:.72);$('#volume').value=String(audio.volume);notation=saved.notation==='waterfall'?'waterfall':'staff';}
 const restoreSelection=selectionEpoch+1;if(row)await choose(row);
 if(selectionEpoch!==restoreSelection){initialRestore=false;sessionReady=!!song;return;}
 initialRestore=false;
 await nativeReady;
 if(selectionEpoch!==restoreSelection){sessionReady=!!song;return;}
 if(saved&&Number.isInteger(saved.tone)&&[...$('#tone').options].some(o=>Number(o.value)===saved.tone)){$('#tone').value=String(saved.tone);$('#tone').dispatchEvent(new Event('change'));}
 if(saved&&song?.id===saved.songId){position=Math.max(0,Math.min(duration(),Number(saved.position)||0));makeGroups();}
 $('#mode').value=mode;$('#volume').value=String(audio.volume);initialRestore=false;sessionReady=!!song;configureKeys();setNotation(notation);saveSession();
}
function refreshComputerLabels(){for(const[p,b]of keyElements){const label=b.querySelector('.name');if(label)label.textContent=keyboardAdapter?.labelForPitch(p)||'';}}
function setNotation(value){notation=value==='waterfall'?'waterfall':'staff';$('#web-staff-layer').hidden=notation!=='staff';$('#roll').hidden=notation==='staff';$('#web-staff').setAttribute('aria-pressed',String(notation==='staff'));$('#web-waterfall').setAttribute('aria-pressed',String(notation==='waterfall'));staffPractice?.setActive(notation==='staff'&&(!document.body.dataset.surface||document.body.dataset.surface==='piano'));staffSongId='';saveSession();}
function updateWebSurface(){
 if(!keyboardAdapter)return;
 const view=PianoWeb.view(),piano=!document.body.dataset.surface||document.body.dataset.surface==='piano';
 $('#computer-keyboard').hidden=!piano||$('#web-keyboard-toggle').getAttribute('aria-expanded')==='false';
 $('#web-time').textContent=time(position);$('#web-duration').textContent=time(duration());$('#web-seek').max=String(duration());if(document.activeElement!==$('#web-seek'))$('#web-seek').value=String(position);$('#web-record').textContent=recording?'■ 停止录制':'● 录制';
 const next=groups[groupIndex+1];keyboardAdapter.update({held:[...downs.values()].map(v=>v.pitch),expected:playing&&mode==='follow'?expected().map(n=>n.pitch):[],next:playing&&mode==='follow'&&$('#preview').checked?(next?.notes||[]).map(n=>n.pitch):[],automatic:mode==='auto'&&playing?activeNotes().map(n=>n.pitch):[]});
 refreshComputerLabels();
 if(staffPractice){staffPractice.setActive(piano&&notation==='staff');if(piano&&notation==='staff'&&song&&performance.now()-lastStaffAt>45){lastStaffAt=performance.now();if(staffSongId!==song.id){staffSongId=song.id;staffPractice.setSong(song).catch(e=>status(e.message));}staffPractice.update(view);}}
}
keyboardAdapter=createKeyboardAdapter({host:$('#computer-keyboard'),isEnabled:()=>!document.querySelector('dialog[open]')&&!document.querySelector('.instrument').inert&&(!document.body.dataset.surface||document.body.dataset.surface==='piano'),onPress:(owner,pitch,velocity)=>noteDown(owner,keyElements.has(pitch)?pitch:null,pitch,velocity),onRelease:noteUp,onReleaseAll:()=>{releasePhysical();},onMappingChange:()=>{refreshComputerLabels();saveSession();},onPedal:on=>{pedalHeld=on;audio.sustain=on||$('#sustain').checked;},onPanic:()=>{pause();audio.sustain=$('#sustain').checked;},onTransport:()=>$('#start').click()});
staffPractice=new StaffPractice($('#web-staff-layer'));setNotation(notation);configureKeys();
$('#web-waterfall').onclick=()=>setNotation('waterfall');$('#web-staff').onclick=()=>setNotation('staff');
$('#web-keyboard-toggle').onclick=()=>{const on=$('#web-keyboard-toggle').getAttribute('aria-expanded')!=='true';$('#web-keyboard-toggle').setAttribute('aria-expanded',String(on));$('#computer-keyboard').hidden=!on;};
$('#web-help').onclick=()=>$('#help').click();$('#web-panic').onclick=()=>{keyboardAdapter.releaseAll();pause();status('全部声音已停止');};
$('#web-seek').oninput=e=>{$('#seek').value=e.target.value;$('#seek').dispatchEvent(new Event('input'));saveSession();};$('#web-record').onclick=()=>{$('#record').click();};
$('#web-fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.querySelector('.instrument').requestFullscreen();}catch(_){status('浏览器未允许全屏；当前窗口仍可演奏');}};
document.addEventListener('change',e=>{if(e.target.closest('dialog')){saveSession();refreshComputerLabels();}});
document.addEventListener('visibilitychange',()=>{if(document.hidden){keyboardAdapter.releaseAll();saveSession();}});addEventListener('pagehide',saveSession);setInterval(saveSession,3000);
PianoWeb.setNotation=setNotation;
PianoWeb.webReady=()=>sessionReady&&!!keyboardAdapter&&(!staffPractice||notation!=='staff'||staffPractice.inspect()?.ready);

// Wait for the shared tone menu before restoring a numeric preset.
const nativeReady=import('./native.js');
audio.sustain=false;$('#volume').value=String(audio.volume);$('#mode').value=mode;
PianoWeb.staffPractice=staffPractice;
nativeReady.then(()=>{
 $('#export-entry').onclick=async()=>{const button=$('#export-entry');button.disabled=true;try{const {exportActualVideo}=await import('./native-video.js');const blob=await exportActualVideo();download((song?.title||'演奏')+'-网页版.mp4',blob,'video/mp4');status('视频已生成，请查看浏览器下载');}catch(error){status(error.message);}finally{button.disabled=false;}};
}).catch(e=>status('演奏工具未加载完成：'+e.message));
